import type { CapacitorConfig } from '@capacitor/cli';

/**
 * إعداد تطبيق الأندرويد (Capacitor).
 * اللعبة تُبنى إلى مجلد dist ثم تُنسخ داخل الحزمة (AAB)، فلا يوجد أي رابط لموقع ولا خادم.
 */
const config: CapacitorConfig = {
  // ⚠️ معرّف الحزمة (Package name): لا يمكن تغييره بعد النشر على Google Play.
  // هذا هو معرّف نسختك السابقة (Sketchware). إن نشرتها من قبل فأبقِه كما هو
  // وبنفس مفتاح التوقيع، وإلا فاختر ما تشاء قبل أول رفع.
  appId: 'com.eid.sheepescape',
  appName: 'هروب خروف العيد',
  webDir: 'dist',

  android: {
    backgroundColor: '#fdf2e9',
    allowMixedContent: false,
  },

  plugins: {
    SystemBars: {
      // أندرويد 15/16 يرسم المحتوى خلف شريط الحالة؛ نحقن --safe-area-inset-* ليتعامل معها الـ CSS.
      insetsHandling: 'css',
      initialViewportFitValueHint: 'cover',
      // أيقونات داكنة فوق خلفية فاتحة
      style: 'LIGHT',
    },
  },
};

export default config;
