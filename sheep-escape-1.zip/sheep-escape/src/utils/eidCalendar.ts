/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Egyptian Official Eid Calendar & Holiday Detector
 * Detects official holidays for Eid al-Fitr and Eid al-Adha according to Egyptian cabinet official calendar.
 */

interface DateRange {
  start: string; // YYYY-MM-DD
  end: string;   // YYYY-MM-DD
  name: string;
}

// Official Egyptian Eid public holidays for recent & upcoming years
const EGYPTIAN_EID_HOLIDAYS: DateRange[] = [
  // 2024
  { start: '2024-04-09', end: '2024-04-14', name: 'عيد الفطر المبارك 2024' },
  { start: '2024-06-15', end: '2024-06-20', name: 'عيد الأضحى المبارك 2024' },
  // 2025
  { start: '2025-03-30', end: '2025-04-04', name: 'عيد الفطر المبارك 2025' },
  { start: '2025-06-05', end: '2025-06-10', name: 'عيد الأضحى المبارك 2025' },
  // 2026
  { start: '2026-03-19', end: '2026-03-24', name: 'عيد الفطر المبارك 2026' },
  { start: '2026-05-26', end: '2026-05-31', name: 'عيد الأضحى المبارك 2026' },
  // 2027
  { start: '2027-03-09', end: '2027-03-14', name: 'عيد الفطر المبارك 2027' },
  { start: '2027-05-16', end: '2027-05-21', name: 'عيد الأضحى المبارك 2027' },
  // 2028
  { start: '2028-02-26', end: '2028-03-03', name: 'عيد الفطر المبارك 2028' },
  { start: '2028-05-04', end: '2028-05-09', name: 'عيد الأضحى المبارك 2028' },
];

/**
 * Returns formatted date string in YYYY-MM-DD format (Cairo / Egypt local time)
 */
export function getTodayDateString(): string {
  try {
    const now = new Date();
    // Use Africa/Cairo time
    const formatter = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Africa/Cairo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    return formatter.format(now);
  } catch (e) {
    const now = new Date();
    return now.toISOString().split('T')[0];
  }
}

/**
 * Checks whether today is during an official Egyptian Eid holiday
 */
export function isEgyptianEidActive(): boolean {
  try {
    // Check developer preview / test override
    if (typeof window !== 'undefined' && window.localStorage) {
      if (window.localStorage.getItem('sheep_debug_force_eid') === 'true') {
        return true;
      }
    }

    const todayStr = getTodayDateString();

    // Check predefined official calendar ranges
    for (const range of EGYPTIAN_EID_HOLIDAYS) {
      if (todayStr >= range.start && todayStr <= range.end) {
        return true;
      }
    }

    // Algorithmic Hijri fallback (Shawwal 1-4 for Eid al-Fitr, Dhu al-Hijjah 9-13 for Eid al-Adha)
    try {
      const formatter = new Intl.DateTimeFormat('en-US-u-ca-islamic-umalqura-nu-latn', {
        day: 'numeric',
        month: 'numeric',
      });
      const parts = formatter.formatToParts(new Date());
      let day = 0;
      let month = 0;
      for (const part of parts) {
        if (part.type === 'day') day = parseInt(part.value, 10);
        if (part.type === 'month') month = parseInt(part.value, 10);
      }
      // Month 10 = Shawwal (1 to 4 is Eid al-Fitr)
      if (month === 10 && day >= 1 && day <= 4) return true;
      // Month 12 = Dhu al-Hijjah (9 to 13 is Arafat + Eid al-Adha)
      if (month === 12 && day >= 9 && day <= 13) return true;
    } catch (e) {}

    return false;
  } catch (err) {
    return false;
  }
}

/**
 * Returns current Eid holiday name if active, or next upcoming Eid
 */
export function getEidStatusDescription(): { isActive: boolean; title: string; note: string } {
  const active = isEgyptianEidActive();
  if (active) {
    return {
      isActive: true,
      title: 'أيام العيد المبارك مفعّلة! 🎉',
      note: 'مفتوحة الآن بمناسبة عطلة العيد الرسمية (متاح شراؤها مرتين يومياً)',
    };
  }
  return {
    isActive: false,
    title: 'متاحة خلال أيام العيد فقط 🔒',
    note: 'تُفتح تلقائياً في عطلات عيد الفطر وعيد الأضحى المبارك وفق الأجندة الرسمية لمصر 🌙',
  };
}
