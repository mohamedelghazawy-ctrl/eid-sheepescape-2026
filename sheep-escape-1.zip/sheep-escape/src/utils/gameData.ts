/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SheepOutfit, ObstacleType, DailyChallenge } from '../types';

export const OUTFITS: SheepOutfit[] = [
  {
    id: 'default',
    name: 'Normal Sheep',
    arabicName: 'خروف بلدي بسيط',
    price: 0,
    unlocked: true,
    color: '#F9FAFB', // Off-white fluffy
    accessoryEmoji: '🐑',
    description: 'خروفنا الطيب، سريع الحركة وحلمه البسيط يعيش بعد العيد دة!',
  },
  {
    id: 'tarbush',
    name: 'El-Mallem Meshmesh',
    arabicName: 'المعلم «مشمش»',
    price: 180,
    unlocked: false,
    color: '#FEF3C7', // Amber-ish white
    accessoryEmoji: '🎓', // Representing Tarbush look
    description: 'صاحب هيبة وشنب، لابس طربوش أحمر مصري أصيل وصعب أي حد يصطاده!',
    bonus: 'جاذبية مغناطيس +20%'
  },
  {
    id: 'saidi',
    name: 'Saidi Sheep',
    arabicName: 'خروف هريدي الصعيدي',
    price: 380,
    unlocked: false,
    color: '#E5E7EB', // Gray-ish
    accessoryEmoji: '👳', // Imama turban
    description: 'لابس الجلابية والعمة الصعيدي، قلبه جامد ومبيخافش من سكاكين الجزارين!',
    bonus: 'مدة الدرع والحماية +25%'
  },
  {
    id: 'cool',
    name: 'Cool Sheep',
    arabicName: 'خروف كول روش',
    price: 650,
    unlocked: false,
    color: '#EEF2F6',
    accessoryEmoji: '🕶️', // Sunglasses and gold chain
    description: 'نظارة شمس ذهبية وسلاسل روشة، خروف بيهرب بشياكة وعامل قلق في الحارة!',
    bonus: 'برسيم مضاعف من الذرة'
  },
  {
    id: 'boxer_tyson',
    name: 'Tyson Boxer Sheep',
    arabicName: 'خروف الملاكم تايسون',
    price: 850,
    unlocked: false,
    color: '#F1F5F9',
    accessoryEmoji: '🥊',
    description: 'بطل حلبات العيد، لابس قفازات ملاكمة وحزام ذهبي ويدمر أول عقبة تقابله بلكمة قاضية!',
    bonus: 'تدمير عقبة واحدة في الجولة بدون خسران (One-time Crash Shield) 🥊💥'
  },
  {
    id: 'captain_stadium',
    name: 'Stadium Captain Sheep',
    arabicName: 'خروف كابتن الملاعب',
    price: 1100,
    unlocked: false,
    color: '#E0F2FE',
    accessoryEmoji: '⚽',
    description: 'هداف الملاعب ونجم الشباك، شارة الكابتن في دراعه ويقفز قفزة ثانية أكروباتية بالهواء!',
    bonus: 'القفز المزدوج (Double Jump) لتفادي السيارات والعربات العالية ⚽🚀'
  },
  {
    id: 'mallem_baladi',
    name: 'Baladi Master Sheep',
    arabicName: 'خروف المعلم البلدية',
    price: 1500,
    unlocked: false,
    color: '#FEF3C7',
    accessoryEmoji: '🧣',
    description: 'كبير الحتة وشيخ السوق، صاحب الهيبة والجلابية البلدي، يمنحك بونص 25% برسيم عند نهاية الجولة!',
    bonus: '+25% برسيم إضافي بنهاية كل جولة 🍀💰'
  },
  {
    id: 'pharaoh',
    name: 'King Ramses Sheep',
    arabicName: 'خروف الفرعون توت',
    price: 2500,
    unlocked: false,
    color: '#FEF08A', // Golden glow
    accessoryEmoji: '👑', // Pharaoh crown
    description: 'حفيد الفراعنة العظماء، هرب من معبد الكرنك وجاي يعلّم الجزارين الجري السريع!',
    bonus: 'الحياة المضاعفة (محاولة إضافية كاملة مجانية!)'
  }
];

export const FUNNY_QUOTES = [
  "أنا مش فخدة.. أنا بني آدم! 🐑",
  "بعععععع! فكّني لو راجل يا معلم بسيوني! 🔪",
  "والله العظيم ما أنا الخروف السمين، اسأل المعزة اللي جمبي! 🐐",
  "الحقوني يا ناس! الجزار بيجري ورايا بساطور! 🏃‍♂️",
  "أنا حلمي أدخل المدرسة مش أدخل الفرن! 🏫",
  "جزار نو.. حرية يس! 🕊️",
  "البرسيم لا دين له! أنا بطلب لجوء ملوخية! 🌱",
  "بتقول فيها فتة ورقاق؟ ده أنا هخليك تجري ورا خيالك!",
  "أنا خسيت يا معلم ومبقاش فيا لحمة، وفر مجهودك!",
  "يا خراااااشي! الساطور قرّب أوي! 😱"
];

export const GAME_OVER_QUOTES = [
  "أوبس! المعلم بسيوني مسكك وهيحولك كفتة وطرب! 🥩",
  "يا خسارة، بقيت طبق فتة بالصلصة والثوم للزباين! 🍛",
  "الجزار كسب الجولة دي.. بس الخروف هيرجع ينتقم! 🍿",
  "اتمسكت على أول ناصية في السيدة زينب! 🕌",
  "وزنك زاد من البرسيم فمعرفتش تنط من فوق التوك توك! 🛺"
];

// Details of upgrade levels
export interface UpgradeItem {
  id: string;
  name: string;
  arabicName: string;
  emoji: string;
  description: string;
  basePrice: number;
  maxLevel: number;
}

export const UPGRADES: UpgradeItem[] = [
  {
    id: 'magnet_upgrade',
    name: 'Magnet Duration',
    arabicName: 'قوة مغناطيس البرسيم والذرة',
    emoji: '🧲',
    description: 'زيادة مدة وقوة جذب المغناطيس للبرسيم والذرة والكنوز تلقائياً.',
    basePrice: 100,
    maxLevel: 5
  },
  {
    id: 'corn_upgrade',
    name: 'Corn Boost Duration',
    arabicName: 'مدة مفعول الذرة السحرية',
    emoji: '🌽',
    description: 'زيادة مدة السرعة الفائقة ومضاعفة النقاط x2 عند أكل الذرة.',
    basePrice: 130,
    maxLevel: 5
  },
  {
    id: 'shield_upgrade',
    name: 'Fatta Garlic Shield',
    arabicName: 'درع صينية الفتة بالثوم',
    emoji: '🍲',
    description: 'زيادة مدة ومقاومة هالة درع الفتة بالثوم ضد صدمات الحارة المصرية.',
    basePrice: 160,
    maxLevel: 5
  },
  {
    id: 'golden_clover_upgrade',
    name: 'Radiant Golden Clover',
    arabicName: 'البرسيم الذهبي المشع',
    emoji: '🌟',
    description: 'ترقية تجعل بعض زهور البرسيم بالطريق ذهبية مشعة وتساوي 5 زهور دفعة واحدة!',
    basePrice: 200,
    maxLevel: 5
  }
];

// Escalating upgrade cost calculation: scales steeply per level
export const getUpgradeCost = (basePrice: number, currentLevel: number): number => {
  return Math.round(basePrice * Math.pow(2.0, currentLevel - 1));
};

export const INITIAL_CHALLENGES = [
  {
    id: 'dist_1000',
    title: 'الوصول إلى مسافة 1000 متر 🏃‍♂️',
    type: 'distance' as const,
    target: 1000,
    rewardClovers: 50,
  },
  {
    id: 'avoid_5',
    title: 'تجنب 5 عقبات متتالية 🛡️',
    type: 'avoid_streak' as const,
    target: 5,
    rewardClovers: 45,
  },
  {
    id: 'collect_clovers_50',
    title: 'جمع 50 زهرة برسيم خضراء 🍀',
    type: 'collect_clovers' as const,
    target: 50,
    rewardClovers: 60,
  },
  {
    id: 'collect_corn_10',
    title: 'جمع 10 كيزان ذرة سحرية 🌽',
    type: 'collect_corn' as const,
    target: 10,
    rewardClovers: 80,
  },
  {
    id: 'score_5000',
    title: 'تحقيق نتيجة 5000 نقطة بالهروب 🔥',
    type: 'score' as const,
    target: 5000,
    rewardClovers: 100,
  }
];
