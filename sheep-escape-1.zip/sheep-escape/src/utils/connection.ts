/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * نقطة واحدة للتحقق من الاتصال بالإنترنت، وللتعرّف على أن اللعبة تعمل كتطبيق أندرويد.
 * كل فحوصات الشبكة في اللعبة تمرّ من هنا؛ فعندما تكون REQUIRE_INTERNET = false
 * لا يؤثر انقطاع الشبكة على اللعب إطلاقاً.
 */

import { APP_CONFIG } from '../config';

/** هل الاتصال متاح (أو غير مطلوب أصلاً)؟ */
export function isConnected(): boolean {
  if (!APP_CONFIG.REQUIRE_INTERNET) return true;
  if (typeof navigator === 'undefined') return true;
  return navigator.onLine !== false;
}

/** هل اللعبة تعمل داخل تطبيق Capacitor (أندرويد)؟ */
export function isNativeApp(): boolean {
  try {
    const cap = (window as any).Capacitor;
    return !!(cap && typeof cap.isNativePlatform === 'function' && cap.isNativePlatform());
  } catch {
    return false;
  }
}

/** فتح رابط خارجي (واتساب مثلاً) دون إخراج اللعبة من التطبيق. */
export function openExternal(url: string): void {
  try {
    const w = window.open(url, '_blank');
    if (!w) window.location.href = url;
  } catch {
    try {
      window.location.href = url;
    } catch {
      /* لا شيء يمكن فعله */
    }
  }
}
