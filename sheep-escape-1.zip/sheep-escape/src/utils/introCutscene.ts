/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { OUTFITS } from './gameData';

export interface IntroSplinter {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rot: number;
  vRot: number;
  w: number;
  h: number;
  color: string;
}

export interface IntroState {
  active: boolean;
  timer: number;
  maxFrames: number;
  ramHit: boolean;
  splinters: IntroSplinter[];
}

export const createInitialIntroState = (): IntroState => ({
  active: true,
  timer: 0,
  maxFrames: 105, // ~1.7 seconds at 60fps
  ramHit: false,
  splinters: [],
});

export const updateIntroPhysics = (
  intro: IntroState,
  dt: number,
  w: number,
  hTargetLine: number,
  onRamHit: () => void
) => {
  if (!intro.active) return;

  intro.timer += dt;

  // Frame 40: Ram impact trigger
  if (intro.timer >= 40 && !intro.ramHit) {
    intro.ramHit = true;
    onRamHit();

    // Spawn 26 wooden splinters & planks exploding outward from the door center
    const colors = ['#78350f', '#92400e', '#b45309', '#d97706', '#451a03', '#fef08a'];
    for (let i = 0; i < 26; i++) {
      const angle = (Math.PI * 2 * i) / 26 + (Math.random() * 0.4 - 0.2);
      const speed = Math.random() * 11 + 5;
      intro.splinters.push({
        x: w / 2 + (Math.random() * 30 - 15),
        y: hTargetLine - 65 + (Math.random() * 30 - 15),
        vx: Math.cos(angle) * speed * 1.2,
        vy: Math.sin(angle) * speed - 4, // explosive upward arc
        rot: Math.random() * Math.PI * 2,
        vRot: (Math.random() * 0.5 - 0.25),
        w: Math.random() * 16 + 8,
        h: Math.random() * 7 + 4,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }
  }

  // Update flying splinters physics
  for (let i = intro.splinters.length - 1; i >= 0; i--) {
    const sp = intro.splinters[i];
    sp.x += sp.vx * dt;
    sp.y += sp.vy * dt;
    sp.vy += 0.52 * dt; // gravity
    sp.rot += sp.vRot * dt;
  }

  // End intro sequence smoothly
  if (intro.timer >= intro.maxFrames) {
    intro.active = false;
  }
};

export const drawIntroCutscene = (
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  horizonY: number,
  hTargetLine: number,
  intro: IntroState,
  activeOutfitId: string
) => {
  const timer = intro.timer;
  const outfit = OUTFITS.find(o => o.id === activeOutfitId) || OUTFITS[0];
  const woolColor = outfit.color;

  // Door center reference
  const doorCenterX = w / 2;
  const doorBottomY = hTargetLine + 25;
  const doorHeight = Math.min(340, h * 0.62);
  const doorTopY = doorBottomY - doorHeight;
  const doorTotalWidth = Math.min(340, w * 0.88);
  const singleDoorWidth = doorTotalWidth / 2;

  // Swing progress: 0 when closed, 1 when wide open
  const openProgress = timer < 40 ? 0 : Math.min(1, Math.pow((timer - 40) / 45, 1.4));
  const fadeOutAlpha = timer > 85 ? Math.max(0, 1 - (timer - 85) / 20) : 1;

  ctx.save();
  ctx.globalAlpha = fadeOutAlpha;

  // 1. Butcher Shop Stone Portal & Brick Frame
  const portalX = doorCenterX - doorTotalWidth / 2 - 25;
  const portalW = doorTotalWidth + 50;
  const portalY = Math.max(10, doorTopY - 70);
  const portalH = doorBottomY - portalY + 20;

  // Brick facade around door
  ctx.fillStyle = '#7c2d12'; // Egyptian red terracotta brick
  ctx.fillRect(portalX, portalY, portalW, portalH);

  // Brick mortar pattern
  ctx.strokeStyle = 'rgba(254, 215, 170, 0.15)';
  ctx.lineWidth = 1.2;
  for (let by = portalY + 16; by < portalY + portalH; by += 22) {
    ctx.beginPath();
    ctx.moveTo(portalX, by);
    ctx.lineTo(portalX + portalW, by);
    ctx.stroke();
  }

  // Butcher Shop Sign above door
  ctx.fillStyle = '#451a03';
  ctx.strokeStyle = '#f59e0b';
  ctx.lineWidth = 2.5;
  const signW = Math.min(270, portalW - 30);
  const signH = 46;
  const signX = doorCenterX - signW / 2;
  const signY = portalY + 12;
  ctx.beginPath();
  ctx.roundRect(signX, signY, signW, signH, 8);
  ctx.fill();
  ctx.stroke();

  // Shop Sign Text
  ctx.fillStyle = '#fef08a';
  ctx.font = 'black 14px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('🥩 جزارة المعلم بسيوني 🥩', doorCenterX, signY + 16);

  ctx.fillStyle = '#fed7aa';
  ctx.font = 'bold 10px sans-serif';
  ctx.fillText('لحوم بلدية طازجة • ممنوع هروب الأضاحي!', doorCenterX, signY + 34);

  // Hanging Garlic and Meat Hooks on sides
  ctx.fillStyle = '#fef08a';
  for (let g = 0; g < 4; g++) {
    ctx.beginPath();
    ctx.arc(portalX + 12, portalY + 80 + g * 16, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(portalX + portalW - 12, portalY + 80 + g * 16, 5, 0, Math.PI * 2);
    ctx.fill();
  }

  // 2. Doorway Interior / Alley Light Reveal
  // When doors break open, bright sunlight floods out from inside
  if (openProgress > 0) {
    const openingW = doorTotalWidth * openProgress * 0.95;
    ctx.save();
    const lightGrad = ctx.createRadialGradient(
      doorCenterX,
      doorTopY + doorHeight * 0.5,
      20,
      doorCenterX,
      doorTopY + doorHeight * 0.5,
      doorTotalWidth * 0.8
    );
    lightGrad.addColorStop(0, 'rgba(254, 240, 138, 0.85)');
    lightGrad.addColorStop(0.5, 'rgba(251, 191, 36, 0.5)');
    lightGrad.addColorStop(1, 'rgba(217, 119, 6, 0)');
    ctx.fillStyle = lightGrad;
    ctx.fillRect(doorCenterX - openingW / 2, doorTopY, openingW, doorHeight);
    ctx.restore();
  }

  // 3. The Double Wooden Doors (Left and Right)
  // Left Door
  ctx.save();
  const leftDoorX = doorCenterX - doorTotalWidth / 2;
  const leftSwingScale = Math.max(0.08, 1 - openProgress * 0.88); // foreshortens as it swings open
  ctx.translate(leftDoorX, doorTopY);
  ctx.scale(leftSwingScale, 1);

  // Door Wood Background
  ctx.fillStyle = '#573012';
  ctx.fillRect(0, 0, singleDoorWidth, doorHeight);

  // Wood Planks
  ctx.strokeStyle = '#381c06';
  ctx.lineWidth = 2.5;
  for (let p = 1; p < 4; p++) {
    ctx.beginPath();
    ctx.moveTo((singleDoorWidth / 4) * p, 0);
    ctx.lineTo((singleDoorWidth / 4) * p, doorHeight);
    ctx.stroke();
  }

  // Iron Braces / Hinges
  ctx.fillStyle = '#1f2937';
  ctx.fillRect(0, 30, singleDoorWidth, 14);
  ctx.fillRect(0, doorHeight - 50, singleDoorWidth, 14);
  ctx.restore();

  // Right Door
  ctx.save();
  const rightDoorX = doorCenterX + doorTotalWidth / 2;
  const rightSwingScale = Math.max(0.08, 1 - openProgress * 0.88);
  ctx.translate(rightDoorX, doorTopY);
  ctx.scale(rightSwingScale, 1);

  // Door Wood Background
  ctx.fillStyle = '#573012';
  ctx.fillRect(-singleDoorWidth, 0, singleDoorWidth, doorHeight);

  // Wood Planks
  ctx.strokeStyle = '#381c06';
  ctx.lineWidth = 2.5;
  for (let p = 1; p < 4; p++) {
    ctx.beginPath();
    ctx.moveTo(-singleDoorWidth + (singleDoorWidth / 4) * p, 0);
    ctx.lineTo(-singleDoorWidth + (singleDoorWidth / 4) * p, doorHeight);
    ctx.stroke();
  }

  // Iron Braces / Hinges
  ctx.fillStyle = '#1f2937';
  ctx.fillRect(-singleDoorWidth, 30, singleDoorWidth, 14);
  ctx.fillRect(-singleDoorWidth, doorHeight - 50, singleDoorWidth, 14);
  ctx.restore();

  // 4. Heavy Wooden Crossbar (Lock Bar) across the center
  if (timer < 40) {
    // Intact heavy bar
    ctx.fillStyle = '#78350f';
    ctx.strokeStyle = '#451a03';
    ctx.lineWidth = 3;
    const barW = doorTotalWidth * 0.82;
    const barH = 26;
    const barX = doorCenterX - barW / 2;
    const barY = doorTopY + doorHeight * 0.55;
    ctx.beginPath();
    ctx.roundRect(barX, barY, barW, barH, 4);
    ctx.fill();
    ctx.stroke();

    // Big Iron Padlock in center
    ctx.fillStyle = '#9ca3af';
    ctx.beginPath();
    ctx.arc(doorCenterX, barY + barH / 2 - 8, 10, Math.PI, 0);
    ctx.stroke();
    ctx.fillStyle = '#eab308';
    ctx.beginPath();
    ctx.roundRect(doorCenterX - 11, barY + barH / 2 - 3, 22, 20, 4);
    ctx.fill();
  } else {
    // Snapped broken bar flying / dropping apart
    const snapDrop = Math.min(60, (timer - 40) * 2.5);
    const snapRot = (timer - 40) * 0.05;

    // Left snapped half
    ctx.save();
    ctx.translate(doorCenterX - 70, doorTopY + doorHeight * 0.55 + snapDrop);
    ctx.rotate(-snapRot);
    ctx.fillStyle = '#78350f';
    ctx.fillRect(-60, -12, 60, 24);
    ctx.restore();

    // Right snapped half
    ctx.save();
    ctx.translate(doorCenterX + 70, doorTopY + doorHeight * 0.55 + snapDrop);
    ctx.rotate(snapRot);
    ctx.fillStyle = '#78350f';
    ctx.fillRect(0, -12, 60, 24);
    ctx.restore();
  }

  // 5. Impact Starburst & "طرااااخ! 💥" on Ram Hit
  if (timer >= 40 && timer < 62) {
    const starProgress = (timer - 40) / 22;
    const starScale = Math.sin(starProgress * Math.PI) * 1.4;

    ctx.save();
    ctx.translate(doorCenterX, doorTopY + doorHeight * 0.55);
    ctx.scale(starScale, starScale);

    // Comic Explosion Star
    ctx.fillStyle = '#fbbf24';
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 4;
    ctx.beginPath();
    const points = 10;
    for (let p = 0; p < points * 2; p++) {
      const rad = p % 2 === 0 ? 55 : 24;
      const angle = (p * Math.PI) / points;
      const sx = Math.cos(angle) * rad;
      const sy = Math.sin(angle) * rad;
      if (p === 0) ctx.moveTo(sx, sy);
      else ctx.lineTo(sx, sy);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Bold Arabic Comic Bang Sound Text
    ctx.fillStyle = '#dc2626';
    ctx.font = 'black 22px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('طرااااخ! 💥', 0, 0);
    ctx.restore();
  }

  // 6. Flying Wood Splinters
  for (let i = 0; i < intro.splinters.length; i++) {
    const sp = intro.splinters[i];
    ctx.save();
    ctx.translate(sp.x, sp.y);
    ctx.rotate(sp.rot);
    ctx.fillStyle = sp.color;
    ctx.fillRect(-sp.w / 2, -sp.h / 2, sp.w, sp.h);
    ctx.restore();
  }

  // 7. THE HERO SHEEP (Animated charging, headbutting, and leaping through!)
  let sheepX = doorCenterX;
  let sheepY = doorBottomY - 10;
  let sheepScale = 1.25;
  let sheepAngle = 0;
  let speechText = '';

  if (timer < 22) {
    // Phase A: Determination & winding up, scraping hoof
    const hoofScrape = Math.sin(timer * 0.6) * 3;
    sheepY = doorBottomY - 10;
    speechText = 'مش هبقى كفتة النهارده! 🐑🔥';

    // Little dust puff on hoof scrape
    if (timer % 5 < 2) {
      ctx.fillStyle = 'rgba(217, 119, 6, 0.4)';
      ctx.beginPath();
      ctx.arc(sheepX - 14, sheepY + 6, 6, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (timer < 40) {
    // Phase B: Lowering head & High-speed Charge forward into the door!
    const chargeProgress = (timer - 22) / 18;
    // Step back slightly then accelerate like a rocket!
    const dist = chargeProgress < 0.25 ? -8 : (chargeProgress - 0.25) * 45;
    sheepY = doorBottomY - 10 - dist;
    sheepScale = 1.25 + chargeProgress * 0.15;
    sheepAngle = 0.08; // tilted forward

    // Speed wind lines behind sheep
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.lineWidth = 2.5;
    for (let l = -20; l <= 20; l += 12) {
      ctx.beginPath();
      ctx.moveTo(sheepX + l, sheepY + 30);
      ctx.lineTo(sheepX + l, sheepY + 60);
      ctx.stroke();
    }
  } else if (timer < 65) {
    // Phase C: Glorious leap through the broken doorway into the daylight!
    const leapProgress = (timer - 40) / 25;
    const leapY = Math.sin(leapProgress * Math.PI) * 45;
    sheepY = doorBottomY - 10 - leapY;
    sheepScale = 1.35 - leapProgress * 0.1;
    speechText = 'الحرييييية! جررري! 🚀💨';
  } else {
    // Phase D: Landing smoothly in center lane ready to run!
    const landProgress = Math.min(1, (timer - 65) / 20);
    sheepY = doorBottomY - 10 + Math.sin(landProgress * Math.PI * 2) * 4;
    sheepScale = 1.25;
  }

  // Draw the Sheep Figure
  ctx.save();
  ctx.translate(sheepX, sheepY);
  ctx.scale(sheepScale, sheepScale);
  ctx.rotate(sheepAngle);

  // Sheep Fluffy Cloud Wool Body
  ctx.fillStyle = woolColor;
  ctx.beginPath();
  ctx.arc(0, -18, 18, 0, Math.PI * 2);
  ctx.arc(-12, -18, 14, 0, Math.PI * 2);
  ctx.arc(12, -18, 14, 0, Math.PI * 2);
  ctx.arc(-7, -26, 12, 0, Math.PI * 2);
  ctx.arc(7, -26, 12, 0, Math.PI * 2);
  ctx.fill();

  // Black Head
  ctx.fillStyle = '#1f2937';
  ctx.beginPath();
  ctx.ellipse(0, -20, 11, 13, 0, 0, Math.PI * 2);
  ctx.fill();

  // Floppy Ears
  ctx.beginPath();
  ctx.ellipse(-14, -22, 4, 10, 0.3, 0, Math.PI * 2);
  ctx.ellipse(14, -22, 4, 10, -0.3, 0, Math.PI * 2);
  ctx.fill();

  // Ramming Horns (Curved Golden Horns aimed straight forward!)
  ctx.strokeStyle = '#d97706';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(-11, -26, 9, Math.PI * 0.2, Math.PI * 1.4, false);
  ctx.arc(11, -26, 9, Math.PI * 0.8, Math.PI * 1.8, true);
  ctx.stroke();

  // Determined / Fierce Cartoon Eyes
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(-5, -20, 4, 0, Math.PI * 2);
  ctx.arc(5, -20, 4, 0, Math.PI * 2);
  ctx.fill();

  // Pupils
  ctx.fillStyle = '#111827';
  ctx.beginPath();
  ctx.arc(-4, -20, 2, 0, Math.PI * 2);
  ctx.arc(6, -20, 2, 0, Math.PI * 2);
  ctx.fill();

  // Angry Eyebrows
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 2.4;
  ctx.beginPath();
  ctx.moveTo(-9, -25); ctx.lineTo(-2, -23);
  ctx.moveTo(9, -25); ctx.lineTo(2, -23);
  ctx.stroke();

  // Snorting steam from nose when charging
  if (timer > 10 && timer < 40) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
    ctx.beginPath();
    ctx.arc(-8, -12, 3, 0, Math.PI * 2);
    ctx.arc(8, -12, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  // Trotting Hooves
  ctx.fillStyle = '#111827';
  ctx.fillRect(-10, -2, 6, 12);
  ctx.fillRect(4, -2, 6, 12);

  ctx.restore(); // end sheep

  // Comic Speech Bubble over Sheep
  if (speechText && timer < 85) {
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#d97706';
    ctx.lineWidth = 2.5;
    ctx.font = 'black 13px sans-serif';
    const textW = ctx.measureText(speechText).width + 24;
    const bubbleX = doorCenterX - textW / 2;
    const bubbleY = sheepY - 65;

    ctx.beginPath();
    ctx.roundRect(bubbleX, bubbleY, textW, 30, 10);
    ctx.fill();
    ctx.stroke();

    // Bubble pointer down to sheep
    ctx.beginPath();
    ctx.moveTo(doorCenterX - 6, bubbleY + 30);
    ctx.lineTo(doorCenterX, bubbleY + 38);
    ctx.lineTo(doorCenterX + 6, bubbleY + 30);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#9a3412';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(speechText, doorCenterX, bubbleY + 15);
    ctx.restore();
  }

  // 8. Big Launch Announcement Banner (Frame 85-105)
  if (timer >= 85) {
    ctx.save();
    const bannerAlpha = Math.min(1, Math.sin(((timer - 85) / 20) * Math.PI));
    ctx.globalAlpha = bannerAlpha;
    ctx.fillStyle = 'rgba(16, 185, 129, 0.95)';
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    const bW = 200;
    const bH = 40;
    const bX = doorCenterX - bW / 2;
    const bY = h * 0.35;
    ctx.beginPath();
    ctx.roundRect(bX, bY, bW, bH, 20);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'black 16px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('اهرب يا خروف! 🏃‍♂️💨', doorCenterX, bY + 20);
    ctx.restore();
  }

  ctx.restore(); // end globalAlpha fadeOut
};
