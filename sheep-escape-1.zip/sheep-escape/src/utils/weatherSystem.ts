/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WeatherType, WeatherParticle } from '../types';

export interface WeatherConfig {
  type: WeatherType;
  arabicName: string;
  badgeEmoji: string;
  announcement: string;
  subtitle: string;
  skyColors: [string, string, string];
  horizonSilhouetteColor: string;
  hazeColor: string;
  hazeOpacity: number;
  heatWaveIntensity: number;
  sunRaysIntensity: number;
  dustWindSpeed: number;
  targetParticleCount: number;
}

export const WEATHER_PRESETS: Record<WeatherType, WeatherConfig> = {
  SUNNY_HEAT: {
    type: 'SUNNY_HEAT',
    arabicName: 'شمس حارقة',
    badgeEmoji: '☀️',
    announcement: '☀️ شمس حارقة ووهج الصيف المصري!',
    subtitle: 'سراب على الأسفلت وأشعة ذهبية تخترق الأزقة',
    skyColors: ['#0284c7', '#38bdf8', '#bae6fd'],
    horizonSilhouetteColor: 'rgba(2, 132, 199, 0.22)',
    hazeColor: '254, 240, 138', // warm bright glow
    hazeOpacity: 0.08,
    heatWaveIntensity: 1.0,
    sunRaysIntensity: 0.85,
    dustWindSpeed: -1.2,
    targetParticleCount: 30,
  },
  KHAMASEEN: {
    type: 'KHAMASEEN',
    arabicName: 'رياح الخماسين',
    badgeEmoji: '🌪️',
    announcement: '🌪️ هبت رياح الخماسين والغبار الذهبي!',
    subtitle: 'عاصفة ترابية ناعمة وأجواء قاهرية أصيلة',
    skyColors: ['#b45309', '#d97706', '#fde68a'],
    horizonSilhouetteColor: 'rgba(180, 83, 9, 0.35)',
    hazeColor: '217, 119, 6', // rich amber dust
    hazeOpacity: 0.18,
    heatWaveIntensity: 0.35,
    sunRaysIntensity: 0.2,
    dustWindSpeed: -5.8,
    targetParticleCount: 65,
  },
  GOLDEN_ASR: {
    type: 'GOLDEN_ASR',
    arabicName: 'عصرية المعز',
    badgeEmoji: '🌅',
    announcement: '🌅 عصرية قاهرة المعز ونسمة هادية!',
    subtitle: 'سرب حمام بلدي يحلّق وأشعة الغروب الدافئة',
    skyColors: ['#c2410c', '#f59e0b', '#fef08a'],
    horizonSilhouetteColor: 'rgba(194, 65, 12, 0.28)',
    hazeColor: '249, 115, 22', // honey sunset
    hazeOpacity: 0.12,
    heatWaveIntensity: 0.15,
    sunRaysIntensity: 0.65,
    dustWindSpeed: -2.0,
    targetParticleCount: 35,
  },
  NIGHT_BREEZE: {
    type: 'NIGHT_BREEZE',
    arabicName: 'نسيم الليل',
    badgeEmoji: '🌙',
    announcement: '🌙 نسيم ليل خان الخليلي وسحر الفوانيس!',
    subtitle: 'هواء نقي منعش وأضواء تلمع في أزقة الحارة',
    skyColors: ['#020617', '#0f172a', '#1e1b4b'],
    horizonSilhouetteColor: 'rgba(51, 65, 85, 0.4)',
    hazeColor: '30, 27, 75', // twilight indigo
    hazeOpacity: 0.14,
    heatWaveIntensity: 0.0,
    sunRaysIntensity: 0.0,
    dustWindSpeed: -1.0,
    targetParticleCount: 28,
  },
};

export const WEATHER_CYCLE: WeatherType[] = [
  'SUNNY_HEAT',
  'KHAMASEEN',
  'GOLDEN_ASR',
  'NIGHT_BREEZE',
];

// Helper to initialize ambient weather particles
export const createWeatherParticles = (count: number, w: number, h: number): WeatherParticle[] => {
  const particles: WeatherParticle[] = [];
  for (let i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * (w + 100),
      y: Math.random() * h,
      z: Math.random(), // 0 = far, 1 = near
      size: Math.random() * 3 + 1.2,
      vx: (Math.random() * 2 - 1) - 2.5,
      vy: (Math.random() * 1.5 - 0.75),
      alpha: Math.random() * 0.7 + 0.3,
      baseAlpha: Math.random() * 0.6 + 0.25,
      color: '#fcd34d',
      wobbleSpeed: Math.random() * 0.05 + 0.02,
      wobbleAmp: Math.random() * 1.8 + 0.5,
      phase: Math.random() * Math.PI * 2,
    });
  }
  return particles;
};

// Update weather particle physics & spawn logic
export const updateWeatherParticles = (
  particles: WeatherParticle[],
  weather: WeatherType,
  dt: number,
  w: number,
  h: number,
  horizonY: number
) => {
  const config = WEATHER_PRESETS[weather];
  const targetCount = config.targetParticleCount;

  // Adjust particle array length smoothly
  if (particles.length < targetCount && Math.random() < 0.2) {
    particles.push({
      x: w + Math.random() * 40,
      y: Math.random() * h,
      z: Math.random(),
      size: Math.random() * 3.5 + 1.2,
      vx: config.dustWindSpeed * (0.8 + Math.random() * 0.6),
      vy: (Math.random() * 1.2 - 0.6),
      alpha: Math.random() * 0.7 + 0.3,
      baseAlpha: Math.random() * 0.6 + 0.25,
      color: '#fcd34d',
      wobbleSpeed: Math.random() * 0.05 + 0.02,
      wobbleAmp: Math.random() * 2.0 + 0.5,
      phase: Math.random() * Math.PI * 2,
    });
  } else if (particles.length > targetCount + 10) {
    particles.pop();
  }

  // Update existing particles
  for (let i = 0; i < particles.length; i++) {
    const p = particles[i];
    p.phase += p.wobbleSpeed * dt;

    if (weather === 'KHAMASEEN') {
      // Khamaseen sand dust: fast horizontal blowing with depth perspective
      const speedMult = 0.7 + p.z * 1.2;
      p.x += config.dustWindSpeed * speedMult * dt;
      p.y += (Math.sin(p.phase) * p.wobbleAmp + (p.z > 0.5 ? 0.3 : 0.1)) * dt;
      p.color = p.z > 0.6 ? '#f59e0b' : '#d97706';
      p.alpha = (p.baseAlpha * 1.3) * (0.6 + Math.sin(p.phase * 0.7) * 0.4);
    } else if (weather === 'SUNNY_HEAT') {
      // Hot summer day: floating golden sun-motes rising gently with heat convection
      p.x += (config.dustWindSpeed * 0.6 + Math.sin(p.phase) * p.wobbleAmp) * dt;
      p.y -= (0.45 + p.z * 0.5) * dt; // Convection upward drift
      p.color = '#fef08a';
      p.alpha = (p.baseAlpha * 0.9) * (0.5 + Math.sin(p.phase) * 0.5);
    } else if (weather === 'GOLDEN_ASR') {
      // Golden hour: tranquil drifting amber pollen & warm dust
      p.x += (config.dustWindSpeed * 0.8 + Math.cos(p.phase) * 0.5) * dt;
      p.y += (Math.sin(p.phase) * 0.4) * dt;
      p.color = '#fbbf24';
      p.alpha = p.baseAlpha * 0.95;
    } else {
      // Night breeze: glowing firefly motes floating lazily with gentle pulse
      p.x += (Math.sin(p.phase * 0.6) * 1.2 - 0.6) * dt;
      p.y += (Math.cos(p.phase * 0.8) * 0.8 - 0.2) * dt;
      p.color = p.z > 0.5 ? '#67e8f9' : '#fef08a'; // cyan & gold firefly specks
      p.alpha = (p.baseAlpha * 1.4) * (0.3 + Math.pow(Math.sin(p.phase * 1.2), 2) * 0.7);
    }

    // Wrap around screen boundaries seamlessly
    if (p.x < -40) {
      p.x = w + Math.random() * 30;
      p.y = Math.random() * h;
    } else if (p.x > w + 60) {
      p.x = -20;
      p.y = Math.random() * h;
    }
    if (p.y < horizonY - 40) {
      p.y = h + 10;
    } else if (p.y > h + 30) {
      p.y = horizonY + Math.random() * (h - horizonY);
    }
  }
};

// 1. Draw Sky Gradient matching current weather
export const drawWeatherSky = (
  ctx: CanvasRenderingContext2D,
  weather: WeatherType,
  w: number,
  horizonY: number
) => {
  const config = WEATHER_PRESETS[weather];
  const skyGrad = ctx.createLinearGradient(0, 0, 0, horizonY);
  skyGrad.addColorStop(0, config.skyColors[0]);
  skyGrad.addColorStop(0.5, config.skyColors[1]);
  skyGrad.addColorStop(1, config.skyColors[2]);

  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, w, horizonY);

  return config.horizonSilhouetteColor;
};

// 2. Draw Sun, Blazing Rays (God Rays), and Heat Corona
export const drawSunAndRays = (
  ctx: CanvasRenderingContext2D,
  weather: WeatherType,
  w: number,
  h: number,
  horizonY: number,
  elapsedFrames: number
) => {
  const config = WEATHER_PRESETS[weather];
  if (weather === 'NIGHT_BREEZE') {
    // Night sky: Radiant crescent moon & twinkling stars
    const moonX = w / 2 - 80;
    const moonY = horizonY - 42;
    const moonRadius = 16;

    // Glowing halo
    const halo = ctx.createRadialGradient(moonX, moonY, 4, moonX, moonY, 45);
    halo.addColorStop(0, 'rgba(254, 240, 138, 0.45)');
    halo.addColorStop(0.6, 'rgba(253, 224, 71, 0.15)');
    halo.addColorStop(1, 'rgba(253, 224, 71, 0)');
    ctx.fillStyle = halo;
    ctx.beginPath();
    ctx.arc(moonX, moonY, 45, 0, Math.PI * 2);
    ctx.fill();

    // Golden Moon body
    ctx.save();
    ctx.beginPath();
    ctx.arc(moonX, moonY, moonRadius, 0, Math.PI * 2);
    ctx.fillStyle = '#fef08a';
    ctx.shadowBlur = 18;
    ctx.shadowColor = '#facc15';
    ctx.fill();
    ctx.shadowBlur = 0;

    // Crescent cutout
    ctx.beginPath();
    ctx.arc(moonX - 6, moonY - 1, moonRadius * 0.95, 0, Math.PI * 2);
    ctx.fillStyle = '#020617';
    ctx.fill();
    ctx.restore();

    // Twinkling Cairo night stars
    ctx.fillStyle = 'rgba(253, 224, 71, 0.85)';
    for (let i = 0; i < 22; i++) {
      const blink = Math.sin(elapsedFrames * 0.05 + i * 1.7) * 0.5 + 0.5;
      if (blink > 0.35) {
        const starX = ((i * 73.19 + 40) % (w - 30));
        const starY = ((i * 47.83 + 15) % (horizonY - 20));
        const starSize = (i % 3 === 0 ? 2.2 : 1.4) * blink;
        ctx.beginPath();
        ctx.arc(starX, starY, starSize, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    return;
  }

  // Daylight / Sunset Sun Position
  const sunX = weather === 'SUNNY_HEAT' ? w / 2 - 70 : weather === 'KHAMASEEN' ? w / 2 - 40 : w / 2 + 50;
  const sunY = weather === 'GOLDEN_ASR' ? horizonY - 24 : horizonY - 48;
  const sunRadius = weather === 'SUNNY_HEAT' ? 34 : weather === 'KHAMASEEN' ? 26 : 30;

  // 1. Grand Sun Corona Glow
  const coronaRadius = weather === 'SUNNY_HEAT' ? 120 : 80;
  const coronaGrad = ctx.createRadialGradient(sunX, sunY, sunRadius * 0.3, sunX, sunY, coronaRadius);
  if (weather === 'SUNNY_HEAT') {
    coronaGrad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
    coronaGrad.addColorStop(0.2, 'rgba(254, 240, 138, 0.7)');
    coronaGrad.addColorStop(0.5, 'rgba(251, 191, 36, 0.35)');
    coronaGrad.addColorStop(1, 'rgba(251, 191, 36, 0)');
  } else if (weather === 'KHAMASEEN') {
    // Dim dusty sun behind sand haze
    coronaGrad.addColorStop(0, 'rgba(254, 215, 170, 0.75)');
    coronaGrad.addColorStop(0.4, 'rgba(217, 119, 6, 0.4)');
    coronaGrad.addColorStop(1, 'rgba(217, 119, 6, 0)');
  } else {
    // Golden Asr sunset
    coronaGrad.addColorStop(0, 'rgba(254, 240, 138, 0.85)');
    coronaGrad.addColorStop(0.35, 'rgba(249, 115, 22, 0.5)');
    coronaGrad.addColorStop(1, 'rgba(234, 88, 12, 0)');
  }

  ctx.fillStyle = coronaGrad;
  ctx.beginPath();
  ctx.arc(sunX, sunY, coronaRadius, 0, Math.PI * 2);
  ctx.fill();

  // 2. Radiant God Rays (Crepuscular Beams) slicing diagonally across the alley
  if (config.sunRaysIntensity > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    const rayCount = weather === 'SUNNY_HEAT' ? 8 : 5;
    const baseAngle = Math.PI * 0.28; // Diagonal beam downwards across street
    const sweepAngle = Math.PI * 0.45;

    for (let r = 0; r < rayCount; r++) {
      const rayAngle = baseAngle + (r / (rayCount - 1)) * sweepAngle + Math.sin(elapsedFrames * 0.015 + r) * 0.03;
      const rayWidth = (0.08 + Math.sin(elapsedFrames * 0.02 + r * 1.5) * 0.02) * (weather === 'SUNNY_HEAT' ? 1.2 : 0.8);
      const rayLength = Math.max(w, h) * 1.4;

      const p1X = sunX + Math.cos(rayAngle - rayWidth) * rayLength;
      const p1Y = sunY + Math.sin(rayAngle - rayWidth) * rayLength;
      const p2X = sunX + Math.cos(rayAngle + rayWidth) * rayLength;
      const p2Y = sunY + Math.sin(rayAngle + rayWidth) * rayLength;

      const rayGrad = ctx.createRadialGradient(sunX, sunY, 15, sunX, sunY, rayLength * 0.8);
      const rayAlpha = (0.16 + Math.sin(elapsedFrames * 0.025 + r) * 0.06) * config.sunRaysIntensity;
      rayGrad.addColorStop(0, `rgba(254, 240, 138, ${rayAlpha * 1.5})`);
      rayGrad.addColorStop(0.4, `rgba(251, 191, 36, ${rayAlpha})`);
      rayGrad.addColorStop(1, 'rgba(251, 191, 36, 0)');

      ctx.fillStyle = rayGrad;
      ctx.beginPath();
      ctx.moveTo(sunX, sunY);
      ctx.lineTo(p1X, p1Y);
      ctx.lineTo(p2X, p2Y);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  }

  // 3. Central Core Sun Disc
  ctx.save();
  ctx.beginPath();
  ctx.arc(sunX, sunY, sunRadius, 0, Math.PI * 2);
  ctx.fillStyle = weather === 'SUNNY_HEAT' ? '#ffffff' : weather === 'KHAMASEEN' ? '#fed7aa' : '#fef08a';
  ctx.shadowBlur = weather === 'SUNNY_HEAT' ? 35 : 20;
  ctx.shadowColor = weather === 'SUNNY_HEAT' ? '#fef08a' : '#ea580c';
  ctx.fill();
  ctx.restore();

  // Subtle clouds drifting across sky
  if (weather === 'SUNNY_HEAT') {
    drawFluffyCloud(ctx, ((elapsedFrames * 0.35) % (w + 140)) - 70, horizonY - 55, 1.15, 'rgba(255, 255, 255, 0.85)');
    drawFluffyCloud(ctx, (((elapsedFrames * 0.18) + w * 0.55) % (w + 140)) - 70, horizonY - 38, 0.9, 'rgba(255, 255, 255, 0.75)');
  } else if (weather === 'GOLDEN_ASR') {
    drawFluffyCloud(ctx, ((elapsedFrames * 0.22) % (w + 140)) - 70, horizonY - 45, 1.25, 'rgba(254, 215, 170, 0.55)');
  }
};

const drawFluffyCloud = (
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  sz: number,
  fillColor: string
) => {
  ctx.fillStyle = fillColor;
  ctx.beginPath();
  ctx.arc(cx, cy, 14 * sz, 0, Math.PI * 2);
  ctx.arc(cx + 12 * sz, cy - 7 * sz, 11 * sz, 0, Math.PI * 2);
  ctx.arc(cx + 24 * sz, cy, 13 * sz, 0, Math.PI * 2);
  ctx.closePath();
  ctx.fill();
};

// 3. Egyptian Pigeons Flock (حمام بلدي قاهري) flying across the golden sky during Asr
export const drawEgyptianPigeons = (
  ctx: CanvasRenderingContext2D,
  weather: WeatherType,
  w: number,
  horizonY: number,
  elapsedFrames: number
) => {
  if (weather !== 'GOLDEN_ASR') return;

  ctx.save();
  ctx.fillStyle = '#431407'; // Deep silhouette brown

  const baseFlockX = ((elapsedFrames * 1.4) % (w + 240)) - 120;
  const baseFlockY = horizonY - 55;

  const pigeons = [
    { dx: 0, dy: 0, scale: 1.0, wingOffset: 0 },
    { dx: -24, dy: 10, scale: 0.85, wingOffset: 0.8 },
    { dx: -45, dy: 22, scale: 0.75, wingOffset: 1.6 },
    { dx: -28, dy: -12, scale: 0.8, wingOffset: 0.4 },
    { dx: -54, dy: -6, scale: 0.7, wingOffset: 1.2 },
    { dx: -75, dy: 14, scale: 0.65, wingOffset: 2.0 },
  ];

  pigeons.forEach((p) => {
    const px = baseFlockX + p.dx;
    const py = baseFlockY + p.dy + Math.sin(elapsedFrames * 0.04 + p.wingOffset) * 4;

    if (px < -30 || px > w + 30) return;

    const wingFlap = Math.sin(elapsedFrames * 0.28 + p.wingOffset);
    const wingY = wingFlap * 6 * p.scale;

    ctx.save();
    ctx.translate(px, py);
    ctx.scale(p.scale, p.scale);

    // Pigeon silhouette wings (classic V-flap)
    ctx.beginPath();
    ctx.moveTo(0, 0); // body center
    ctx.quadraticCurveTo(-7, -4 - wingY, -14, -1 - wingY * 1.2); // left wing
    ctx.quadraticCurveTo(-6, 2 - wingY * 0.5, 0, 1);
    ctx.quadraticCurveTo(7, -4 - wingY, 14, -1 - wingY * 1.2); // right wing
    ctx.quadraticCurveTo(6, 2 - wingY * 0.5, 0, 0);
    ctx.fill();

    // Tiny head
    ctx.beginPath();
    ctx.arc(0, -3, 2, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  });

  ctx.restore();
};

// 4. Heat Shimmer / Mirage on Road (سراب الحرارة على الطريق)
export const drawHeatShimmer = (
  ctx: CanvasRenderingContext2D,
  weather: WeatherType,
  w: number,
  horizonY: number,
  elapsedFrames: number
) => {
  const config = WEATHER_PRESETS[weather];
  if (config.heatWaveIntensity <= 0) return;

  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  const intensity = config.heatWaveIntensity;

  // Draw 3 shimmering heat mirage bands undulating right above the cobblestones
  for (let b = 0; b < 3; b++) {
    const bandY = horizonY + 12 + b * 16;
    const waveOffset = elapsedFrames * (0.08 + b * 0.03);
    const alpha = (0.12 - b * 0.03) * intensity;

    ctx.strokeStyle = `rgba(254, 240, 138, ${alpha})`;
    ctx.lineWidth = 3.5 - b * 0.8;
    ctx.beginPath();

    for (let x = 0; x <= w; x += 15) {
      const waveY = bandY + Math.sin(x * 0.03 + waveOffset) * (3.5 - b * 0.8);
      if (x === 0) ctx.moveTo(x, waveY);
      else ctx.lineTo(x, waveY);
    }
    ctx.stroke();
  }

  ctx.restore();
};

// 5. Desert Dust Wisps blowing horizontally across the street floor during Khamaseen
export const drawKhamaseenSandWisps = (
  ctx: CanvasRenderingContext2D,
  weather: WeatherType,
  w: number,
  h: number,
  horizonY: number,
  elapsedFrames: number
) => {
  if (weather !== 'KHAMASEEN') return;

  ctx.save();
  ctx.globalCompositeOperation = 'screen';

  // 4 blowing sand streaks speeding along the street floor
  for (let s = 0; s < 4; s++) {
    const speed = 7.5 + s * 2.8;
    const wispLength = 120 + s * 45;
    const wispX = ((w + 200) - ((elapsedFrames * speed + s * 160) % (w + 400))) - 100;
    const wispY = horizonY + 30 + s * ((h - horizonY - 60) / 4) + Math.sin(elapsedFrames * 0.06 + s) * 8;

    const wispGrad = ctx.createLinearGradient(wispX, wispY, wispX + wispLength, wispY);
    wispGrad.addColorStop(0, 'rgba(217, 119, 6, 0)');
    wispGrad.addColorStop(0.3, 'rgba(245, 158, 11, 0.22)');
    wispGrad.addColorStop(0.7, 'rgba(254, 215, 170, 0.35)');
    wispGrad.addColorStop(1, 'rgba(217, 119, 6, 0)');

    ctx.fillStyle = wispGrad;
    ctx.beginPath();
    ctx.ellipse(wispX + wispLength / 2, wispY, wispLength / 2, 4 + s * 1.5, -0.05, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
};

// 6. Draw Weather Particles (Sand dust, fireflies, sparkling sun motes)
export const drawWeatherParticles = (
  ctx: CanvasRenderingContext2D,
  particles: WeatherParticle[],
  weather: WeatherType,
  elapsedFrames: number
) => {
  if (particles.length === 0) return;

  ctx.save();

  if (weather === 'NIGHT_BREEZE' || weather === 'SUNNY_HEAT') {
    ctx.globalCompositeOperation = 'screen';
  }

  for (let i = 0; i < particles.length; i++) {
    const p = particles[i];
    if (p.alpha <= 0.01) continue;

    ctx.fillStyle = p.color;
    ctx.globalAlpha = Math.max(0, Math.min(1, p.alpha));

    if (weather === 'KHAMASEEN') {
      // Sand grains: elongated micro-streaks due to fast horizontal wind speed
      ctx.beginPath();
      ctx.ellipse(p.x, p.y, p.size * 2.2, p.size * 0.8, -0.15, 0, Math.PI * 2);
      ctx.fill();
    } else if (weather === 'NIGHT_BREEZE') {
      // Fireflies: soft glowing halo orb
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * 1.3, 0, Math.PI * 2);
      ctx.fill();

      // Outer glow ring for large fireflies
      if (p.size > 2.5) {
        ctx.globalAlpha = p.alpha * 0.35;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * 3.2, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      // Sunny & Asr: sparkling circular sun motes
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.restore();
};

// 7. Full Atmosphere Color Tint & Vignette
export const drawWeatherAtmosphere = (
  ctx: CanvasRenderingContext2D,
  weather: WeatherType,
  w: number,
  h: number,
  horizonY: number
) => {
  const config = WEATHER_PRESETS[weather];

  ctx.save();
  // Subtle atmospheric wash over the scene
  const atmosGrad = ctx.createLinearGradient(0, horizonY - 40, 0, h);
  atmosGrad.addColorStop(0, `rgba(${config.hazeColor}, ${config.hazeOpacity * 1.4})`);
  atmosGrad.addColorStop(0.5, `rgba(${config.hazeColor}, ${config.hazeOpacity * 0.8})`);
  atmosGrad.addColorStop(1, `rgba(${config.hazeColor}, ${config.hazeOpacity * 1.1})`);

  ctx.fillStyle = atmosGrad;
  ctx.fillRect(0, 0, w, h);

  // For Khamaseen: warm sand vignette at edges
  if (weather === 'KHAMASEEN') {
    const vigGrad = ctx.createRadialGradient(w / 2, h / 2, w * 0.35, w / 2, h / 2, w * 0.85);
    vigGrad.addColorStop(0, 'rgba(217, 119, 6, 0)');
    vigGrad.addColorStop(1, 'rgba(180, 83, 9, 0.18)');
    ctx.fillStyle = vigGrad;
    ctx.fillRect(0, 0, w, h);
  }

  ctx.restore();
};
