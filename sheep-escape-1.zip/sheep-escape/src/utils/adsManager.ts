/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Comprehensive Ads & Daily Limits Manager for "هروب خروف العيد"
 */

import { getTodayDateString, isEgyptianEidActive } from './eidCalendar';

export type AdPlacement = 
  | 'FREE_BALLOON'       // Shop: Free Eid Balloon (limit 10/day)
  | 'LUCKY_BOX'          // Shop: Lucky Box (limit 2/day)
  | 'DOUBLE_HARVEST'     // Game Over: 2x Clovers
  | 'REVIVE_RUN'         // Game Board: 5s Quick Escape Revive
  | 'EID_BUNDLE';        // Shop: Eid Bundle (if allowed via ad/purchase)

export interface DailyAdLimits {
  date: string;
  cloverBalloonBought: boolean; // Limit: 1 per day
  adBalloonsWatched: number;    // Limit: 10 per day
  eidBundleBought: number;      // Limit: 2 per day (only during Eid)
  luckyBoxesOpened: number;     // Limit: 2 per day
}

const STORAGE_KEY = 'sheep_ads_daily_limits_v1';

export const DAILY_LIMITS = {
  CLOVER_BALLOON_MAX: 1,
  AD_BALLOONS_MAX: 10,
  EID_BUNDLE_MAX: 2,
  LUCKY_BOX_MAX: 2,
};

/**
 * Loads daily limits and automatically resets counters if date has changed (24h midnight reset)
 */
export function getDailyAdLimits(): DailyAdLimits {
  const today = getTodayDateString();
  const defaultLimits: DailyAdLimits = {
    date: today,
    cloverBalloonBought: false,
    adBalloonsWatched: 0,
    eidBundleBought: 0,
    luckyBoxesOpened: 0,
  };

  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return defaultLimits;
    }

    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveDailyAdLimits(defaultLimits);
      return defaultLimits;
    }

    const parsed: DailyAdLimits = JSON.parse(raw);

    // If stored date is not today, midnight has passed -> reset counters
    if (parsed.date !== today) {
      saveDailyAdLimits(defaultLimits);
      return defaultLimits;
    }

    return {
      date: today,
      cloverBalloonBought: Boolean(parsed.cloverBalloonBought),
      adBalloonsWatched: Number(parsed.adBalloonsWatched || 0),
      eidBundleBought: Number(parsed.eidBundleBought || 0),
      luckyBoxesOpened: Number(parsed.luckyBoxesOpened || 0),
    };
  } catch (err) {
    return defaultLimits;
  }
}

/**
 * Persists daily ad limits to localStorage
 */
export function saveDailyAdLimits(limits: DailyAdLimits): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(limits));
    }
  } catch (err) {}
}

/**
 * Records purchase of single balloon with clovers (limit 1/day)
 */
export function recordCloverBalloonPurchase(): boolean {
  const limits = getDailyAdLimits();
  if (limits.cloverBalloonBought) return false;
  limits.cloverBalloonBought = true;
  saveDailyAdLimits(limits);
  return true;
}

/**
 * Checks if clover balloon can be purchased today
 */
export function canBuyCloverBalloonToday(): boolean {
  const limits = getDailyAdLimits();
  return !limits.cloverBalloonBought;
}

/**
 * Records an ad watch for free balloon (limit 10/day)
 */
export function recordAdBalloonWatched(): { success: boolean; count: number; remaining: number } {
  const limits = getDailyAdLimits();
  if (limits.adBalloonsWatched >= DAILY_LIMITS.AD_BALLOONS_MAX) {
    return { success: false, count: limits.adBalloonsWatched, remaining: 0 };
  }
  limits.adBalloonsWatched += 1;
  saveDailyAdLimits(limits);
  return {
    success: true,
    count: limits.adBalloonsWatched,
    remaining: DAILY_LIMITS.AD_BALLOONS_MAX - limits.adBalloonsWatched,
  };
}

/**
 * Checks how many ad balloons remain today
 */
export function getRemainingAdBalloons(): { watched: number; remaining: number; canWatch: boolean } {
  const limits = getDailyAdLimits();
  const remaining = Math.max(0, DAILY_LIMITS.AD_BALLOONS_MAX - limits.adBalloonsWatched);
  return {
    watched: limits.adBalloonsWatched,
    remaining,
    canWatch: remaining > 0,
  };
}

/**
 * Records lucky box opened via ad (limit 2/day)
 */
export function recordLuckyBoxOpened(): { success: boolean; count: number; remaining: number } {
  const limits = getDailyAdLimits();
  if (limits.luckyBoxesOpened >= DAILY_LIMITS.LUCKY_BOX_MAX) {
    return { success: false, count: limits.luckyBoxesOpened, remaining: 0 };
  }
  limits.luckyBoxesOpened += 1;
  saveDailyAdLimits(limits);
  return {
    success: true,
    count: limits.luckyBoxesOpened,
    remaining: DAILY_LIMITS.LUCKY_BOX_MAX - limits.luckyBoxesOpened,
  };
}

/**
 * Checks if lucky box can be opened today
 */
export function getRemainingLuckyBoxes(): { opened: number; remaining: number; canOpen: boolean } {
  const limits = getDailyAdLimits();
  const remaining = Math.max(0, DAILY_LIMITS.LUCKY_BOX_MAX - limits.luckyBoxesOpened);
  return {
    opened: limits.luckyBoxesOpened,
    remaining,
    canOpen: remaining > 0,
  };
}

/**
 * Records purchase of Eid 3-balloons bundle (limit 2/day during Eid holidays)
 */
export function recordEidBundlePurchase(): { success: boolean; count: number; remaining: number } {
  if (!isEgyptianEidActive()) {
    return { success: false, count: 0, remaining: 0 };
  }
  const limits = getDailyAdLimits();
  if (limits.eidBundleBought >= DAILY_LIMITS.EID_BUNDLE_MAX) {
    return { success: false, count: limits.eidBundleBought, remaining: 0 };
  }
  limits.eidBundleBought += 1;
  saveDailyAdLimits(limits);
  return {
    success: true,
    count: limits.eidBundleBought,
    remaining: DAILY_LIMITS.EID_BUNDLE_MAX - limits.eidBundleBought,
  };
}

/**
 * Checks if Eid 3-balloons bundle is eligible today
 */
export function getEidBundleStatus(): { isEidActive: boolean; count: number; remaining: number; canBuy: boolean } {
  const isEidActive = isEgyptianEidActive();
  const limits = getDailyAdLimits();
  const remaining = Math.max(0, DAILY_LIMITS.EID_BUNDLE_MAX - limits.eidBundleBought);
  return {
    isEidActive,
    count: limits.eidBundleBought,
    remaining,
    canBuy: isEidActive && remaining > 0,
  };
}
