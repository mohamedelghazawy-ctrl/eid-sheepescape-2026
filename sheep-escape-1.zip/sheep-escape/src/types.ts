/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum GameState {
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  PAUSED = 'PAUSED',
  GAME_OVER = 'GAME_OVER',
  SHOP = 'SHOP',
  TUTORIAL = 'TUTORIAL'
}

export type LaneType = 0 | 1 | 2; // Left (0), Middle (1), Right (2)

export type ControlMode = 'buttons' | 'swipe';

export interface SheepOutfit {
  id: string;
  name: string;
  arabicName: string;
  price: number;
  unlocked: boolean;
  color: string;
  accessoryEmoji: string;
  description: string;
  bonus?: string;
}

export interface PlayerState {
  lane: LaneType;
  targetX: number;
  currentX: number;
  y: number; // 0 is ground level (closer to user), jumping goes up
  vy: number; // Jump velocity
  isJumping: boolean;
  isDucking: boolean;
  duckProgress: number; // For duck sliding animation
  activeOutfit: string;
  cloversCollected: number;
  score: number;
  distance: number;
  butcherDistance: number; // 0 = caught, 100 = far, starting at 70
  warningFlash: boolean;
  extraLifeUsed: boolean;
  boxerShieldUsed?: boolean; // خروف الملاكم تايسون: تدمير عقبة واحدة
  canDoubleJump?: boolean;   // خروف كابتن الملاعب: القفز المزدوج
}

export interface PowerUp {
  type?: 'MAGNET' | 'BOOST' | 'SHIELD' | 'CORN_BOOST' | 'NITRO';
  durationLeft: number; // in frames or ms
  maxDuration: number;
}

export type ObstacleType = 
  | 'TUKTUK'        // Medium height, cannot jump easily, must switch lane
  | 'VEG_CART'      // Slide under or switch lane
  | 'BARRIER'       // High or Low jump barrier
  | 'FOUL_POT'      // Jump over
  | 'CLOTHESLINE'   // Low hanger, must Slide under
  | 'WATERMELON';   // Small hurdle, jump over

export interface GameObstacle {
  id: number;
  type: ObstacleType;
  lane: LaneType;
  z: number; // Depth coordinate (starts at 1000 at the horizon, reaches 0 near screen)
  xOffset: number; // Slight decorative offset from center of lane
  scraped: boolean; // Flag if player already hit this once but didn't die
}

export type CollectibleType = 'CLOVER' | 'CORN' | 'MAGNET' | 'NITRO' | 'FATTA_SHIELD' | 'GOLDEN_CLOVER';

export interface GameCoin {
  id: number;
  lane: LaneType;
  z: number; // Depth coordinate
  y: number; // Floating height
  type: CollectibleType;
}

export interface DailyChallenge {
  id: string;
  title: string;
  type: 'distance' | 'avoid_streak' | 'collect_clovers' | 'collect_corn' | 'collect_magnets' | 'score';
  target: number;
  rewardClovers: number;
  progress: number;
  completed: boolean;
}

export interface Particle {
  x: number;
  y: number;
  color: string;
  vx: number;
  vy: number;
  size: number;
  life: number;
  maxLife: number;
  shape?: 'circle' | 'leaf' | 'star' | 'ring';
  rotation?: number;
  vRot?: number;
  gravity?: number;
  drag?: number;
}

export interface DecorativeAsset {
  id: number;
  type: 'FANOOS' | 'BALCONY' | 'DOME' | 'TREE' | 'STREET_LIGHT' | 'BANNER';
  side: 'left' | 'right';
  z: number;
  scale: number;
  variety: number;
}

export type WeatherType = 'SUNNY_HEAT' | 'KHAMASEEN' | 'GOLDEN_ASR' | 'NIGHT_BREEZE';

export interface WeatherParticle {
  x: number;
  y: number;
  z: number;
  size: number;
  vx: number;
  vy: number;
  alpha: number;
  baseAlpha: number;
  color: string;
  wobbleSpeed: number;
  wobbleAmp: number;
  phase: number;
}
