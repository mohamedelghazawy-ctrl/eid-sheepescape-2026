/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { GameState, DailyChallenge, ControlMode } from './types';
import GameBoard from './components/GameBoard';
import MainMenu from './components/MainMenu';
import Shop from './components/Shop';
import GameOverCutscene from './components/GameOverCutscene';
import OfflineOverlay from './components/OfflineOverlay';
import RewardedAdModal from './components/RewardedAdModal';
import { gameSounds } from './components/SoundManager';
import { GAME_OVER_QUOTES, INITIAL_CHALLENGES } from './utils/gameData';
import { isConnected, isNativeApp } from './utils/connection';
import { APP_CONFIG } from './config';

function safeGetItem(key: string, fallback: string = ''): string {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage.getItem(key) ?? fallback;
    }
  } catch (e) {}
  return fallback;
}

function safeSetItem(key: string, value: string): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, value);
    }
  } catch (e) {}
}

export default function App() {
  const [gameState, setGameState] = useState<GameState>(GameState.MENU);
  const gameStateRef = useRef(gameState);

  useEffect(() => {
    gameStateRef.current = gameState;
  }, [gameState]);
  
  // Persistent metrics
  const [highScore, setHighScore] = useState<number>(() => {
    return Number(safeGetItem('sheep_game_highscore', '0'));
  });
  const [maxDistance, setMaxDistance] = useState<number>(() => {
    return Number(safeGetItem('sheep_game_maxdist', '0'));
  });
  const [cloversTotal, setCloversTotal] = useState<number>(() => {
    return Number(safeGetItem('sheep_game_clovers_total', '15')); // starts with 15 free clovers for quick fun!
  });
  
  // Control Mode state: 'buttons' (أسهم الشاشة) or 'swipe' (السحب Touch Swipe)
  const [controlMode, setControlMode] = useState<ControlMode>(() => {
    return (safeGetItem('sheep_game_control_mode', 'buttons') as ControlMode) || 'buttons';
  });

  useEffect(() => {
    safeSetItem('sheep_game_control_mode', controlMode);
  }, [controlMode]);

  // Store unlocked skins (outfit ids)
  const [unlockedOutfits, setUnlockedOutfits] = useState<string[]>(() => {
    try {
      const stored = safeGetItem('sheep_game_outfits');
      return stored ? JSON.parse(stored) : ['default'];
    } catch {
      return ['default'];
    }
  });

  const [activeOutfitId, setActiveOutfitId] = useState<string>(() => {
    return safeGetItem('sheep_game_active_outfit', 'default') || 'default';
  });

  // Upgrades
  const [magnetLevel, setMagnetLevel] = useState<number>(() => {
    return Number(safeGetItem('sheep_game_magnet_lvl', '1'));
  });
  const [cornLevel, setCornLevel] = useState<number>(() => {
    return Number(safeGetItem('sheep_game_corn_lvl', '1'));
  });
  const [shieldLevel, setShieldLevel] = useState<number>(() => {
    return Number(safeGetItem('sheep_game_shield_lvl', '1'));
  });
  const [fattaLevel, setFattaLevel] = useState<number>(() => {
    return Number(safeGetItem('sheep_game_fatta_lvl', '1'));
  });
  const [goldenCloverLevel, setGoldenCloverLevel] = useState<number>(() => {
    return Number(safeGetItem('sheep_game_golden_clover_lvl', '1'));
  });

  // بالونات العيد (Extra Life Hearts)
  const [eidBalloons, setEidBalloons] = useState<number>(() => {
    return Number(safeGetItem('sheep_game_eid_balloons', '1'));
  });

  // Active running round scores
  const [currentScore, setCurrentScore] = useState(0);
  const [currentDistance, setCurrentDistance] = useState(0);
  const [cloversCollectedThisRound, setCloversCollectedThisRound] = useState(0);
  const [lastRoundBonusClovers, setLastRoundBonusClovers] = useState(0);
  const [hasDoubledClovers, setHasDoubledClovers] = useState(false);
  const [showDoubleCloversAd, setShowDoubleCloversAd] = useState(false);

  const [isMuted, setIsMuted] = useState(() => gameSounds.getMuted());
  const [gameOverQuote, setGameOverQuote] = useState('');
  const [isShaking, setIsShaking] = useState(false);

  // Trigger shake animation for physical impacts
  const handleObstacleCollision = () => {
    setIsShaking(true);
  };

  useEffect(() => {
    if (isShaking) {
      const timer = setTimeout(() => {
        setIsShaking(false);
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [isShaking]);

  // 🎯 DAILY CHALLENGES STATE
  const [challenges, setChallenges] = useState<DailyChallenge[]>(() => {
    try {
      const stored = safeGetItem('sheep_game_challenges_v1');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {}
    return INITIAL_CHALLENGES.map(ch => ({
      ...ch,
      progress: 0,
      completed: false
    }));
  });

  const [activeToast, setActiveToast] = useState<{ id: number; title: string; reward: number } | null>(null);
  const toastIdCounterRef = useRef(0);

  // State for delayed Game Over modal appearance after Basyouni tying animation
  const [showGameOverModal, setShowGameOverModal] = useState(false);
  const [isEscapingWithBalloons, setIsEscapingWithBalloons] = useState(false);
  const [resumedWithBalloons, setResumedWithBalloons] = useState(false);
  const [gameSessionId, setGameSessionId] = useState(1);

  // Handle Game Over cutscene sequence: hide all windows for 2.8 seconds, then reveal modal
  useEffect(() => {
    if (gameState === GameState.GAME_OVER) {
      setIsEscapingWithBalloons(false);
      setResumedWithBalloons(false);
      setShowGameOverModal(false);
      const timer = setTimeout(() => {
        setShowGameOverModal(true);
      }, 2800); // 2.8s duration
      return () => clearTimeout(timer);
    } else {
      setShowGameOverModal(false);
    }
  }, [gameState]);

  // Persist challenges updates
  useEffect(() => {
    safeSetItem('sheep_game_challenges_v1', JSON.stringify(challenges));
  }, [challenges]);

  const triggerChallengeToast = (title: string, reward: number) => {
    toastIdCounterRef.current++;
    const currentToastId = toastIdCounterRef.current;
    setActiveToast({ id: currentToastId, title, reward });

    // Synthesized cute game completion sound
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      
      osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
      osc.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.12); // E5
      osc.frequency.setValueAtTime(783.99, audioCtx.currentTime + 0.24); // G5
      osc.frequency.setValueAtTime(1046.50, audioCtx.currentTime + 0.36); // C6
      
      gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.7);
      
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.75);
    } catch (e) {}

    setTimeout(() => {
      setActiveToast(prev => prev?.id === currentToastId ? null : prev);
    }, 4000);
  };

  const handleChallengeProgress = (id: string, progress: number) => {
    setChallenges(prev => prev.map(ch => {
      if (ch.id === id && !ch.completed) {
        return { ...ch, progress: Math.min(ch.target, progress) };
      }
      return ch;
    }));
  };

  const handleChallengeCompleted = (id: string, reward: number, title: string) => {
    setChallenges(prev => {
      const existsCompleted = prev.some(ch => ch.id === id && ch.completed);
      if (existsCompleted) return prev; // Avoid double triggering
      
      // Update states and trigger toast
      triggerChallengeToast(title, reward);
      
      // Add Clover to database wallet ledger
      setTimeout(() => {
        addClovers(reward);
      }, 50);

      return prev.map(ch => ch.id === id ? { ...ch, completed: true, progress: ch.target } : ch);
    });
  };

  // Re-generate challenges progression for infinite play!
  const handleResetChallenges = () => {
    setChallenges(INITIAL_CHALLENGES.map(ch => ({
      ...ch,
      progress: 0,
      completed: false
    })));
  };

  // Persist outfits updates
  useEffect(() => {
    safeSetItem('sheep_game_outfits', JSON.stringify(unlockedOutfits));
  }, [unlockedOutfits]);

  useEffect(() => {
    safeSetItem('sheep_game_active_outfit', activeOutfitId);
  }, [activeOutfitId]);

  // Persist Upgrades
  useEffect(() => {
    safeSetItem('sheep_game_magnet_lvl', String(magnetLevel));
  }, [magnetLevel]);

  useEffect(() => {
    safeSetItem('sheep_game_corn_lvl', String(cornLevel));
  }, [cornLevel]);

  useEffect(() => {
    safeSetItem('sheep_game_shield_lvl', String(shieldLevel));
  }, [shieldLevel]);

  useEffect(() => {
    safeSetItem('sheep_game_fatta_lvl', String(fattaLevel));
  }, [fattaLevel]);

  useEffect(() => {
    safeSetItem('sheep_game_golden_clover_lvl', String(goldenCloverLevel));
  }, [goldenCloverLevel]);

  useEffect(() => {
    safeSetItem('sheep_game_eid_balloons', String(eidBalloons));
  }, [eidBalloons]);

  // مراقبة الاتصال باستمرار أثناء اللعب
  useEffect(() => {
    // اللعبة تعمل بدون إنترنت: لا مراقبة للشبكة إلا لو فُعّل REQUIRE_INTERNET في config.ts
    if (!APP_CONFIG.REQUIRE_INTERNET) return;
    function checkConnectionAndPause() {
      if (!isConnected()) {
        // إيقاف حركة اللعبة أو إظهار واجهة الأوفلاين الكرتونية فوراً
        if (typeof (window as any).freezeGameMovement === 'function') {
          (window as any).freezeGameMovement();
        }
        if (typeof (window as any).showOfflineOverlay === 'function') {
          (window as any).showOfflineOverlay();
        } else {
          var overlay = document.getElementById('offline-overlay');
          if (overlay) overlay.style.display = 'flex';
        }
      }
    }

    (window as any).checkConnectionAndPause = checkConnectionAndPause;

    // تشغيل الفحص التلقائي كل ثانيتين أثناء اللعب
    var connectionInterval = setInterval(checkConnectionAndPause, 2000);

    // الاستجابة اللحظية لتغير حالة الشبكة
    var handleOfflineEvent = function() {
      checkConnectionAndPause();
    };
    window.addEventListener('offline', handleOfflineEvent);

    return () => {
      clearInterval(connectionInterval);
      window.removeEventListener('offline', handleOfflineEvent);
    };
  }, []);

  // Handle game mute toggle
  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    gameSounds.setMute(nextMuted);
  };

  // Upgrades functions
  const handleLevelUpMagnet = () => {
    setMagnetLevel(prev => Math.min(5, prev + 1));
  };

  const handleLevelUpCorn = () => {
    setCornLevel(prev => Math.min(5, prev + 1));
  };

  const handleLevelUpShield = () => {
    setShieldLevel(prev => Math.min(5, prev + 1));
  };

  const handleLevelUpGoldenClover = () => {
    setGoldenCloverLevel(prev => Math.min(5, prev + 1));
  };

  const addEidBalloons = (count: number) => {
    setEidBalloons(prev => {
      const next = prev + count;
      safeSetItem('sheep_game_eid_balloons', String(next));
      return next;
    });
  };

  const useEidBalloon = (): boolean => {
    if (eidBalloons > 0) {
      setEidBalloons(prev => {
        const next = Math.max(0, prev - 1);
        safeSetItem('sheep_game_eid_balloons', String(next));
        return next;
      });
      return true;
    }
    return false;
  };

  // Deduct/Add clovers total ledger
  const subClovers = (amount: number) => {
    setCloversTotal(prev => {
      const next = prev - amount;
      safeSetItem('sheep_game_clovers_total', String(next));
      return next;
    });
  };

  const addClovers = (amount: number) => {
    setCloversTotal(prev => {
      const next = prev + amount;
      safeSetItem('sheep_game_clovers_total', String(next));
      return next;
    });
  };

  const updateScoreAndDistance = (score: number, distance: number) => {
    setCurrentScore(score);
    setCurrentDistance(distance);
  };

  // Triggers when sheep is caught by butcher
  const handleGameOver = (finalScore: number, finalClovers: number) => {
    // Check Malem Baladi bonus (+25% clovers)
    let bonus = 0;
    if (activeOutfitId === 'mallem_baladi' && finalClovers > 0) {
      bonus = Math.ceil(finalClovers * 0.25);
    }
    setLastRoundBonusClovers(bonus);

    // Add gained clovers back to reserve ledger
    addClovers(finalClovers + bonus);
    
    if (bonus > 0) {
      triggerChallengeToast(`بونص المعلم البلدية: +${bonus} 🍀 إضافية! 🧣💰`, bonus);
    }

    // Choose funny Egyptian game over quote
    const randIdx = Math.floor(Math.random() * GAME_OVER_QUOTES.length);
    setGameOverQuote(GAME_OVER_QUOTES[randIdx]);

    // Check high scores
    if (finalScore > highScore) {
      setHighScore(finalScore);
      safeSetItem('sheep_game_highscore', String(finalScore));
    }

    if (currentDistance > maxDistance) {
      setMaxDistance(currentDistance);
      safeSetItem('sheep_game_maxdist', String(currentDistance));
    }

    // Play sad pitch or sheep bleat and butcher victory shout
    gameSounds.playBaa();
    gameSounds.playButcherShout();
    setShowGameOverModal(false);
    setHasDoubledClovers(false);
    setShowDoubleCloversAd(false);
  };

  const handleDoubleCloversGranted = () => {
    const extra = cloversCollectedThisRound;
    setCloversTotal((prev) => {
      const updated = prev + extra;
      safeSetItem('sheep_game_clovers_total', String(updated));
      return updated;
    });
    setHasDoubledClovers(true);
    setShowDoubleCloversAd(false);
    gameSounds.playGoldenClover();
    triggerChallengeToast(`مبروك! ضاعفت برسيم الجولة بنجاح! (+${extra} 🍀) 🎉`, extra);
  };

  const handleResumeEscapeWithBalloons = () => {
    if (eidBalloons > 0) {
      useEidBalloon();
      setShowGameOverModal(false);
      setIsEscapingWithBalloons(true);
    } else if (cloversTotal >= 60) {
      subClovers(60);
      triggerChallengeToast("تم شراء بالونة العيد واستكمال الهروب فوراً! 🎈✨", 60);
      setShowGameOverModal(false);
      setIsEscapingWithBalloons(true);
    } else {
      triggerChallengeToast("تحتاج إلى بالونة أو 60 🍀 على الأقل لاستكمال الهروب بالبالونات! 🍀", 0);
    }
  };

  const handleEscapeComplete = () => {
    setIsEscapingWithBalloons(false);
    setResumedWithBalloons(true);
    setGameState(GameState.PLAYING);
    gameSounds.playBalloonRevive();
    gameSounds.playBaa();
  };

  const handleStartGame = (targetState: GameState) => {
    if (!isConnected()) {
      if (typeof (window as any).showOfflineOverlay === 'function') {
        (window as any).showOfflineOverlay();
      }
      window.dispatchEvent(new Event('offline'));
      return;
    }
    if (targetState === GameState.PLAYING) {
      setResumedWithBalloons(false);
      setIsEscapingWithBalloons(false);
      setCurrentScore(0);
      setCurrentDistance(0);
      setCloversCollectedThisRound(0);
      setGameSessionId(prev => prev + 1);
    }
    setGameState(targetState);
  };

  const restartGame = () => {
    if (!isConnected()) {
      if (typeof (window as any).showOfflineOverlay === 'function') {
        (window as any).showOfflineOverlay();
      }
      window.dispatchEvent(new Event('offline'));
      return;
    }
    setResumedWithBalloons(false);
    setIsEscapingWithBalloons(false);
    setCurrentScore(0);
    setCurrentDistance(0);
    setCloversCollectedThisRound(0);
    setGameSessionId(prev => prev + 1);
    setGameState(GameState.PLAYING);
    // Play cheerful initial escape start bleat "Baaa!"
    gameSounds.playBaa();
  };

  const exitToMenu = () => {
    setResumedWithBalloons(false);
    setIsEscapingWithBalloons(false);
    setCurrentScore(0);
    setCurrentDistance(0);
    setCloversCollectedThisRound(0);
    setGameSessionId(prev => prev + 1);
    setGameState(GameState.MENU);
  };

  // ---------------------------------------------------------------
  // سلوك التطبيق على الأندرويد:
  //  • زر الرجوع: أثناء اللعب = إيقاف مؤقت، من أي شاشة فرعية = القائمة،
  //    ومن القائمة = ضغطتان متتاليتان للخروج (بدل الإغلاق المفاجئ).
  //  • إيقاف مؤقت تلقائي (وإيقاف الموسيقى) عند الانتقال لتطبيق آخر أو قفل الشاشة.
  // ---------------------------------------------------------------
  const [exitHint, setExitHint] = useState(false);
  const lastBackPressRef = useRef(0);

  useEffect(() => {
    const pauseIfPlaying = () => {
      if (gameStateRef.current === GameState.PLAYING) {
        setGameState(GameState.PAUSED);
      }
    };
    const onVisibility = () => {
      if (document.hidden) pauseIfPlaying();
    };
    document.addEventListener('visibilitychange', onVisibility);

    let disposed = false;
    const removers: Array<() => void> = [];

    if (isNativeApp()) {
      import('@capacitor/app')
        .then(({ App: CapApp }) => {
          if (disposed) return;

          CapApp.addListener('backButton', () => {
            const gs = gameStateRef.current;
            if (gs === GameState.PLAYING) {
              setGameState(GameState.PAUSED);
              return;
            }
            if (gs === GameState.PAUSED) {
              setGameState(GameState.PLAYING);
              return;
            }
            if (gs !== GameState.MENU) {
              exitToMenu();
              return;
            }
            const now = Date.now();
            if (now - lastBackPressRef.current < 2000) {
              CapApp.exitApp();
              return;
            }
            lastBackPressRef.current = now;
            setExitHint(true);
            setTimeout(() => setExitHint(false), 2000);
          }).then((h) => (disposed ? h.remove() : removers.push(() => h.remove())));

          CapApp.addListener('appStateChange', ({ isActive }) => {
            if (!isActive) pauseIfPlaying();
          }).then((h) => (disposed ? h.remove() : removers.push(() => h.remove())));
        })
        .catch(() => {});
    }

    return () => {
      disposed = true;
      document.removeEventListener('visibilitychange', onVisibility);
      removers.forEach((rm) => rm());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div 
      id="game-universe-container" 
      className="fixed inset-0 w-full h-full bg-[#fdf2e9] flex justify-center items-center overflow-hidden select-none animate-fade-in"
    >
      {/* FULL VIEWPORT GAME CONTAINER */}
      <motion.div 
        id="full-game-viewport" 
        className="w-full h-full relative flex flex-col overflow-hidden"
        initial={{ opacity: 0 }}
        animate={isShaking ? {
          opacity: 1,
          x: [0, -12, 12, -10, 10, -6, 6, -3, 3, 0],
          y: [0, 8, -8, 6, -6, 4, -4, 2, -2, 0]
        } : {
          opacity: 1,
          x: 0,
          y: 0
        }}
        transition={isShaking ? {
          duration: 0.35,
          ease: "easeInOut"
        } : { duration: 0.3 }}
      >
        {/* INNER VIEWPORTS CONTAINER WITH STATE MACHINE */}
        <div className="w-full h-full relative flex items-center justify-center overflow-hidden bg-[#fdf2e9]">
          
          {/* A. MENU SCREEN STATE */}
          {gameState === GameState.MENU && (
            <div className="w-full h-full flex items-center justify-center p-0 sm:p-4 bg-[#fdf2e9] overflow-hidden">
              <div className="w-full h-full max-w-md max-h-screen sm:max-h-[92vh] bg-white sm:rounded-3xl shadow-xl overflow-hidden flex flex-col border-0 sm:border-2 sm:border-orange-300">
                <MainMenu 
                  highScore={highScore}
                  maxDistance={maxDistance}
                  totalClovers={cloversTotal}
                  setGameState={handleStartGame}
                  isMuted={isMuted}
                  onToggleMute={handleToggleMute}
                  challenges={challenges}
                  onResetChallenges={handleResetChallenges}
                  controlMode={controlMode}
                  onControlModeChange={setControlMode}
                  onClaimDailyReward={(clovers, balloons) => {
                    addClovers(clovers);
                    if (balloons && balloons > 0) {
                      addEidBalloons(balloons);
                    }
                    triggerChallengeToast(`مكافأة الدخول اليومي: +${clovers} 🍀 ${balloons ? '+ 🎈 بالون' : ''}! 🔥`, clovers);
                  }}
                />
              </div>
            </div>
          )}

          {/* B. ACTIVE CODES RUNNING GAME SCREEN STATE - FULL SCREEN 100% CANVAS */}
          {(gameState === GameState.PLAYING || gameState === GameState.PAUSED) && (
            <div className="relative w-full h-full overflow-hidden">
              <GameBoard 
                key={gameSessionId}
                gameState={gameState}
                setGameState={setGameState}
                activeOutfitId={activeOutfitId}
                addClovers={addClovers}
                subClovers={subClovers}
                cloversTotal={cloversTotal}
                updateScoreAndDistance={updateScoreAndDistance}
                score={currentScore}
                distance={currentDistance}
                cloversCollected={cloversCollectedThisRound}
                setCloversCollected={setCloversCollectedThisRound}
                magnetLevel={magnetLevel}
                cornLevel={cornLevel}
                shieldLevel={shieldLevel}
                fattaLevel={fattaLevel}
                goldenCloverLevel={goldenCloverLevel}
                eidBalloons={eidBalloons}
                useEidBalloon={useEidBalloon}
                addEidBalloons={addEidBalloons}
                onGameOver={handleGameOver}
                challenges={challenges}
                onChallengeProgress={handleChallengeProgress}
                onChallengeCompleted={handleChallengeCompleted}
                onObstacleCollision={handleObstacleCollision}
                controlMode={controlMode}
                resumedWithBalloons={resumedWithBalloons}
                onConsumeResume={() => setResumedWithBalloons(false)}
              />
            </div>
          )}

          {/* C. SHOP MODULE STATE SCREEN */}
          {gameState === GameState.SHOP && (
            <div className="w-full h-full flex items-center justify-center p-0 sm:p-4 bg-[#fdf2e9] overflow-hidden">
              <div className="w-full h-full max-w-md max-h-screen sm:max-h-[92vh] bg-white sm:rounded-3xl shadow-xl overflow-hidden flex flex-col border-0 sm:border-2 sm:border-orange-300">
                <Shop 
                  clovers={cloversTotal}
                  subClovers={subClovers}
                  unlockedOutfits={unlockedOutfits}
                  unlockOutfit={(id) => setUnlockedOutfits(prev => [...prev, id])}
                  activeOutfitId={activeOutfitId}
                  setActiveOutfitId={setActiveOutfitId}
                  magnetLevel={magnetLevel}
                  levelUpMagnet={handleLevelUpMagnet}
                  cornLevel={cornLevel}
                  levelUpCorn={handleLevelUpCorn}
                  shieldLevel={shieldLevel}
                  levelUpShield={handleLevelUpShield}
                  goldenCloverLevel={goldenCloverLevel}
                  levelUpGoldenClover={handleLevelUpGoldenClover}
                  eidBalloons={eidBalloons}
                  addEidBalloons={addEidBalloons}
                  onBack={() => setGameState(GameState.MENU)}
                />
              </div>
            </div>
          )}

          {/* D. GAME OVER STATUS FULL DISPLAY MODAL */}
          {gameState === GameState.GAME_OVER && (
            <motion.div 
              id="gameover-modal-overlay" 
              className="absolute inset-0 flex flex-col items-center justify-center p-3 sm:p-4 text-center z-40 select-none animate-fadeIn overflow-hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              {/* Cartoon Cutscene in Background: El-Moallim Basyouni tying the sheep's leg with rope & Balloon Escape */}
              <GameOverCutscene 
                activeOutfitId={activeOutfitId} 
                isModalVisible={showGameOverModal}
                isEscapingWithBalloons={isEscapingWithBalloons}
                onEscapeComplete={handleEscapeComplete}
              />

              {/* Skip button while watching the tying cutscene before modal reveals */}
              {!showGameOverModal && !isEscapingWithBalloons && (
                <button
                  onClick={() => setShowGameOverModal(true)}
                  className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 bg-black/60 hover:bg-black/85 active:scale-95 text-white/95 font-bold text-xs px-4 py-2 rounded-full border border-yellow-400/50 backdrop-blur-md cursor-pointer flex items-center gap-1.5 transition-all shadow-xl pointer-events-auto"
                  title="تخطي المشهد وعرض النتائج"
                >
                  <span>تخطي المشهد وعرض النتيجة</span>
                  <span>⏭️</span>
                </button>
              )}

              {/* Exact existing Game Over modal card directly over the tying cutscene, revealed after the 2.8-second cutscene */}
              {showGameOverModal && !isEscapingWithBalloons && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.85, y: 15 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                  className="relative z-10 w-full max-w-[310px] sm:max-w-xs bg-white/95 backdrop-blur-md border-2 border-red-500 rounded-[2rem] p-4.5 sm:p-5 shadow-2xl flex flex-col gap-3.5 text-right"
                >
                  
                  {/* Visual Icon Header */}
                  <div className="flex flex-col items-center justify-center pt-1">
                    <span className="text-5xl animate-bounce">🍢🐑</span>
                    <h2 className="text-red-500 font-black text-base sm:text-lg tracking-tight mt-1 text-center w-full">
                      المعلم بسيوني صادك يا خروف!
                    </h2>
                  </div>

                  {/* Comical Catch Slang description */}
                  <div className="bg-red-50 border border-red-100 px-3.5 py-2.5 rounded-xl text-center">
                    <p className="text-red-600 text-xs sm:text-sm font-black leading-relaxed">
                      {gameOverQuote || "اتمسكت واتحولت كفتة بالبقدونس وسلطة طحينة ممتازة!"}
                    </p>
                  </div>

                  {/* Round Statistics table */}
                  <div className="bg-[#f0f4f8] border border-orange-100 rounded-xl p-3 flex flex-col gap-2 text-[#2c3e50] text-sm font-black">
                    <div className="flex justify-between items-center bg-white border border-orange-100 py-1.5 px-2.5 rounded-lg">
                      <span className="font-mono text-[#e67e22] text-base sm:text-lg font-black">{currentScore}</span>
                      <span className="text-gray-500 text-xs sm:text-sm">نقاط هربك:</span>
                    </div>
                    <div className="flex justify-between items-center bg-white border border-orange-100 py-1.5 px-2.5 rounded-lg">
                      <span className="font-mono text-[#e67e22] text-base sm:text-lg font-black">{currentDistance}m</span>
                      <span className="text-gray-500 text-xs sm:text-sm">المسافة:</span>
                    </div>
                    <div className="flex justify-between items-center bg-white border border-orange-100 py-1.5 px-2.5 rounded-lg">
                      <span className="font-mono text-[#27ae60] text-base sm:text-lg flex items-center gap-1 justify-end font-black">{cloversCollectedThisRound} 🍀</span>
                      <span className="text-gray-500 text-xs sm:text-sm">البرسيم المجموع:</span>
                    </div>
                    {lastRoundBonusClovers > 0 && (
                      <div className="flex justify-between items-center bg-emerald-50 border border-emerald-200 py-1.5 px-2.5 rounded-lg text-emerald-800 text-xs font-black">
                        <span className="font-mono text-emerald-700 text-sm font-black">+{lastRoundBonusClovers} 🍀</span>
                        <span>بونص المعلم البلدية (+25%):</span>
                      </div>
                    )}
                  </div>

                  {/* Main Action buttons row */}
                  <div className="flex flex-col gap-2 mt-1">
                    {/* 🎬 مضاعفة البرسيم 🎬 (2x) */}
                    {cloversCollectedThisRound > 0 && (
                      hasDoubledClovers ? (
                        <div className="w-full bg-emerald-50 border-2 border-emerald-300 text-emerald-800 font-black text-xs py-2 px-3 rounded-2xl flex items-center justify-center gap-1.5 shadow-xs">
                          <span>✨</span>
                          <span>تمت مضاعفة البرسيم 2x بنجاح! (+{cloversCollectedThisRound} 🍀)</span>
                        </div>
                      ) : (
                        <button
                          onClick={() => setShowDoubleCloversAd(true)}
                          className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-emerald-600 hover:brightness-105 active:scale-95 text-white border-b-4 border-amber-700 font-black text-xs sm:text-sm py-2.5 px-3 rounded-2xl cursor-pointer shadow-md flex items-center justify-center gap-2 group transition-all animate-bounce"
                        >
                          <span className="text-lg">🎬</span>
                          <span>مضاعفة البرسيم 🎬 (2x)</span>
                          <span className="text-[11px] bg-black/25 px-2 py-0.5 rounded-full font-mono font-bold text-yellow-200">
                            +{cloversCollectedThisRound} 🍀 مجاناً!
                          </span>
                        </button>
                      )
                    )}

                    {/* 🎈 بالونات العيد: استكمال الهروب وتخطي الخسارة! */}
                    <button
                      onClick={handleResumeEscapeWithBalloons}
                      className="w-full bg-gradient-to-r from-rose-500 via-pink-500 to-amber-500 hover:brightness-110 active:scale-95 text-white border-b-4 border-rose-700 font-black text-sm py-2.5 px-3 rounded-2xl cursor-pointer shadow-xl flex items-center justify-center gap-2 group transition-all animate-pulse"
                    >
                      <span className="text-xl group-hover:scale-125 transition-transform">🎈</span>
                      <div className="flex flex-col items-center leading-tight">
                        <span className="font-black text-sm">استكمال الهروب بالبالونات!</span>
                        <span className="text-[11px] font-bold text-yellow-200">
                          {eidBalloons > 0 
                            ? `(استخدم 1 بالونة • متبقي: ${eidBalloons} 🎈)`
                            : cloversTotal >= 60 
                              ? `(شراء بالونة بـ 60 🍀 والهروب فوراً!)`
                              : `(تحتاج 1 بالونة أو 60 🍀)`}
                        </span>
                      </div>
                      <span className="text-xl group-hover:scale-125 transition-transform">✨</span>
                    </button>

                    <button
                      onClick={restartGame}
                      className="w-full bg-[#10b981] text-white border-b-4 border-[#047857] hover:brightness-105 font-extrabold text-sm sm:text-base py-2.5 rounded-xl cursor-pointer text-center"
                    >
                      🚀 جرب اهرب تاني!
                    </button>

                    <button
                      onClick={exitToMenu}
                      className="w-full bg-[#e67e22] text-white border-b-4 border-[#c25114] font-bold text-xs sm:text-sm py-2 rounded-xl cursor-pointer text-center"
                    >
                      العودة للقائمة الرئيسية ↩️
                    </button>
                  </div>

                </motion.div>
              )}
            </motion.div>
          )}

          {/* 🎬 REWARDED AD MODAL FOR DOUBLE CLOVERS */}
          {showDoubleCloversAd && (
            <RewardedAdModal
              placement="DOUBLE_HARVEST"
              title="مضاعفة محصول البرسيم 2x"
              rewardDescription={`مضاعفة برسيم الجولة فوراً (+${cloversCollectedThisRound} 🍀 إضافية) 🎉`}
              onRewardGranted={handleDoubleCloversGranted}
              onClose={() => setShowDoubleCloversAd(false)}
            />
          )}

          {/* E. PAUSE STATE CONTROL DIALOG OVERLAY */}
          {gameState === GameState.PAUSED && isConnected() && (
            <motion.div 
              id="pause-modal-overlay" 
              className="absolute inset-0 bg-black/25 flex flex-col items-center justify-center p-4 text-center z-40 select-none animate-fadeIn"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <div className="w-full max-w-[260px] bg-white border-2 border-orange-500 rounded-[2rem] p-4.5 shadow-xl flex flex-col gap-3 text-center animate-scale-up">
                
                <h3 className="text-[#e67e22] text-base sm:text-lg font-black tracking-tight">
                  ☕ الهروب مستمر بالخفاء!
                </h3>
                
                <p className="text-gray-500 text-xs sm:text-[13px] leading-relaxed">
                  الخروف مستني إشارتك عشان يهرب من المعلم بسيوني. جاهز تكمل؟
                </p>

                {/* Control mode switcher in Pause Menu */}
                <div className="bg-orange-50 border border-orange-200 rounded-xl p-2 flex flex-col gap-1.5 text-right">
                  <span className="text-[#e67e22] text-xs font-black">🎮 طريقة التحكم:</span>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      onClick={() => setControlMode('buttons')}
                      className={`py-1.5 px-1 text-xs font-black rounded-lg transition-all text-center cursor-pointer ${
                        controlMode === 'buttons' ? 'bg-orange-500 text-white shadow-xs' : 'bg-white text-gray-600 border border-orange-100 hover:bg-orange-100/50'
                      }`}
                    >
                      🕹️ أسهم الشاشة
                    </button>
                    <button
                      onClick={() => setControlMode('swipe')}
                      className={`py-1.5 px-1 text-xs font-black rounded-lg transition-all text-center cursor-pointer ${
                        controlMode === 'swipe' ? 'bg-orange-500 text-white shadow-xs' : 'bg-white text-gray-600 border border-orange-100 hover:bg-orange-100/50'
                      }`}
                    >
                      👆 السحب Swipe
                    </button>
                  </div>
                </div>

                <div className="flex flex-col gap-2 mt-1">
                  <button
                    onClick={() => setGameState(GameState.PLAYING)}
                    className="w-full bg-[#10b981] text-white border-b-4 border-[#047857] hover:brightness-105 font-extrabold text-sm py-2.5 rounded-xl cursor-pointer"
                  >
                    ▶️ استكمال الهرب
                  </button>
                  <button
                    onClick={restartGame}
                    className="w-full bg-[#f59e0b] text-white border-b-4 border-[#b45309] font-black text-sm py-2 rounded-xl cursor-pointer"
                  >
                    🔄 إعادة تشغيل الجولة
                  </button>
                  <button
                    onClick={exitToMenu}
                    className="w-full flat-btn-red text-white text-xs sm:text-sm font-bold py-2 rounded-xl cursor-pointer"
                  >
                    🚪 العودة للقائمة الرئيسية
                  </button>
                </div>

              </div>
            </motion.div>
          )}

          {/* F. SLIDING TOAST CHALLENGES COMPLETED BANNER */}
          {activeToast && (
            <motion.div
              id="challenge-success-toast"
              initial={{ x: '100%', opacity: 0 }}
              animate={{ x: '0%', opacity: 1 }}
              exit={{ x: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 15 }}
              className="absolute top-4 left-4 right-4 bg-gradient-to-r from-yellow-500 to-amber-600 border-2 border-amber-300 text-white p-3.5 rounded-2xl shadow-xl z-50 flex items-center justify-between text-right"
              dir="rtl"
            >
              <div className="flex items-center gap-2.5">
                <span className="text-2xl animate-spin">🏆</span>
                <div className="flex flex-col">
                  <span className="text-xs text-yellow-100 uppercase tracking-wider font-extrabold text-amber-100">اكتمل التحدي اليومي!</span>
                  <span className="text-sm font-black tracking-tight">{activeToast.title}</span>
                </div>
              </div>
              <div className="bg-white/20 px-3 py-1 rounded-xl text-center flex flex-col items-center">
                <span className="text-[10px] font-extrabold uppercase text-amber-100">المكافأة</span>
                <span className="text-sm font-black font-mono">+{activeToast.reward} 🍀</span>
              </div>
            </motion.div>
          )}

          {/* تلميح الخروج على الأندرويد */}
          {exitHint && (
            <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[200] bg-black/80 text-white text-xs font-bold px-4 py-2 rounded-full pointer-events-none select-none">
              اضغط رجوع مرة أخرى للخروج
            </div>
          )}

          {/* G. CARTOON OFFLINE FALLBACK OVERLAY & NETWORK RECOVERY */}
          <OfflineOverlay 
            isGameRunning={gameState === GameState.PLAYING}
            onConnectivityRestored={() => {
              if (gameState === GameState.PAUSED) {
                setGameState(GameState.PLAYING);
              }
            }}
            onExitGame={() => {
              exitToMenu();
            }}
          />

        </div>
      </motion.div>
    </div>
  );
}
