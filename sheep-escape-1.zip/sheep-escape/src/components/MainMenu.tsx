/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { GameState, DailyChallenge, ControlMode } from '../types';
import { gameSounds } from './SoundManager';
import { BUTCHER_BANNER_BASE64 } from '../utils/butcherBannerBase64';
import BannerAdSpace from './BannerAdSpace';
import { isConnected, openExternal } from '../utils/connection';
import { getWhatsAppUrl } from '../config';

function safeGet(key: string, fallback: string = ''): string {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage.getItem(key) ?? fallback;
    }
  } catch (e) {}
  return fallback;
}

function safeSet(key: string, value: string): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, value);
    }
  } catch (e) {}
}

interface MainMenuProps {
  highScore: number;
  maxDistance: number;
  totalClovers: number;
  setGameState: (state: GameState) => void;
  isMuted: boolean;
  onToggleMute: () => void;
  challenges: DailyChallenge[];
  onResetChallenges: () => void;
  controlMode: ControlMode;
  onControlModeChange: (mode: ControlMode) => void;
  onClaimDailyReward?: (clovers: number, balloons?: number) => void;
}

export interface DailyStreakReward {
  day: number;
  clovers: number;
  balloons?: number;
  title: string;
  emoji: string;
}

export const DAILY_STREAK_REWARDS: DailyStreakReward[] = [
  { day: 1, clovers: 25, title: 'بداية الرحلة', emoji: '🌱' },
  { day: 2, clovers: 40, title: 'حماس متواصل', emoji: '⚡' },
  { day: 3, clovers: 60, title: 'سرعة البرق', emoji: '🔥' },
  { day: 4, clovers: 85, title: 'فلتان الحارات', emoji: '🏃‍♂️' },
  { day: 5, clovers: 115, title: 'عمدة الزريبة', emoji: '⭐' },
  { day: 6, clovers: 150, title: 'أسطورة الهروب', emoji: '👑' },
  { day: 7, clovers: 250, balloons: 1, title: 'الكنز الأكبر!', emoji: '🎁' },
];

function getLocalDateString(date: Date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getDaysDiff(dateStr1: string, dateStr2: string): number {
  if (!dateStr1 || !dateStr2) return 999;
  const d1 = new Date(dateStr1 + 'T00:00:00');
  const d2 = new Date(dateStr2 + 'T00:00:00');
  const diffTime = d2.getTime() - d1.getTime();
  return Math.round(diffTime / (1000 * 60 * 60 * 24));
}

export function getEgyptianRank(score: number) {
  if (score < 1000) return { title: 'خروف نيئ سهل الصيد 🐑', emoji: '🟢', color: 'text-emerald-700 font-extrabold' };
  if (score < 3500) return { title: 'خفيف اللّية السريع ⚡', emoji: '🔵', color: 'text-blue-700 font-extrabold' };
  if (score < 8000) return { title: 'فلتان مـذابح البساتين 🔪', emoji: '🟣', color: 'text-purple-700 font-extrabold' };
  if (score < 16000) return { title: 'زعيم الزريبة الأكبر 👑', emoji: '🟠', color: 'text-amber-700 font-extrabold' };
  if (score < 35000) return { title: 'المعلم كوارع وبسطرمة 🍖', emoji: '🔴', color: 'text-rose-700 font-extrabold' };
  return { title: 'خروف الفراعنة الخالد 🇪🇬👑', emoji: '✨👑𓃵', color: 'text-yellow-600 font-extrabold animate-pulse' };
}

export default function MainMenu({
  highScore,
  maxDistance,
  totalClovers,
  setGameState,
  isMuted,
  onToggleMute,
  challenges,
  onResetChallenges,
  controlMode,
  onControlModeChange,
  onClaimDailyReward,
}: MainMenuProps) {
  const [showTutorial, setShowTutorial] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const [difficulty, setDifficulty] = useState<'easy' | 'normal' | 'hard'>(() => {
    return (safeGet('sheep_game_difficulty', 'normal') as 'easy' | 'normal' | 'hard') || 'normal';
  });

  // 📅 DAILY LOGIN STREAK SYSTEM
  const todayStr = getLocalDateString();
  const [streakState, setStreakState] = useState(() => {
    const storedStreak = Number(safeGet('sheep_game_login_streak', '0'));
    const lastDate = safeGet('sheep_game_last_login_date', '');
    const maxStreak = Number(safeGet('sheep_game_max_streak', '0'));

    let currentStreak = storedStreak;
    let canClaim = false;
    let claimDay = 1;

    if (!lastDate) {
      // First time player - can claim Day 1
      currentStreak = 0;
      canClaim = true;
      claimDay = 1;
    } else {
      const diff = getDaysDiff(lastDate, todayStr);
      if (diff === 0) {
        // Already claimed today
        canClaim = false;
        currentStreak = Math.max(1, storedStreak);
        claimDay = ((currentStreak - 1) % 7) + 1;
      } else if (diff === 1) {
        // Consecutive day
        canClaim = true;
        claimDay = (storedStreak % 7) + 1;
      } else {
        // Streak broken
        currentStreak = 0;
        canClaim = true;
        claimDay = 1;
      }
    }

    return {
      streak: currentStreak,
      lastDate,
      canClaim,
      claimDay,
      maxStreak: Math.max(maxStreak, currentStreak)
    };
  });

  const [claimCelebration, setClaimCelebration] = useState<{
    day: number;
    clovers: number;
    balloons?: number;
    newStreak: number;
  } | null>(null);

  const handleClaimReward = () => {
    if (!streakState.canClaim) return;
    const reward = DAILY_STREAK_REWARDS[streakState.claimDay - 1];
    const newStreak = streakState.streak + 1;
    const newMax = Math.max(streakState.maxStreak, newStreak);

    safeSet('sheep_game_login_streak', String(newStreak));
    safeSet('sheep_game_last_login_date', todayStr);
    safeSet('sheep_game_max_streak', String(newMax));

    setStreakState({
      streak: newStreak,
      lastDate: todayStr,
      canClaim: false,
      claimDay: streakState.claimDay,
      maxStreak: newMax
    });

    setClaimCelebration({
      day: streakState.claimDay,
      clovers: reward.clovers,
      balloons: reward.balloons,
      newStreak
    });

    gameSounds.playGoldenClover();

    if (onClaimDailyReward) {
      onClaimDailyReward(reward.clovers, reward.balloons);
    }
  };

  const handleDifficultyChange = (diff: 'easy' | 'normal' | 'hard') => {
    setDifficulty(diff);
    safeSet('sheep_game_difficulty', diff);

    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(diff === 'easy' ? 261.63 : diff === 'normal' ? 329.63 : 392.00, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.18);
    } catch (e) {}
  };

  const [activeTrack, setActiveTrack] = useState<'ataba' | 'baladi'>(() => {
    return gameSounds.getTrack();
  });

  const toggleTrack = () => {
    const nextTrack = activeTrack === 'ataba' ? 'baladi' : 'ataba';
    setActiveTrack(nextTrack);
    gameSounds.setTrack(nextTrack);
  };

  const startGame = () => {
    if (!isConnected()) {
      if (typeof (window as any).showOfflineOverlay === 'function') {
        (window as any).showOfflineOverlay();
      }
      window.dispatchEvent(new Event('offline'));
      return;
    }
    const runs = Number(safeGet('sheep_game_total_runs', '0')) + 1;
    safeSet('sheep_game_total_runs', String(runs));
    setGameState(GameState.PLAYING);
  };

  const openShop = () => {
    if (!isConnected()) {
      if (typeof (window as any).showOfflineOverlay === 'function') {
        (window as any).showOfflineOverlay();
      }
      window.dispatchEvent(new Event('offline'));
      return;
    }
    setGameState(GameState.SHOP);
  };

  // يفتح محادثة واتساب (أعمال) دون إخراج اللعبة من التطبيق
  const handleOpenWhatsApp = () => {
    openExternal(getWhatsAppUrl());
  };

  // Stable static HTTPS & Base64 compressed banner cover for instant WebView rendering
  const bannerUrl = BUTCHER_BANNER_BASE64;

  return (
    <div className="w-full h-full flex flex-col bg-[#fdf2e9]/50 select-none text-right overflow-y-auto rounded-[2rem] relative z-30 font-sans [scrollbar-width:thin] [scrollbar-color:#e67e22_transparent]">
      
      {/* 🎪 TOP GORGEOUS GENERATED BANNER COVER */}
      <div className="relative w-full h-36 min-h-36 sm:h-40 sm:min-h-40 bg-[#fdf2e9] border-b-2 border-orange-400 overflow-hidden flex-shrink-0 butcher-header-banner bg-cover bg-center">
        <img 
          src={bannerUrl} 
          alt="هروب خروف العيد من الجزار بسيوني"
          className="w-full h-full object-cover select-none pointer-events-none"
          loading="eager"
          decoding="sync"
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).src = '/assets/butcher_cover_banner.jpg';
          }}
        />
        
        {/* Story Intro / Funny absolute text tag */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#2c3e50]/95 via-[#2c3e50]/30 to-transparent flex flex-col justify-end p-3.5 animate-fade-in">
          {/* Geometric floating sticker for Warning */}
          <div className="absolute top-2.5 left-2.5 bg-red-600 text-white font-black text-[11px] px-3 py-1 rounded-full border border-white transform -rotate-6 shadow-md">
            الجزار بسيوني خلفك! 🔪
          </div>

          <div className="bg-[#e67e22] text-white px-3.5 py-1.5 rounded-xl border border-white transform -rotate-1 w-max self-end mb-0.5 shadow-md">
            <h1 className="text-base sm:text-lg font-black flex items-center gap-1.5">
              هروب خروف العيد! <span className="text-xl">🐑</span>
            </h1>
          </div>
          <p className="text-[#fdf2e9] text-xs sm:text-[13px] font-bold leading-tight max-w-xs">
            لعبة ركض كرتونية شيقة في حارات مصر القديمة الساحرة 🇪🇬✨
          </p>
        </div>
      </div>

      <div className="p-3 pb-[70px] bg-[#fdf2e9]/50 flex flex-col gap-3.5 relative flex-1">
        <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#d35400 1.5px, transparent 1.5px)', backgroundSize: '20px 20px' }} />
        
        {/* 🏆 PLAYER HISTORIC STATS ROW - DYNAMIC COMBINED DASHBOARD */}
        <div className="grid grid-cols-3 gap-2 z-10">
          <div className="bg-white border border-orange-200 p-2 rounded-xl flex flex-col items-center justify-center shadow-xs">
            <span className="text-[#e67e22] font-black text-[10.5px] sm:text-xs tracking-tight">أعلى نقاط 🏆</span>
            <span className="text-[#2c3e50] font-black text-base sm:text-lg font-mono mt-0.5">{highScore}</span>
          </div>
          <div className="bg-white border border-orange-200 p-2 rounded-xl flex flex-col items-center justify-center shadow-xs">
            <span className="text-[#e67e22] font-black text-[10.5px] sm:text-xs tracking-tight">أطول مسافة 🏃‍♂️</span>
            <span className="text-[#2c3e50] font-black text-sm sm:text-base font-mono mt-0.5">{maxDistance}m</span>
          </div>
          <div className="bg-white border border-orange-200 p-2 rounded-xl flex flex-col items-center justify-center shadow-xs">
            <span className="text-[#e67e22] font-black text-[10.5px] sm:text-xs tracking-tight">البرسيم 🍀</span>
            <span className="text-emerald-600 font-extrabold text-base sm:text-lg font-mono mt-0.5">{totalClovers}</span>
          </div>
        </div>

        {/* 🏅 EGYPTIAN ESCAPE RANK BADGE */}
        {(() => {
          const rank = getEgyptianRank(highScore);
          return (
            <div className="bg-gradient-to-r from-orange-50/90 to-amber-50/90 rounded-xl border border-orange-200 p-2.5 flex justify-between items-center z-10 shadow-xs relative overflow-hidden">
              <div className="absolute top-0 right-0 h-full w-1.5 bg-orange-500" />
              <span className={`text-xs sm:text-sm font-black ${rank.color} flex items-center gap-1.5`}>
                <span>{rank.emoji}</span>
                <span>{rank.title}</span>
              </span>
              <span className="text-gray-500 text-[11px] font-black">رتبتك بالمدابح:</span>
            </div>
          );
        })()}

        {/* 🔥 DAILY LOGIN STREAK CARD */}
        <div className="bg-white border-2 border-amber-300 rounded-xl p-2.5 sm:p-3 shadow-xs z-10 text-right flex flex-col gap-2 relative overflow-hidden">
          <div className="flex justify-between items-center border-b border-orange-100 pb-1.5">
            <div className="flex items-center gap-1.5">
              <span className={`text-[10px] sm:text-[11px] font-black px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-xs ${
                streakState.streak > 0 
                  ? 'bg-gradient-to-r from-red-600 via-orange-500 to-amber-500 text-white animate-pulse'
                  : 'bg-gray-100 text-gray-500'
              }`}>
                <span>🔥</span>
                <span>تتابع الدخول: {streakState.streak} {streakState.streak === 1 ? 'يوم' : 'أيام'}</span>
              </span>
              {streakState.maxStreak > 1 && (
                <span className="text-gray-400 text-[9.5px] font-bold hidden xs:inline">
                  (أعلى تتابع: {streakState.maxStreak})
                </span>
              )}
            </div>
            <span className="text-[#e67e22] text-xs sm:text-sm font-black flex items-center gap-1 select-none pointer-events-none">
              <span>📅</span>
              <span>مكافأة الدخول اليومي</span>
            </span>
          </div>

          {/* 7-Days Horizontal Progression Strip */}
          <div className="grid grid-cols-7 gap-1">
            {DAILY_STREAK_REWARDS.map((r) => {
              const isPastClaimed = (r.day < streakState.claimDay) || (r.day === streakState.claimDay && !streakState.canClaim);
              const isCurrentClaimable = r.day === streakState.claimDay && streakState.canClaim;

              return (
                <div 
                  key={r.day}
                  className={`flex flex-col items-center justify-between p-1 sm:p-1.5 rounded-lg border text-center transition-all ${
                    isPastClaimed
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                      : isCurrentClaimable
                      ? 'bg-gradient-to-b from-amber-100 to-orange-100 border-2 border-orange-500 shadow-sm scale-[1.03] text-orange-950 font-black'
                      : 'bg-gray-50/80 border-gray-200 text-gray-400'
                  }`}
                >
                  <span className="text-[8.5px] sm:text-[9.5px] font-black">يوم {r.day}</span>
                  <span className="text-xs sm:text-sm my-0.5">{r.emoji}</span>
                  <span className="text-[8px] sm:text-[9px] font-black font-mono">
                    +{r.clovers}🍀
                  </span>
                  {r.balloons && (
                    <span className="text-[7px] sm:text-[8px] bg-red-100 text-red-700 px-1 rounded-full font-bold">
                      +🎈
                    </span>
                  )}
                  <div className="mt-0.5">
                    {isPastClaimed ? (
                      <span className="text-[9px] text-emerald-600 font-black">✓</span>
                    ) : isCurrentClaimable ? (
                      <span className="text-[7.5px] bg-orange-500 text-white px-1 rounded-full font-bold animate-pulse">
                        الآن!
                      </span>
                    ) : (
                      <span className="text-[9px] text-gray-300">🔒</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Action Row: Claim button or already claimed status */}
          {streakState.canClaim ? (
            <button
              onClick={handleClaimReward}
              className="w-full py-2 sm:py-2.5 px-3 bg-gradient-to-r from-emerald-500 via-green-600 to-emerald-600 hover:brightness-105 active:scale-98 text-white font-black text-xs sm:text-sm rounded-xl shadow-md border-b-4 border-emerald-700 cursor-pointer flex items-center justify-center gap-2 animate-bounce transition-all"
            >
              <span className="text-base sm:text-lg">🎁</span>
              <span>استلم مكافأة اليوم {streakState.claimDay} (+{DAILY_STREAK_REWARDS[streakState.claimDay - 1].clovers} 🍀 {DAILY_STREAK_REWARDS[streakState.claimDay - 1].balloons ? '+ 🎈 بالون عيد' : ''})</span>
            </button>
          ) : (
            <div className="w-full py-1.5 px-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-[10.5px] sm:text-[11.5px] font-black flex items-center justify-between">
              <span className="flex items-center gap-1">
                <span>✅</span>
                <span>استلمت مكافأة اليوم بنجاح! عُد غداً لليوم {streakState.claimDay === 7 ? 1 : streakState.claimDay + 1} 🔥</span>
              </span>
              <span className="text-emerald-700 font-bold text-[9.5px] bg-emerald-100 px-2 py-0.5 rounded-full">
                مكافأة الغد: +{DAILY_STREAK_REWARDS[streakState.claimDay === 7 ? 0 : streakState.claimDay].clovers} 🍀
              </span>
            </div>
          )}
        </div>

        {/* 🎮 CONTROL SETTINGS (طريقة التحكم) */}
        <div className="bg-white border-2 border-orange-300 rounded-xl p-2.5 px-3 shadow-sm z-10 text-right flex flex-col gap-1.5">
          <div className="flex justify-between items-center border-b border-orange-100 pb-1">
            <span className="text-[10px] bg-blue-100 text-blue-800 font-black px-2 py-0.5 rounded-full">إعدادات التحكم</span>
            <span className="text-[#e67e22] text-xs sm:text-sm font-black">🎮 طريقة التحكم:</span>
          </div>

          <div className="grid grid-cols-2 gap-2 bg-gray-50 p-1.5 rounded-xl border border-gray-100">
            <button
              onClick={() => onControlModeChange('buttons')}
              className={`py-2 px-2 text-xs sm:text-sm font-black rounded-lg active:scale-95 transition-all text-center cursor-pointer flex items-center justify-center gap-1.5 ${
                controlMode === 'buttons'
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'text-gray-500 hover:bg-gray-150'
              }`}
            >
              <span>🕹️</span>
              <span>أسهم الشاشة</span>
            </button>
            <button
              onClick={() => onControlModeChange('swipe')}
              className={`py-2 px-2 text-xs sm:text-sm font-black rounded-lg active:scale-95 transition-all text-center cursor-pointer flex items-center justify-center gap-1.5 ${
                controlMode === 'swipe'
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'text-gray-500 hover:bg-gray-150'
              }`}
            >
              <span>👆</span>
              <span>السحب (Touch Swipe)</span>
            </button>
          </div>
          
          <div className="text-[10px] sm:text-[11.5px] text-gray-500 font-bold leading-normal text-center min-h-[1.25rem] flex items-center justify-center">
            {controlMode === 'buttons' && "🕹️ تظهر أزرار الحركة والتنقل والقفز/التزحلق بأسفل الشاشة للتحكم."}
            {controlMode === 'swipe' && "👆 إخفاء جميع الأزرار لتصبح الشاشة فارغة ونظيفة تماماً! التمرير بالإصبع للتوجيه."}
          </div>
        </div>

        {/* 🎯 DAILY CHALLENGES CARD - GEOMETRIC */}
        <div className="bg-white border border-orange-200 rounded-xl p-2.5 sm:p-3 text-[#2c3e50] relative z-10 shadow-xs text-right flex flex-col gap-2">
          <div className="flex justify-between items-center border-b border-orange-100 pb-1">
            <button 
              onClick={onResetChallenges}
              className="text-[10px] sm:text-[11px] bg-orange-50 hover:bg-orange-100 hover:text-orange-900 border border-orange-150 text-orange-700 px-2.5 py-0.5 rounded-md font-black cursor-pointer shadow-xs active:scale-95 transition-transform"
              title="تحديث التحديات للحصول على فرصة جديدة"
            >
              🔄 تجديد التحديات
            </button>
            <span className="text-[#e67e22] font-black text-xs sm:text-sm flex items-center gap-1 select-none pointer-events-none">
              🎯 تحديات العيد اليومية
            </span>
          </div>

          <div className="flex flex-col gap-2">
            {challenges.map((ch) => {
              const pct = Math.min(100, Math.floor((ch.progress / ch.target) * 100));
              return (
                <div key={ch.id} className="flex flex-col gap-0.5 text-xs sm:text-[13px]">
                  <div className="flex justify-between items-center">
                    <span className="font-mono text-[9.5px] sm:text-[10px] font-black text-[#27ae60] bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-100">
                      +{ch.rewardClovers} 🍀
                    </span>
                    <span className={`font-black text-xs sm:text-[13px] ${ch.completed ? 'text-green-600 line-through opacity-70' : 'text-[#2c3e50]'}`}>
                      {ch.title}
                    </span>
                  </div>
                  
                  {/* Progress bar */}
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] sm:text-[10px] font-black font-mono text-gray-400 w-10 text-left">
                      {ch.progress}/{ch.target}
                    </span>
                    <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden relative border border-gray-100">
                      <div 
                        className={`h-full rounded-full transition-all duration-300 ${ch.completed ? 'bg-green-500' : 'bg-orange-500'}`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    {ch.completed && (
                      <span className="text-[9px] sm:text-[10px] font-black text-green-600 animate-bounce">مكتمل! 🎉</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ⚙️ DIFFICULTY/SPEED LEVEL SELECTOR */}
        <div className="bg-white border border-orange-200 rounded-xl p-2 px-2.5 shadow-xs z-10 text-right flex flex-col gap-1">
          <div className="flex justify-between items-center border-b border-orange-100 pb-1">
            <span className="text-[9.5px] sm:text-[10px] bg-amber-100 text-[#b45309] font-black px-2 py-0.5 rounded-full">السرعة والتحكم</span>
            <span className="text-[#e67e22] text-xs sm:text-sm font-black">⚙️ اختر سرعة ومستوى الجري:</span>
          </div>

          <div className="grid grid-cols-3 gap-1 bg-gray-50 p-1 rounded-xl border border-gray-100">
            <button
              onClick={() => handleDifficultyChange('hard')}
              className={`py-1.5 px-0.5 text-xs sm:text-[13px] font-black rounded-lg active:scale-95 transition-all text-center cursor-pointer ${
                difficulty === 'hard'
                  ? 'bg-rose-600 text-white shadow-xs font-black animate-none'
                  : 'text-gray-400 hover:bg-gray-150'
              }`}
            >
              🌶️ صعب ناري
            </button>
            <button
              onClick={() => handleDifficultyChange('normal')}
              className={`py-1.5 px-0.5 text-xs sm:text-[13px] font-black rounded-lg active:scale-95 transition-all text-center cursor-pointer ${
                difficulty === 'normal'
                  ? 'bg-orange-500 text-white shadow-xs font-black'
                  : 'text-gray-400 hover:bg-gray-150'
              }`}
            >
              🏃‍♂️ عادي طبيعي
            </button>
            <button
              onClick={() => handleDifficultyChange('easy')}
              className={`py-1.5 px-0.5 text-xs sm:text-[13px] font-black rounded-lg active:scale-95 transition-all text-center cursor-pointer ${
                difficulty === 'easy'
                  ? 'bg-emerald-600 text-white shadow-xs font-black animate-pulse'
                  : 'text-gray-400 hover:bg-gray-150'
              }`}
            >
              🐑 سهل هادئ
            </button>
          </div>
          
          <div className="text-[10px] sm:text-[11.5px] text-gray-500 font-bold leading-normal text-center min-h-[1.25rem] flex items-center justify-center">
            {difficulty === 'easy' && "🐑 سهل: سرعة هادئة ثابتة تقريباً لتجنب العقبات واللعب باسترخاء."}
            {difficulty === 'normal' && "🏃‍♂️ عادي: تسارع تدريجي بطيء حتى يصل للحد الأقصى المريح والممتع."}
            {difficulty === 'hard' && "🌶️ صعب ناري: تبدأ سريعة ولكن تصمد عند السقف الأقصى لتحدي متقن ومحكم."}
          </div>
        </div>

        {/* 🎮 CORE MENU OPTIONS BUTTONS */}
        <div className="flex flex-col gap-2.5 z-10">
          {/* PLAY BUTTON - CHUNKY GREEN FLAT PATTERN */}
          <button
            onClick={startGame}
            className="w-full bg-[#10b981] shadow-md hover:brightness-105 hover:bg-[#059669] text-white border-b-4 border-[#047857] font-extrabold text-base sm:text-lg py-3 rounded-xl cursor-pointer text-center flex items-center justify-center gap-2 active:scale-98 transition-all animate-pulse"
          >
            🚀 ابدأ الهروب الكبير الآن!
          </button>

          {/* CLOTHING SHOP BUTTON - CHUNKY BLUE FLAT PATTERN */}
          <button
            onClick={openShop}
            className="w-full bg-[#3b82f6] shadow-md hover:brightness-105 hover:bg-[#2563eb] text-white border-b-4 border-[#1d4ed8] font-extrabold text-sm sm:text-base py-2.5 rounded-lg cursor-pointer text-center flex items-center justify-center gap-2 active:scale-98 transition-all"
          >
            🎪 دكان الخروف السعيد (الملابس والترقيات)
          </button>

          {/* 💬 CONTACT & SUGGESTIONS BUTTON (DIRECT SAME-PAGE REDIRECT FOR WEBVIEW COMPATIBILITY) */}
          <button
            type="button"
            onClick={handleOpenWhatsApp}
            className="w-full bg-gradient-to-r from-emerald-500 via-green-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white border-b-4 border-emerald-800 shadow-md py-2.5 px-3 rounded-xl cursor-pointer text-center flex items-center justify-center gap-2 active:scale-98 transition-all group"
            title="تواصل معنا على واتساب لإرسال اقتراحاتك وآرائك"
          >
            {/* Cartoon WhatsApp Speech Bubble Icon */}
            <div className="w-8 h-8 rounded-full bg-white/20 border border-white/40 flex items-center justify-center text-lg shrink-0 group-hover:scale-110 transition-transform shadow-xs">
              💬
            </div>
            <div className="flex flex-col items-center leading-tight">
              <span className="font-black text-sm sm:text-base flex items-center gap-1">
                <span>تواصل معنا للإقتراحات 💬</span>
              </span>
              <span className="text-[10.5px] font-bold text-emerald-100 flex items-center gap-1">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-200 animate-ping" />
                <span>واتساب مباشر • شاركنا أفكارك لتطوير اللعبة!</span>
              </span>
            </div>
          </button>
        </div>

        {/* 🛠️ BENTO OPTIONS CONTROLLER GRID - INCREDIBLY COMPACT & SPACE-SAVING */}
        <div className="bg-white border border-orange-200/60 rounded-xl p-2.5 shadow-xs text-right flex flex-col gap-1.5 z-10">
          <div className="text-gray-500 text-[10.5px] sm:text-xs font-black border-b border-orange-100 pb-1">
            🎛️ أدوات تعديل اللعبة والأنغام الشعبية القديمة:
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            {/* EGYPTIAN FOLK MELODY SELECTOR CONTROL */}
            <button
              onClick={toggleTrack}
              className="bg-purple-50 hover:bg-purple-100/80 hover:text-purple-900 border border-purple-100 text-[#6b21a8] text-xs sm:text-[13px] font-black py-2 rounded-md cursor-pointer text-center flex items-center justify-center gap-1 active:scale-95 transition-transform"
            >
              🎵 اللحن: {activeTrack === 'ataba' ? 'العتبة 🎷' : 'سعيدي 🪕'}
            </button>

            {/* AUDIO TOGGLE BUTTON */}
            <button
              onClick={onToggleMute}
              className="bg-indigo-50 hover:bg-indigo-100/80 hover:text-indigo-900 border border-indigo-100 text-[#1e3a8a] text-xs sm:text-[13px] font-black py-2 rounded-md cursor-pointer text-center flex items-center justify-center gap-1 active:scale-95 transition-transform"
            >
              {isMuted ? '🔇 تشغيل الأنغام' : '🔊 كتم الأنغام'}
            </button>

            {/* TUTORIAL / HELP TOGGLE */}
            <button
              onClick={() => {
                setShowTutorial(!showTutorial);
                if (showStats) setShowStats(false);
              }}
              className="bg-amber-50 hover:bg-amber-100/80 hover:text-amber-900 border border-amber-105 text-[#9a3412] text-xs sm:text-[13px] font-black py-2 rounded-md cursor-pointer text-center flex items-center justify-center gap-1 active:scale-95 transition-transform"
            >
              📖 كيف ألعب اللعبة؟
            </button>

            {/* STATS BUTTON */}
            <button
              onClick={() => {
                setShowStats(!showStats);
                if (showTutorial) setShowTutorial(false);
              }}
              className="bg-emerald-50 hover:bg-emerald-100/80 hover:text-emerald-955 border border-emerald-100 text-[#065f46] text-xs sm:text-[13px] font-black py-2 rounded-md cursor-pointer text-center flex items-center justify-center gap-1 active:scale-95 transition-transform"
            >
              📊 {showStats ? 'إخفاء الإحصائيات' : 'سجل إنجازات الخروف'}
            </button>
          </div>
        </div>

        {/* TUTORIAL INFO DROPDOWN COLLAPSIBLE */}
        {showTutorial && (
          <div className="bg-white border border-amber-300 rounded-xl p-3.5 text-[#2c3e50] text-xs sm:text-[13px] leading-relaxed text-right flex flex-col gap-2 z-10 shadow-md">
            <span className="text-[#e67e22] font-black text-sm block border-b border-orange-100 pb-1">📖 تعليمات التحكم وعناصر اللعبة:</span>
            
            <div className="grid grid-cols-2 gap-2 mt-0.5">
              <div className="bg-amber-50/50 p-2.5 rounded-lg border border-amber-100">
                <span className="text-[#d35400] font-black block text-[11px] sm:text-xs mb-1">🎮 طريقتين للتحكم:</span>
                <div>• <b>أسهم الشاشة:</b> أزرار أسفل الشاشة للتحكم.</div>
                <div>• <b>السحب (Touch Swipe):</b> إخفاء الأزرار وشاشة نظيفة مع السحب بإصبعك!</div>
                <div>• <b>كيبورد:</b> A/D أو الأسهم لتغيير الحارة، W للقفز، S للتزحلق.</div>
              </div>

              <div className="bg-amber-50/50 p-2.5 rounded-lg border border-amber-100">
                <span className="text-[#d35400] font-black block text-[11px] sm:text-xs mb-1">🌟 العناصر والمعدات السحرية:</span>
                <div>• 🌶️ <b>شطة الجزار النارية:</b> طيران فائق وسرعة خارقة وجذب كل البرسيم!</div>
                <div>• 🍲 <b>درع الفتة بالثوم:</b> هالة حماية مؤقتة ضد أول اصطدام.</div>
                <div>• 🌟 <b>البرسيم الذهبي المشع:</b> يمنحك 5 زهور دفعة واحدة!</div>
                <div>• 🎈 <b>بالونات العيد:</b> تتيح لك الطيران والاستمرار بعد الاصطدام.</div>
              </div>
            </div>
            
            <button
              onClick={() => {
                try {
                  localStorage.removeItem('sheep_game_tutorial_completed');
                } catch (e) {}
                startGame();
              }}
              className="mt-1 bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-black text-xs py-2 rounded-xl text-center cursor-pointer shadow-xs"
            >
              📱 تشغيل البرنامج التعليمي التفاعلي بالكامل
            </button>
          </div>
        )}

        {/* STATS & ACHIEVEMENTS BENTO GRID PANEL */}
        {showStats && (() => {
          const totalRuns = Number(safeGet('sheep_game_total_runs', '0'));
          const boxesOpened = Number(safeGet('sheep_game_boxes_opened', '0'));
          const unlockedCount = (() => {
            try {
              const outfitsStr = safeGet('sheep_game_outfits');
              return outfitsStr ? JSON.parse(outfitsStr).length : 1;
            } catch {
              return 1;
            }
          })();
          const magnetLvl = Number(safeGet('sheep_game_magnet_lvl', '1'));
          const cornLvl = Number(safeGet('sheep_game_corn_lvl', '1'));
          const upgradesCount = (magnetLvl + cornLvl) - 2;

          return (
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white border border-emerald-300 rounded-xl p-3.5 text-[#2c3e50] text-xs sm:text-[13px] leading-relaxed text-right flex flex-col gap-2 z-10 shadow-md"
            >
              <div className="text-emerald-700 font-black text-xs sm:text-sm border-b border-emerald-100 pb-1 flex justify-between items-center">
                <span>🏆 سجل التميز والإنجازات للعداء</span>
                <span className="text-[10px] text-gray-400 font-extrabold font-mono">HERCULES SUMMARY</span>
              </div>

              {/* Bento Grid layout with gorgeous styled boxes */}
              <div className="grid grid-cols-5 gap-1">
                
                {/* 1. Total Runs attempted */}
                <div className="bg-sky-50 border border-sky-100 p-1.5 rounded-lg flex flex-col items-center justify-center text-center">
                  <span className="text-sm">🏃‍♂️</span>
                  <span className="font-mono text-xs font-black text-sky-800 mt-0.5">{totalRuns}</span>
                  <span className="text-gray-500 text-[8px] font-black mt-0.5 leading-none">الجولات</span>
                </div>

                {/* 2. Mystery Boxes Opened */}
                <div className="bg-purple-50 border border-purple-100 p-1.5 rounded-lg flex flex-col items-center justify-center text-center">
                  <span className="text-sm">🎁</span>
                  <span className="font-mono text-xs font-black text-purple-800 mt-0.5">{boxesOpened}</span>
                  <span className="text-gray-500 text-[8px] font-black mt-0.5 leading-none">الصناديق</span>
                </div>

                {/* 3. Outfits Unlocked */}
                <div className="bg-amber-50 border border-amber-100 p-1.5 rounded-lg flex flex-col items-center justify-center text-center">
                  <span className="text-sm">👕</span>
                  <span className="font-mono text-xs font-black text-amber-800 mt-0.5">{unlockedCount} / 5</span>
                  <span className="text-gray-500 text-[8px] font-black mt-0.5 leading-none">أزياء</span>
                </div>

                {/* 4. Total Upgrades Done */}
                <div className="bg-emerald-50 border border-emerald-100 p-1.5 rounded-lg flex flex-col items-center justify-center text-center">
                  <span className="text-sm">💪</span>
                  <span className="font-mono text-xs font-black text-emerald-800 mt-0.5">+{upgradesCount}</span>
                  <span className="text-gray-500 text-[8px] font-black mt-0.5 leading-none">ترقيات</span>
                </div>

                {/* 5. Daily Streak Counter */}
                <div className="bg-red-50 border border-red-100 p-1.5 rounded-lg flex flex-col items-center justify-center text-center">
                  <span className="text-sm">🔥</span>
                  <span className="font-mono text-xs font-black text-red-600 mt-0.5">{streakState.streak}</span>
                  <span className="text-gray-500 text-[8px] font-black mt-0.5 leading-none">تتابع الأيام</span>
                </div>

              </div>
              
              <div className="bg-orange-50/50 p-2.5 rounded-lg text-center border border-orange-100">
                <p className="text-orange-700 text-[11px] sm:text-xs font-black leading-tight">
                  💡 تلميحة بلدي: كل ما تجري مسافة أطول هتكسب برسيم أكتر! جرب افتح صناديق الحظ للحصول على جوائز لامتناهية! 🍀🌟
                </p>
              </div>

            </motion.div>
          );
        })()}

        {/* STORY OVERVIEW CARD */}
        <div className="bg-[#e67e22]/5 border border-[#e67e22]/15 p-2.5 rounded-xl text-[#2c3e50] text-[11px] sm:text-xs leading-relaxed z-10">
          💡 <span className="text-[#d35400] font-black">حكاية هيركوليس:</span> خروفنا الذكي فك الحبل وقرر هزم الجزار بسيوني! ساعده في الوثب والتزحلق وتجميع ثروة البرسيم والذرة والمغناطيس لشراء الأزياء من الدكان والتنكر! 🎪🕌
        </div>

      </div>

      {/* 4. RESERVED BOTTOM BANNER AD SPACE (60px) */}
      <BannerAdSpace id="main-menu-bottom-banner" />

      {/* FOOTER FOOTNOTE */}
      <div className="bg-[#f2e2d9] py-2.5 border-t border-orange-200 text-center text-[10.5px] sm:text-[11px] text-[#2c3e50]/80 font-bold flex-shrink-0">
        لعبة كرتونية بروح عيد الأضحى المبارك 🐑 - كل عام وأنتم بخير!
      </div>

      {/* 🎉 DAILY STREAK CELEBRATION MODAL */}
      {claimCelebration && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-xs bg-white rounded-3xl p-5 border-4 border-amber-400 shadow-2xl flex flex-col items-center text-center gap-3 text-[#2c3e50]"
            dir="rtl"
          >
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 flex items-center justify-center text-3xl shadow-md border-2 border-white animate-bounce">
              🎁
            </div>
            
            <div className="flex flex-col gap-0.5">
              <span className="text-amber-600 font-black text-xs">مكافأة الدخول اليومي</span>
              <h2 className="text-base sm:text-lg font-black text-gray-900">
                مبارك! استلمت مكافأة اليوم {claimCelebration.day} 🎉
              </h2>
            </div>

            <div className="w-full bg-amber-50 border border-amber-200 rounded-2xl p-3 flex flex-col gap-1 items-center">
              <span className="text-emerald-600 font-black text-xl font-mono flex items-center gap-1">
                <span>+{claimCelebration.clovers}</span>
                <span>🍀 برسيم</span>
              </span>
              {claimCelebration.balloons && (
                <span className="text-red-600 font-black text-xs sm:text-sm flex items-center gap-1">
                  <span>+1</span>
                  <span>🎈 بالون عيد إضافي!</span>
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1 bg-orange-100 text-orange-800 rounded-full font-black text-xs">
              <span>🔥</span>
              <span>تتابع الدخول الحالي: {claimCelebration.newStreak} {claimCelebration.newStreak === 1 ? 'يوم' : 'أيام متتالية'}!</span>
            </div>

            <p className="text-[11px] text-gray-500 font-bold">
              عُد غداً للاستمرار في التتابع وفتح المكافآت الأكبر! ✨
            </p>

            <button
              onClick={() => setClaimCelebration(null)}
              className="w-full py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black text-sm rounded-xl shadow-md cursor-pointer active:scale-95 transition-all"
            >
              رائع! استمر باللعب 🚀
            </button>
          </motion.div>
        </div>
      )}

    </div>
  );
}
