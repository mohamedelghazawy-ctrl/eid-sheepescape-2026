/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { OUTFITS } from '../utils/gameData';
import { gameSounds } from './SoundManager';

interface GameOverCutsceneProps {
  activeOutfitId?: string;
  isModalVisible?: boolean;
  isEscapingWithBalloons?: boolean;
  onEscapeComplete?: () => void;
}

export default function GameOverCutscene({ 
  activeOutfitId = 'default',
  isModalVisible = false,
  isEscapingWithBalloons = false,
  onEscapeComplete
}: GameOverCutsceneProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [basyouniQuote, setBasyouniQuote] = useState('');
  const escapeFrameRef = useRef(0);
  const soundPlayedRef = useRef({ revive: false, snap: false });

  const activeOutfit = OUTFITS.find(o => o.id === activeOutfitId) || OUTFITS[0];
  const woolColor = activeOutfit.color;

  // Funny quotes from El-Moallim Basyouni while tying the rope
  const quotes = [
    'مسكتك يا فصيح! على الجزارة عدل! 🥩😂',
    'هات رجلك أربطها عقدة بلدية متينة! 🪢',
    'فاكر نفسك غزال؟ ده ساطور المعلم ما بيهزرش! 🍖',
    'ولا تقدر تهرب من المعلم بسيوني خطوة تانية! 🐑',
  ];

  useEffect(() => {
    if (!isEscapingWithBalloons) {
      setBasyouniQuote(quotes[Math.floor(Math.random() * quotes.length)]);
      const quoteInterval = setInterval(() => {
        setBasyouniQuote(quotes[Math.floor(Math.random() * quotes.length)]);
      }, 4500);
      return () => clearInterval(quoteInterval);
    } else {
      setBasyouniQuote('يا بن الإيه!! طار في الجو بالبالونات وسابني؟! 😱🎈🥩');
    }
  }, [isEscapingWithBalloons]);

  useEffect(() => {
    if (isEscapingWithBalloons) {
      escapeFrameRef.current = 0;
      soundPlayedRef.current = { revive: false, snap: false };
    }
  }, [isEscapingWithBalloons]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let frame = 0;

    // Particles for rope break and balloon sparkles
    const escapeParticles: { x: number; y: number; vx: number; vy: number; color: string; size: number; life: number; maxLife: number }[] = [];

    const resize = () => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      ctx.resetTransform();
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    resize();
    window.addEventListener('resize', resize);

    const render = () => {
      frame++;
      const rect = canvas.getBoundingClientRect();
      const w = rect.width;
      const h = rect.height;

      ctx.clearRect(0, 0, w, h);

      // Escape timeline tracking
      let escapeFrame = 0;
      if (isEscapingWithBalloons) {
        escapeFrameRef.current++;
        escapeFrame = escapeFrameRef.current;

        // Sound triggers
        if (escapeFrame === 2 && !soundPlayedRef.current.revive) {
          soundPlayedRef.current.revive = true;
          gameSounds.playBalloonRevive();
        }
        if (escapeFrame === 38 && !soundPlayedRef.current.snap) {
          soundPlayedRef.current.snap = true;
          gameSounds.playShieldBreak();
          gameSounds.playBaa();
        }

        // Complete callback
        if (escapeFrame >= 135) {
          if (onEscapeComplete) {
            onEscapeComplete();
            return;
          }
        }
      }

      // 1. Cairo Alley Backdrop (Warm Night / Sunset Amber Atmosphere)
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#1e1b4b'); // deep twilight purple-blue
      bgGrad.addColorStop(0.5, '#451a03'); // warm amber brick wall
      bgGrad.addColorStop(1, '#1c1917'); // dark cobblestone ground
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Cobblestone ground line
      const groundY = h * 0.76;
      const groundGrad = ctx.createLinearGradient(0, groundY, 0, h);
      groundGrad.addColorStop(0, '#292524');
      groundGrad.addColorStop(1, '#0c0a09');
      ctx.fillStyle = groundGrad;
      ctx.fillRect(0, groundY, w, h - groundY);

      // Cobblestone texture lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1.5;
      for (let y = groundY + 12; y < h; y += 18) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Warm street lamp glow pool on ground
      const glowGrad = ctx.createRadialGradient(w * 0.5, groundY - 30, 20, w * 0.5, groundY + 30, w * 0.6);
      glowGrad.addColorStop(0, 'rgba(251, 191, 36, 0.28)');
      glowGrad.addColorStop(0.6, 'rgba(217, 119, 6, 0.1)');
      glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = glowGrad;
      ctx.fillRect(0, groundY - 60, w, h - groundY + 60);

      // Ancient Cairo Stone Wall Bricks
      ctx.strokeStyle = 'rgba(254, 215, 170, 0.06)';
      ctx.lineWidth = 1;
      for (let y = 30; y < groundY; y += 28) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Shop Sign in background
      ctx.save();
      ctx.fillStyle = '#78350f';
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      const signW = Math.min(220, w * 0.65);
      const signX = (w - signW) / 2;
      const signY = 24;
      ctx.beginPath();
      ctx.roundRect(signX, signY, signW, 36, 8);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 13px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🥩 جزارة المعلم بسيوني 🥩', signX + signW / 2, signY + 18);
      ctx.restore();

      // Hanging decorative lantern on side
      ctx.save();
      const lanternX = Math.max(30, w * 0.12);
      ctx.strokeStyle = '#d97706';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(lanternX, 0);
      ctx.lineTo(lanternX, 60);
      ctx.stroke();

      // Lantern body
      ctx.fillStyle = '#b45309';
      ctx.fillRect(lanternX - 10, 60, 20, 26);
      ctx.fillStyle = 'rgba(254, 240, 138, 0.9)';
      ctx.beginPath();
      ctx.arc(lanternX, 73, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Hitching wooden post / iron ring in ground
      const postX = w * 0.78;
      const postY = groundY - 10;
      ctx.fillStyle = '#573012';
      ctx.beginPath();
      ctx.roundRect(postX - 8, postY - 35, 16, 45, 3);
      ctx.fill();

      // Iron Ring on post
      ctx.strokeStyle = '#9ca3af';
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.arc(postX, postY - 18, 9, 0, Math.PI * 2);
      ctx.stroke();

      // -------------------------------------------------------------
      // SCENE CHARACTERS: EL-MOALLIM BASYOUNI & THE SHEEP
      // -------------------------------------------------------------
      const sceneScale = Math.min(1.2, Math.max(0.75, w / 420));
      const centerX = w * 0.46;
      const baseY = groundY + 10;

      ctx.save();
      ctx.translate(centerX, baseY);
      ctx.scale(sceneScale, sceneScale);

      // Character shadows (fade away as sheep lifts)
      const liftProgress = Math.min(1, Math.max(0, (escapeFrame - 15) / 80));
      const sheepLiftY = isEscapingWithBalloons ? Math.pow(liftProgress, 1.4) * 260 : 0;
      const sheepSway = isEscapingWithBalloons ? Math.sin(escapeFrame * 0.14) * 14 * Math.min(1, escapeFrame / 25) : 0;
      const shadowAlpha = Math.max(0, 0.35 * (1 - sheepLiftY / 180));

      ctx.fillStyle = `rgba(0, 0, 0, ${shadowAlpha})`;
      ctx.beginPath();
      ctx.ellipse(-50, 0, Math.max(8, 55 - sheepLiftY * 0.18), Math.max(3, 12 - sheepLiftY * 0.04), 0, 0, Math.PI * 2); // sheep shadow
      ctx.fill();

      // Butcher shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      ctx.beginPath();
      ctx.ellipse(35, 0, 45, 12, 0, 0, Math.PI * 2); // butcher shadow
      ctx.fill();

      // Rhythmic breathing / motion cycle
      const breathe = Math.sin(frame * 0.08) * 2;
      const tieCycle = (frame * 0.09) % (Math.PI * 2);

      // -------------------------------------------------------------
      // A. THE SHEEP (WITH EID BALLOONS & ESCAPE PHYSICS)
      // -------------------------------------------------------------
      ctx.save();
      ctx.translate(-50 + sheepSway, -18 - sheepLiftY);

      // Tilt sheep gently as it is lifted by the balloons
      if (isEscapingWithBalloons) {
        const tilt = Math.sin(escapeFrame * 0.12) * 0.12;
        ctx.rotate(tilt);
      }

      // Wool Body
      ctx.fillStyle = woolColor;
      ctx.beginPath();
      ctx.arc(-8, -12 + breathe, 24, 0, Math.PI * 2);
      ctx.arc(10, -14 + breathe, 20, 0, Math.PI * 2);
      ctx.arc(-22, -10 + breathe, 16, 0, Math.PI * 2);
      ctx.arc(0, -26 + breathe, 18, 0, Math.PI * 2);
      ctx.fill();

      // Cute Traveler Backpack on Sheep's Back ("شنطة الخروف")
      // Animate backpack rattling and flap opening as balloons burst out
      const bagRattleX = isEscapingWithBalloons && escapeFrame < 16 ? Math.sin(escapeFrame * 1.8) * 2.5 : 0;
      const bagRattleY = isEscapingWithBalloons && escapeFrame < 16 ? Math.cos(escapeFrame * 1.8) * 1.5 : 0;
      const isBagOpen = isEscapingWithBalloons && escapeFrame >= 10;
      const flapOpenAngle = isBagOpen ? Math.min(Math.PI * 0.72, (escapeFrame - 10) * 0.16) : 0;

      ctx.save();
      ctx.translate(-4 + bagRattleX, -38 + breathe + bagRattleY);

      // Backpack Main Leather Body
      ctx.fillStyle = '#78350f'; // Rich saddle leather brown
      ctx.beginPath();
      ctx.roundRect(0, 0, 20, 22, 5);
      ctx.fill();
      ctx.strokeStyle = '#451a03';
      ctx.lineWidth = 1.2;
      ctx.stroke();

      // Front Leather Pocket
      ctx.fillStyle = '#92400e';
      ctx.beginPath();
      ctx.roundRect(2, 8, 16, 12, 3);
      ctx.fill();

      // Leather side straps
      ctx.fillStyle = '#b45309';
      ctx.fillRect(4, 0, 3, 22);
      ctx.fillRect(13, 0, 3, 22);

      // Hinged Backpack Top Flap & Golden Buckle
      ctx.save();
      ctx.translate(10, 0); // Flap hinge at top center of bag
      ctx.rotate(-flapOpenAngle); // Flips back and open when balloons emerge!

      // Leather Flap
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.roundRect(-10, -3, 20, 10, [4, 4, 2, 2]);
      ctx.fill();
      ctx.strokeStyle = '#451a03';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Shiny Gold Buckle
      ctx.fillStyle = '#facc15';
      ctx.fillRect(-3, 3, 6, 5);
      ctx.fillStyle = '#451a03';
      ctx.fillRect(-1.5, 4.5, 3, 2);

      ctx.restore(); // end flap

      // Open Bag Cavity Glow (when opened)
      if (isBagOpen) {
        ctx.fillStyle = 'rgba(254, 240, 138, 0.6)';
        ctx.beginPath();
        ctx.ellipse(10, -1, 7, 3, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore(); // end backpack

      // 🎈 FESTIVE BALLOONS EMERGING FROM SHEEP'S BACKPACK
      if (isEscapingWithBalloons && escapeFrame >= 8) {
        // Elastic spring expansion physics
        const rawScale = Math.min(1.0, (escapeFrame - 8) / 20);
        // Bouncy spring overshoot
        const springOvershoot = escapeFrame > 22 && escapeFrame < 45 ? Math.sin((escapeFrame - 22) * 0.35) * 0.1 : 0;
        const balloonScale = rawScale + springOvershoot;

        ctx.save();
        ctx.translate(6, -38 + breathe); // Mount inside sheep's backpack pocket!
        ctx.scale(balloonScale, balloonScale);

        // Cord cluster tension & vibration
        const cordTension = escapeFrame < 38 ? Math.sin(escapeFrame * 1.5) * 2 : 0;

        // Strings connecting backpack interior to balloon cluster
        const stringColors = ['#fde047', '#facc15', '#fef08a'];
        ctx.lineWidth = 1.8;
        ctx.lineCap = 'round';
        ctx.strokeStyle = stringColors[0];
        ctx.beginPath();
        ctx.moveTo(0, 0); ctx.quadraticCurveTo(-16 + cordTension, -42, -26, -78);
        ctx.moveTo(0, 0); ctx.quadraticCurveTo(-7 + cordTension, -48, -10, -96);
        ctx.moveTo(0, 0); ctx.quadraticCurveTo(8 + cordTension, -52, 12, -102);
        ctx.moveTo(0, 0); ctx.quadraticCurveTo(20 + cordTension, -46, 28, -86);
        ctx.moveTo(0, 0); ctx.quadraticCurveTo(30 + cordTension, -36, 40, -68);
        ctx.stroke();

        // 5 Giant Glossy 3D Shaded Balloons
        const balloons = [
          { x: -26, y: -78, r: 17, color: '#ef4444', light: '#fca5a5' }, // Ruby Crimson
          { x: -10, y: -96, r: 19, color: '#0ea5e9', light: '#7dd3fc' }, // Sky Azure
          { x: 12, y: -102, r: 21, color: '#eab308', light: '#fef08a' }, // Eid Gold (Hero)
          { x: 28, y: -86, r: 18, color: '#ec4899', light: '#fbcfe8' },  // Festive Pink
          { x: 40, y: -68, r: 16, color: '#10b981', light: '#a7f3d0' },  // Cairo Emerald
        ];

        balloons.forEach((b, idx) => {
          // Buoyant floating bob
          const bob = Math.sin(escapeFrame * 0.16 + idx * 1.25) * 3.5;
          ctx.save();
          ctx.translate(b.x, b.y + bob);

          // Balloon Body with 3D Radial Depth
          const bGrad = ctx.createRadialGradient(-b.r * 0.35, -b.r * 0.35, 2, 0, 0, b.r);
          bGrad.addColorStop(0, b.light);
          bGrad.addColorStop(0.65, b.color);
          bGrad.addColorStop(1, '#1e1b4b');
          ctx.fillStyle = bGrad;
          ctx.beginPath();
          ctx.arc(0, 0, b.r, 0, Math.PI * 2);
          ctx.fill();

          // Balloon Knot (Tied nozzle)
          ctx.fillStyle = b.color;
          ctx.beginPath();
          ctx.moveTo(-3.5, b.r - 1);
          ctx.lineTo(3.5, b.r - 1);
          ctx.lineTo(0, b.r + 4.5);
          ctx.closePath();
          ctx.fill();

          // Specular Curved Gloss Highlight Arc
          ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.beginPath();
          ctx.ellipse(-b.r * 0.38, -b.r * 0.38, b.r * 0.24, b.r * 0.48, -0.6, 0, Math.PI * 2);
          ctx.fill();

          // Secondary rim gleam
          ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
          ctx.beginPath();
          ctx.arc(b.r * 0.3, b.r * 0.3, b.r * 0.15, 0, Math.PI * 2);
          ctx.fill();

          ctx.restore();
        });

        // Golden Stars & Sparkles bursting around balloons
        for (let sp = 0; sp < 6; sp++) {
          const sAngle = escapeFrame * 0.12 + sp * (Math.PI / 3);
          const sDist = 48 + Math.sin(escapeFrame * 0.18 + sp) * 16;
          ctx.fillStyle = '#fde047';
          ctx.beginPath();
          ctx.arc(Math.cos(sAngle) * sDist, -80 + Math.sin(sAngle) * sDist * 0.6, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }

        // Puffs of cartoon air at backpack opening when balloons emerge
        if (escapeFrame >= 10 && escapeFrame <= 26) {
          const puffProg = (escapeFrame - 10) / 16;
          ctx.fillStyle = `rgba(255, 255, 255, ${0.7 * (1 - puffProg)})`;
          ctx.beginPath();
          ctx.arc(-8, -10 - puffProg * 18, 6 + puffProg * 8, 0, Math.PI * 2);
          ctx.arc(8, -12 - puffProg * 18, 7 + puffProg * 8, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore(); // end balloons
      }

      // Front Hooves (resting on ground if tied, kicking happily if escaping)
      const hoofKick = isEscapingWithBalloons ? Math.sin(escapeFrame * 0.2) * 8 : 0;
      ctx.fillStyle = '#1f2937';
      ctx.beginPath();
      ctx.roundRect(-24, 8 + hoofKick, 8, 14, 3);
      ctx.roundRect(-10, 8 - hoofKick, 8, 14, 3);
      ctx.fill();

      // Head
      ctx.save();
      ctx.translate(-24, -20 + breathe);
      if (isEscapingWithBalloons && escapeFrame >= 38) {
        ctx.rotate(0.1 + Math.sin(escapeFrame * 0.15) * 0.08); // happy upright head
      } else {
        ctx.rotate(-0.15 + Math.sin(frame * 0.05) * 0.04); // sad drooping head
      }

      // Head shape
      ctx.fillStyle = '#1f2937';
      ctx.beginPath();
      ctx.ellipse(0, 0, 14, 15, 0, 0, Math.PI * 2);
      ctx.fill();

      // Drooping or perky ears
      ctx.fillStyle = '#1f2937';
      ctx.beginPath();
      if (isEscapingWithBalloons && escapeFrame >= 38) {
        // Happy fluttering ears
        ctx.ellipse(-14, -2, 5, 11, -0.4, 0, Math.PI * 2);
        ctx.ellipse(8, -2, 4, 10, 0.4, 0, Math.PI * 2);
      } else {
        ctx.ellipse(-14, 4, 5, 11, 0.4, 0, Math.PI * 2);
        ctx.ellipse(8, 6, 4, 10, -0.4, 0, Math.PI * 2);
      }
      ctx.fill();

      // Pink inner ear
      ctx.fillStyle = '#f472b6';
      ctx.beginPath();
      ctx.ellipse(-14, isEscapingWithBalloons && escapeFrame >= 38 ? -2 : 4, 2.5, 7, 0.4, 0, Math.PI * 2);
      ctx.fill();

      // Sheep Horns
      ctx.strokeStyle = '#d97706';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(-10, -10, 8, Math.PI * 0.3, Math.PI * 1.5, false);
      ctx.stroke();

      // EYES: Dizzy spiral if defeated VS Sparkling joy if escaping!
      if (isEscapingWithBalloons && escapeFrame >= 38) {
        // Huge Joyful Cartoon Eyes ^_^ with sparkling stars
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-5, -2, 6, 0, Math.PI * 2);
        ctx.arc(5, -2, 6, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#1e3a8a';
        ctx.beginPath();
        ctx.arc(-4, -2, 3.5, 0, Math.PI * 2);
        ctx.arc(6, -2, 3.5, 0, Math.PI * 2);
        ctx.fill();

        // White shine reflection
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-5, -3, 1.8, 0, Math.PI * 2);
        ctx.arc(5, -3, 1.8, 0, Math.PI * 2);
        ctx.fill();

        // Cheerful open smiling mouth
        ctx.fillStyle = '#be123c';
        ctx.beginPath();
        ctx.arc(0, 8, 5, 0, Math.PI);
        ctx.fill();
        ctx.fillStyle = '#fb7185'; // tongue
        ctx.beginPath();
        ctx.arc(0, 10, 3, 0, Math.PI);
        ctx.fill();
      } else {
        // Spiral dizzy eyes!
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-5, -1, 5, 0, Math.PI * 2);
        ctx.arc(5, -1, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#1e3a8a';
        ctx.lineWidth = 1.8;
        const spin = frame * 0.15;
        ctx.beginPath();
        ctx.arc(-5, -1, 2.5, spin, spin + Math.PI * 1.4);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(5, -1, 2.5, -spin, -spin + Math.PI * 1.4);
        ctx.stroke();

        // Sad mouth
        ctx.strokeStyle = '#9ca3af';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 9, 4, Math.PI * 1.1, Math.PI * 1.9, true);
        ctx.stroke();
      }

      ctx.restore(); // end head

      // Extended Hind Leg
      const legTwitch = (frame % 80 < 12) ? Math.sin(frame * 0.8) * 4 : 0;
      const legX = 26 + legTwitch;
      const legY = 6;

      ctx.strokeStyle = '#1f2937';
      ctx.lineWidth = 7;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(14, -2);
      ctx.lineTo(legX, legY);
      ctx.stroke();

      // Black Hoof at tip
      ctx.fillStyle = '#111827';
      ctx.beginPath();
      ctx.roundRect(legX - 2, legY - 5, 9, 10, 2);
      ctx.fill();

      ctx.restore(); // end sheep

      // -------------------------------------------------------------
      // B. EL-MOALLIM BASYOUNI (TYING VS SHOCKED TUMBLE)
      // -------------------------------------------------------------
      ctx.save();
      const isShocked = isEscapingWithBalloons && escapeFrame >= 38;
      const tumbleAngle = isShocked ? Math.min(0.55, (escapeFrame - 38) * 0.04) : 0;
      const tumbleX = isShocked ? 45 + Math.min(28, (escapeFrame - 38) * 1.8) : 45;
      const tumbleY = isShocked ? -28 + Math.min(18, (escapeFrame - 38) * 1.2) : -28;

      ctx.translate(tumbleX, tumbleY);
      ctx.rotate(tumbleAngle);

      // Butcher Body
      ctx.fillStyle = '#1e3a8a';
      ctx.beginPath();
      ctx.ellipse(0, 0 + breathe * 0.5, 26, 32, -0.2, 0, Math.PI * 2);
      ctx.fill();

      // White butcher apron with straps
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.moveTo(-12, -26);
      ctx.lineTo(14, -24);
      ctx.lineTo(18, 16);
      ctx.lineTo(-14, 18);
      ctx.closePath();
      ctx.fill();

      // Galabeya Hem & Legs
      ctx.fillStyle = '#172554';
      ctx.fillRect(-18, 26, 14, 18);
      ctx.fillRect(4, 26, 14, 18);

      // Baladi leather slippers
      ctx.fillStyle = '#7c2d12';
      ctx.beginPath();
      ctx.roundRect(-22, 42, 20, 8, 3);
      ctx.roundRect(2, 42, 20, 8, 3);
      ctx.fill();

      // Head & Red Tarboosh
      ctx.save();
      ctx.translate(0, -38 + breathe * 0.6);

      // Face
      ctx.fillStyle = '#fdba74';
      ctx.beginPath();
      ctx.arc(0, 0, 16, 0, Math.PI * 2);
      ctx.fill();

      // Red Tarboosh
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.moveTo(-13, -12);
      ctx.lineTo(13, -12);
      ctx.lineTo(11, -28);
      ctx.lineTo(-11, -28);
      ctx.closePath();
      ctx.fill();

      // Black tassel (flies upwards in shock!)
      ctx.strokeStyle = '#111827';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(0, -28);
      if (isShocked) {
        ctx.lineTo(18, -36); // flying back
      } else {
        ctx.lineTo(15, -20);
      }
      ctx.stroke();

      if (isShocked) {
        // Shocked O_O Eyes
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-6, -2, 5, 0, Math.PI * 2);
        ctx.arc(6, -2, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#111827';
        ctx.beginPath();
        ctx.arc(-6, -2, 2.2, 0, Math.PI * 2);
        ctx.arc(6, -2, 2.2, 0, Math.PI * 2);
        ctx.fill();

        // Giant Eyebrows raised in shock
        ctx.strokeStyle = '#111827';
        ctx.lineWidth = 2.8;
        ctx.beginPath();
        ctx.moveTo(-11, -10); ctx.lineTo(-2, -8);
        ctx.moveTo(11, -10); ctx.lineTo(2, -8);
        ctx.stroke();

        // Giant Open Shocked Mouth "O"
        ctx.fillStyle = '#881337';
        ctx.beginPath();
        ctx.ellipse(0, 12, 6, 8, 0, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Laughing smug face
        ctx.strokeStyle = '#111827';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.arc(-6, -1, 3.5, Math.PI * 1.1, Math.PI * 1.9, false);
        ctx.arc(6, -1, 3.5, Math.PI * 1.1, Math.PI * 1.9, false);
        ctx.stroke();

        // Mustache
        ctx.fillStyle = '#111827';
        ctx.beginPath();
        ctx.moveTo(-18, 6);
        ctx.quadraticCurveTo(0, -4, 18, 6);
        ctx.quadraticCurveTo(0, 14, -18, 6);
        ctx.fill();
      }

      ctx.restore(); // end head

      // Butcher Arms
      if (isShocked) {
        // Arms thrown up in comic despair
        ctx.strokeStyle = '#fdba74';
        ctx.lineWidth = 8;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(-14, -14); ctx.lineTo(-35, -45);
        ctx.moveTo(12, -14); ctx.lineTo(35, -42);
        ctx.stroke();
      } else {
        // Tying arms
        const knotPull = Math.sin(tieCycle) * 6;
        ctx.strokeStyle = '#fdba74';
        ctx.lineWidth = 8;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(-14, -14);
        ctx.quadraticCurveTo(-30, 0, -48 + knotPull * 0.5, 12);
        ctx.moveTo(12, -14);
        ctx.quadraticCurveTo(-10, 8, -42 - knotPull * 0.5, 16);
        ctx.stroke();
      }

      ctx.restore(); // end butcher

      // -------------------------------------------------------------
      // C. THE ROPE (INTACT VS SNAPPED BY BALLOONS)
      // -------------------------------------------------------------
      const currentHoofX = -50 + sheepSway + 26;
      const currentHoofY = -18 - sheepLiftY + 6;

      ctx.save();
      ctx.strokeStyle = '#d97706';
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';

      if (!isEscapingWithBalloons || escapeFrame < 38) {
        // Tension / Vibrate as balloon pulls up
        const tensionVibrate = isEscapingWithBalloons ? Math.sin(escapeFrame * 1.4) * 3 : 0;
        
        // Coils around ankle
        for (let c = -1; c <= 1; c++) {
          ctx.beginPath();
          ctx.ellipse(currentHoofX + c * 3, currentHoofY, 5, 8, 0.4, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Rope to post
        const postWorldX = (postX - centerX) / sceneScale;
        const postWorldY = (postY - 18 - baseY) / sceneScale;
        ctx.beginPath();
        ctx.moveTo(currentHoofX, currentHoofY + tensionVibrate);
        ctx.quadraticCurveTo((currentHoofX + postWorldX) * 0.4, Math.max(currentHoofY + 8, postWorldY + 14), postWorldX, postWorldY);
        ctx.stroke();
      } else {
        // 💥 ROPE IS SNAPPED!
        // 1. Broken coil remains on flying sheep's hoof with frayed dangling tail
        ctx.beginPath();
        ctx.ellipse(currentHoofX, currentHoofY, 4, 7, 0.4, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(currentHoofX, currentHoofY);
        ctx.lineTo(currentHoofX - 4, currentHoofY + 12);
        ctx.stroke();

        // 2. Loose broken rope lying on ground to post
        const postWorldX = (postX - centerX) / sceneScale;
        const postWorldY = (postY - 18 - baseY) / sceneScale;
        ctx.beginPath();
        ctx.moveTo(10, 4);
        ctx.quadraticCurveTo((10 + postWorldX) * 0.5, postWorldY + 12, postWorldX, postWorldY);
        ctx.stroke();

        // Spawn explosive fiber particles on snap
        if (escapeFrame === 38) {
          for (let p = 0; p < 18; p++) {
            const angle = Math.random() * Math.PI * 2;
            const spd = 2 + Math.random() * 5;
            escapeParticles.push({
              x: currentHoofX,
              y: currentHoofY,
              vx: Math.cos(angle) * spd,
              vy: Math.sin(angle) * spd,
              color: Math.random() > 0.4 ? '#f59e0b' : '#b45309',
              size: 2 + Math.random() * 2.5,
              life: 0,
              maxLife: 30 + Math.random() * 20
            });
          }
        }
      }

      ctx.restore();

      // Render escape particles
      for (let i = escapeParticles.length - 1; i >= 0; i--) {
        const pt = escapeParticles[i];
        pt.x += pt.vx;
        pt.y += pt.vy;
        pt.life++;
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, Math.max(0.5, pt.size * (1 - pt.life / pt.maxLife)), 0, Math.PI * 2);
        ctx.fill();
        if (pt.life >= pt.maxLife) {
          escapeParticles.splice(i, 1);
        }
      }

      ctx.restore(); // end characters

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, [woolColor, isEscapingWithBalloons, onEscapeComplete]);

  return (
    <div className="absolute inset-0 w-full h-full pointer-events-none overflow-hidden select-none">
      {/* 60fps HTML5 Canvas rendering Basyouni & Sheep tying animation + Balloon Escape */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full object-cover"
      />

      {/* Tying Action Banner - shown while watching tying cutscene before modal reveals */}
      {!isModalVisible && !isEscapingWithBalloons && (
        <div className="absolute top-4 sm:top-6 left-1/2 -translate-x-1/2 z-10 transition-all duration-300">
          <div className="bg-red-700/90 border-2 border-yellow-400 text-yellow-100 text-xs sm:text-sm font-black px-4 py-1.5 rounded-full shadow-2xl backdrop-blur-sm flex items-center gap-2 animate-pulse whitespace-nowrap">
            <span>🪢 المعلم بسيوني يربط الخروف بالحبل! 🥩</span>
          </div>
        </div>
      )}

      {/* 🎈 CELEBRATORY ESCAPE BANNER WHEN RESUMING WITH BALLOONS */}
      {isEscapingWithBalloons && (
        <div className="absolute top-4 sm:top-6 left-1/2 -translate-x-1/2 z-30 transition-all duration-300 w-[92%] max-w-sm">
          <div className="bg-gradient-to-r from-rose-600 via-pink-600 to-amber-500 border-2 border-yellow-300 text-white text-xs sm:text-sm font-black px-4 py-2 rounded-2xl shadow-2xl backdrop-blur-md flex items-center justify-center gap-2 animate-bounce text-center">
            <span className="text-xl">🎈🚀</span>
            <span>انقطع الحبل! الخروف طار بالبالونات فوق المعلم! ✨</span>
          </div>
        </div>
      )}

      {/* Floating Animated Speech Bubble from El-Moallim Basyouni */}
      {basyouniQuote && (
        <div className={`absolute left-1/2 -translate-x-1/2 z-10 transition-all duration-300 ${!isModalVisible ? 'top-14 sm:top-18' : 'top-2 sm:top-3 opacity-90 scale-90'}`}>
          <div className="bg-gradient-to-r from-amber-900/90 to-red-900/90 border-2 border-yellow-400 text-yellow-100 text-xs sm:text-sm font-black px-4 py-2 rounded-2xl shadow-2xl backdrop-blur-sm flex items-center gap-2 max-w-[92vw] sm:max-w-md text-center whitespace-nowrap animate-bounce">
            <span className="text-xl">🥩</span>
            <span>{basyouniQuote}</span>
          </div>
        </div>
      )}
    </div>
  );
}
