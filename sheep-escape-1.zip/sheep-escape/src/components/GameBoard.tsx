/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState } from 'react';
import { 
  GameState, 
  PlayerState, 
  GameObstacle, 
  GameCoin, 
  Particle, 
  DecorativeAsset, 
  PowerUp,
  LaneType,
  ObstacleType,
  DailyChallenge,
  ControlMode,
  WeatherType,
  WeatherParticle
} from '../types';
import { gameSounds } from './SoundManager';
import { OUTFITS, FUNNY_QUOTES } from '../utils/gameData';
import {
  WEATHER_PRESETS,
  WEATHER_CYCLE,
  createWeatherParticles,
  updateWeatherParticles,
  drawWeatherSky,
  drawSunAndRays,
  drawEgyptianPigeons,
  drawHeatShimmer,
  drawKhamaseenSandWisps,
  drawWeatherParticles,
  drawWeatherAtmosphere,
} from '../utils/weatherSystem';
import {
  createInitialIntroState,
  updateIntroPhysics,
  drawIntroCutscene,
  IntroState
} from '../utils/introCutscene';
import TutorialOverlay from './TutorialOverlay';
import RewardedAdModal from './RewardedAdModal';
import { isConnected } from '../utils/connection';
import { APP_CONFIG } from '../config';

// Ensure canvas roundRect is polyfilled for all browsers, webviews, and iframes
if (typeof CanvasRenderingContext2D !== 'undefined' && !CanvasRenderingContext2D.prototype.roundRect) {
  CanvasRenderingContext2D.prototype.roundRect = function (
    this: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    radii: number | number[] = 0
  ) {
    const r = typeof radii === 'number' ? radii : (Array.isArray(radii) ? radii[0] || 0 : 0);
    const radius = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
    this.beginPath();
    this.moveTo(x + radius, y);
    this.arcTo(x + w, y, x + w, y + h, radius);
    this.arcTo(x + w, y + h, x, y + h, radius);
    this.arcTo(x, y + h, x, y, radius);
    this.arcTo(x, y, x + radius, y, radius);
    this.closePath();
    return this;
  };
}

interface GameBoardProps {
  gameState: GameState;
  setGameState: (state: GameState) => void;
  activeOutfitId: string;
  addClovers: (amount: number) => void;
  subClovers?: (amount: number) => void;
  cloversTotal?: number;
  updateScoreAndDistance: (score: number, distance: number) => void;
  score: number;
  distance: number;
  cloversCollected: number;
  setCloversCollected: React.Dispatch<React.SetStateAction<number>>;
  magnetLevel: number;
  cornLevel?: number;
  shieldLevel?: number;
  fattaLevel?: number;
  goldenCloverLevel?: number;
  eidBalloons?: number;
  useEidBalloon?: () => boolean;
  addEidBalloons?: (count: number) => void;
  onGameOver: (finalScore: number, finalClovers: number) => void;
  challenges: DailyChallenge[];
  onChallengeProgress: (id: string, progress: number) => void;
  onChallengeCompleted: (id: string, reward: number, title: string) => void;
  onObstacleCollision?: () => void;
  controlMode: ControlMode;
  resumedWithBalloons?: boolean;
  onConsumeResume?: () => void;
  key?: React.Key;
}

export default function GameBoard({
  gameState,
  setGameState,
  activeOutfitId,
  addClovers,
  subClovers,
  cloversTotal = 0,
  updateScoreAndDistance,
  score,
  distance,
  cloversCollected,
  setCloversCollected,
  magnetLevel,
  cornLevel = 1,
  shieldLevel = 1,
  fattaLevel = 1,
  goldenCloverLevel = 1,
  eidBalloons = 0,
  useEidBalloon,
  addEidBalloons,
  onGameOver,
  challenges,
  onChallengeProgress,
  onChallengeCompleted,
  onObstacleCollision,
  controlMode,
  resumedWithBalloons = false,
  onConsumeResume,
}: GameBoardProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Core Game Loop variables in refs to avoid React re-render overhead at 60fps
  const stateRef = useRef({
    player: {
      lane: 1 as LaneType,
      targetX: 0,
      currentX: 0,
      y: 0,
      vy: 0,
      isJumping: false,
      isDucking: false,
      duckProgress: 0,
      activeOutfit: activeOutfitId,
      cloversCollected: 0,
      score: 0,
      distance: 0,
      butcherDistance: 70, // 0 = caught, 100 = safe far away
      warningFlash: false,
      extraLifeUsed: false,
      boxerShieldUsed: false, // خروف الملاكم تايسون: تدمير عقبة واحدة بدون خسارة
      canDoubleJump: false,   // خروف كابتن الملاعب: القفز المزدوج
    } as PlayerState,
    obstacles: [] as GameObstacle[],
    coins: [] as GameCoin[],
    decorations: [] as DecorativeAsset[],
    particles: [] as Particle[],
    gameSpeed: 5.8, // Initial scroll speed
    obstacleSpawnDistAccumulator: 0,
    coinSpawnDistAccumulator: 0,
    decSpawnDistAccumulator: 0,
    powerups: {
      MAGNET: { durationLeft: 0, maxDuration: 360 + magnetLevel * 60 } as PowerUp,
      BOOST: { durationLeft: 0, maxDuration: 360 + (cornLevel || 1) * 60 } as PowerUp, // Corn Boost (speed + 2x points)
      SHIELD: { durationLeft: 0, maxDuration: 400 + (shieldLevel || 1) * 80 } as PowerUp,
      NITRO: { durationLeft: 0, maxDuration: 360 } as PowerUp, // شطة الجزار النارية
    },
    obstacleIdCounter: 0,
    coinIdCounter: 0,
    decIdCounter: 0,
    elapsedFrames: 0,
    timeOfDay: 0, // values from 0 to 3600 frames for smooth Day -> Sunset -> Night -> Sunrise flows
    comboCount: 0, // combo counter for consecutive collections
    comboTimer: 0, // frame counter decay for combo life
    cloverStreak: 0, // for increasing points from clover
    cloverStreakTimer: 0, // decays if no clover collected
    roundCornCount: 0,
    roundCloverCount: 0,
    lastDodgeTime: 0, // rate limiter for close call alerts
    isHurtCooldown: 0,
    butcherAnimFrame: 0,
    roadOffset: 0,
    fattaStardustTimer: 0,
    lastLaneChangeTime: 0,
    runningSpeechBubble: {
      text: '',
      timer: 0,
    },
    butcherSpeechBubble: {
      text: '',
      timer: 0,
    },
    avoidedStreak: 0,
    textIdCounter: 0,
    floatingTexts: [] as { id: number; text: string; x: number; y: number; color: string; life: number; vy: number }[],
    weather: 'SUNNY_HEAT' as WeatherType,
    weatherParticles: [] as WeatherParticle[],
    weatherTimer: 0,
    weatherCycleIndex: 0,
    intro: createInitialIntroState(),
  });

  // Track state for Game Intro Cutscene UI
  const [isIntroActive, setIsIntroActive] = useState(true);

  // Skip intro cutscene and jump straight to running
  const skipIntro = () => {
    const s = stateRef.current;
    if (s.intro.active) {
      s.intro.active = false;
      s.intro.timer = s.intro.maxFrames;
      setIsIntroActive(false);
    }
  };

  // Track state for UI elements (synchronized from ref periodically)
  const [hudStats, setHudStats] = useState({
    score: 0,
    distance: 0,
    clovers: 0,
    butcherDist: 70,
    activeMagnet: 0,
    activeBoost: 0,
    activeNitro: 0,
    activeNitroFrames: 0,
    activeNitroMax: 360,
    activeShield: 0,
    speechBubbleText: '',
    comboCount: 0,
    comboTimer: 0,
    cloverStreak: 0,
    currentWeather: 'SUNNY_HEAT' as WeatherType,
  });

  // Tutorial Overlay state for new players
  const [showTutorial, setShowTutorial] = useState<boolean>(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage.getItem('sheep_game_tutorial_completed') !== 'true';
      }
    } catch (e) {}
    return true;
  });

  // Revival Modal (بالونات العيد Extra Life & فرار سريع) State
  const [isReviveActive, setIsReviveActive] = useState(false);
  const isReviveActiveRef = useRef(false);
  const [reviveTimer, setReviveTimer] = useState(5);
  const [showReviveAd, setShowReviveAd] = useState(false);
  const [isBalloonFloating, setIsBalloonFloating] = useState(false);
  const showTutorialRef = useRef(showTutorial);

  useEffect(() => {
    showTutorialRef.current = showTutorial;
  }, [showTutorial]);

  useEffect(() => {
    isReviveActiveRef.current = isReviveActive;
  }, [isReviveActive]);

  // Manage Revival Countdown timer (5 seconds, paused while watching ad)
  useEffect(() => {
    let interval: number;
    if (isReviveActive && !showReviveAd) {
      interval = window.setInterval(() => {
        setReviveTimer((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            handleDeclineRevive();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isReviveActive, showReviveAd]);

  const resumeConsumedRef = useRef(false);

  // Handle game continuation when resumed with Eid Balloons from Game Over screen
  useEffect(() => {
    if (resumedWithBalloons && !resumeConsumedRef.current) {
      resumeConsumedRef.current = true;
      const s = stateRef.current;
      s.player.score = score || 0;
      s.player.distance = distance || 0;
      s.player.cloversCollected = cloversCollected || 0;
      s.player.butcherDistance = 88;
      s.isHurtCooldown = 240; // 4 seconds invulnerability
      s.powerups.SHIELD.durationLeft = 240;
      s.intro.active = false;
      setIsIntroActive(false);
      setIsBalloonFloating(true);
      setTimeout(() => setIsBalloonFloating(false), 3800);
      // Clear close obstacles in front once so player lands smoothly without collision
      s.obstacles = s.obstacles.filter(ob => ob.z > 300 || ob.z < -20);
      // Clear old stacked floating texts and show clean celebratory text
      s.floatingTexts = [];
      setHudStats(prev => ({
        ...prev,
        score: score || 0,
        distance: distance || 0,
        clovers: cloversCollected || 0,
        butcherDist: 88,
        activeShield: 4, // 4 seconds
      }));
      const canvas = canvasRef.current;
      if (canvas) {
        const w = canvas.width / window.devicePixelRatio;
        const h = canvas.height / window.devicePixelRatio;
        addFloatingText("طرت بالبالونات وهربت من المعلم! 🎈🎉", w / 2, h - 140, '#ec4899');
      }
      onConsumeResume?.();
    } else if (!resumedWithBalloons) {
      resumeConsumedRef.current = false;
    }
  }, [resumedWithBalloons, onConsumeResume]);

  const executeRevive = (reasonText: string = "فرار سريع أنقذك! استمر في الهروب! 🏃‍♂️💨") => {
    const s = stateRef.current;
    const p = s.player;
    setIsReviveActive(false);
    setShowReviveAd(false);
    p.butcherDistance = 85;
    s.isHurtCooldown = 210; // 3.5s invulnerable
    s.powerups.SHIELD.durationLeft = 210;
    // Clear obstacles in vicinity
    s.obstacles = s.obstacles.filter(ob => ob.z > 350 || ob.z < -20);
    gameSounds.playBalloonRevive();
    setIsBalloonFloating(true);
    setTimeout(() => setIsBalloonFloating(false), 3500);

    const canvas = canvasRef.current;
    if (canvas) {
      const w = canvas.width / window.devicePixelRatio;
      const h = canvas.height / window.devicePixelRatio;
      const hTargetLine = h - 110;
      addFloatingText(reasonText, w / 2 + p.currentX, hTargetLine - p.y - 30, '#ec4899');
    }
  };

  const handleUseReviveBalloon = () => {
    let success = false;
    if (useEidBalloon && useEidBalloon()) {
      success = true;
    } else if (subClovers && (cloversTotal || 0) >= 60) {
      subClovers(60);
      success = true;
    }

    if (success) {
      executeRevive("بالونة العيد أنقذتك! استمر في الهروب! 🎈🎉");
    }
  };

  const handleDeclineRevive = () => {
    setIsReviveActive(false);
    const s = stateRef.current;
    const p = s.player;
    p.butcherDistance = 0;
    onGameOver(p.score, p.cloversCollected);
    setGameState(GameState.GAME_OVER);
  };

  // Weather Toast Announcement Notification State
  const [weatherToast, setWeatherToast] = useState<{
    text: string;
    subtitle: string;
    emoji: string;
  } | null>({
    text: WEATHER_PRESETS.SUNNY_HEAT.announcement,
    subtitle: WEATHER_PRESETS.SUNNY_HEAT.subtitle,
    emoji: WEATHER_PRESETS.SUNNY_HEAT.badgeEmoji,
  });

  // Auto-dismiss weather toast after 3.8 seconds
  useEffect(() => {
    if (!weatherToast) return;
    const timer = setTimeout(() => {
      setWeatherToast(null);
    }, 3800);
    return () => clearTimeout(timer);
  }, [weatherToast]);

  // Weather switcher interface
  const changeWeather = (newWeather?: WeatherType) => {
    const s = stateRef.current;
    if (newWeather) {
      s.weather = newWeather;
      s.weatherCycleIndex = WEATHER_CYCLE.indexOf(newWeather);
    } else {
      s.weatherCycleIndex = (s.weatherCycleIndex + 1) % WEATHER_CYCLE.length;
      s.weather = WEATHER_CYCLE[s.weatherCycleIndex];
    }
    s.weatherTimer = 0;
    const cfg = WEATHER_PRESETS[s.weather];
    setHudStats(prev => ({ ...prev, currentWeather: s.weather }));
    setWeatherToast({
      text: cfg.announcement,
      subtitle: cfg.subtitle,
      emoji: cfg.badgeEmoji,
    });
  };

  // Handle active outfit prop change
  useEffect(() => {
    stateRef.current.player.activeOutfit = activeOutfitId;
  }, [activeOutfitId]);

  // Keys state
  const keysPressed = useRef<{ [key: string]: boolean }>({});

  // Setup canvas size & scale
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const rect = container.getBoundingClientRect();
      // Set resolution
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      }

      // Initialize ambient weather particles pool if empty
      if (stateRef.current.weatherParticles.length === 0) {
        stateRef.current.weatherParticles = createWeatherParticles(45, rect.width, rect.height);
      }
    };

    window.addEventListener('resize', handleResize);
    // Double trigger to ensure sizing is ready
    setTimeout(handleResize, 100);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Keyboard and Gestures listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState !== GameState.PLAYING || isOfflineFrozenRef.current || !isConnected()) return;
      
      const key = e.key;
      keysPressed.current[key] = true;

      if (key === 'ArrowLeft' || key === 'a' || key === 'A') {
        changeLane(-1);
      } else if (key === 'ArrowRight' || key === 'd' || key === 'D') {
        changeLane(1);
      } else if (key === 'ArrowUp' || key === 'w' || key === 'W' || key === ' ') {
        triggerJump();
        e.preventDefault();
      } else if (key === 'ArrowDown' || key === 's' || key === 'S') {
        triggerDuck();
        e.preventDefault();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current[e.key] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameState]);

  // Command interfaces
  const changeLane = (direction: number) => {
    if (isOfflineFrozenRef.current || !isConnected() || gameState !== GameState.PLAYING) return;
    if (stateRef.current.intro.active) {
      skipIntro();
      return;
    }
    const p = stateRef.current.player;
    if (p.isDucking && p.duckProgress > 45) return; // Cant change lanes if slide is tightly locked

    const now = Date.now();
    if (now - stateRef.current.lastLaneChangeTime < 140) return; // rate limit lane switching

    let targetLane = p.lane + direction;
    if (targetLane < 0) targetLane = 0;
    if (targetLane > 2) targetLane = 2;

    if (p.lane !== targetLane) {
      const s = stateRef.current;
      const prevLane = p.lane;
      p.lane = targetLane as LaneType;
      s.lastLaneChangeTime = now;
      gameSounds.playSlide();
      
      // Spawn tiny dust particles at old lane
      createDustParticles(p.currentX, 10);

      // Reflex Dodge "Close Call" system!
      const canvas = canvasRef.current;
      if (canvas) {
        const w = canvas.width / window.devicePixelRatio;
        const h = canvas.height / window.devicePixelRatio;
        const hTargetLine = h - 110;

        // Find if an obstacle is dangerously close in the lane we just evacuated
        const closeObstacle = s.obstacles.find(ob => ob.lane === prevLane && ob.z < 180 && ob.z > 30);
        if (closeObstacle && now - s.lastDodgeTime > 1800) {
          s.lastDodgeTime = now;
          const sheepScreenX = w / 2 + p.currentX;
          const sheepScreenY = hTargetLine - p.y - 25;
          const dodgeBonus = 150;
          p.score += dodgeBonus;
          addFloatingText(`يا لعيب! فلتت! +${dodgeBonus} 🛡️✨`, sheepScreenX, sheepScreenY - 30, '#10b981');
          
          // Synthesize an elite retro double note reflex sound (C6 to G6)
          try {
            const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.frequency.setValueAtTime(1046.50, audioCtx.currentTime); // C6
            osc.frequency.setValueAtTime(1567.98, audioCtx.currentTime + 0.08); // G6
            gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.35);
          } catch (e) {}
        }
      }

      // 10% chance sheep says a funny quote when switching lane
      if (Math.random() < 0.15) {
        triggerSpeechBubble();
      }
    }
  };

  const triggerJump = () => {
    if (isOfflineFrozenRef.current || !isConnected() || gameState !== GameState.PLAYING) return;
    if (stateRef.current.intro.active) {
      skipIntro();
      return;
    }
    const p = stateRef.current.player;
    // القفز يلغي الانزلاق فوراً بدل تجاهل الأمر
    if (p.isDucking) {
      p.isDucking = false;
      p.duckProgress = 0;
    }

    if (!p.isJumping) {
      p.isJumping = true;
      p.vy = 12.8; // jump impulse
      p.canDoubleJump = p.activeOutfit === 'captain_stadium';
      gameSounds.playJump();
    } else if (p.canDoubleJump && p.activeOutfit === 'captain_stadium') {
      p.canDoubleJump = false;
      p.vy = 12.2; // Acrobatic second jump boost
      gameSounds.playDoubleJump();

      const canvas = canvasRef.current;
      if (canvas) {
        const w = canvas.width / window.devicePixelRatio;
        const h = canvas.height / window.devicePixelRatio;
        const hTargetLine = h - 110;
        const sheepScreenX = w / 2 + p.currentX;
        const sheepScreenY = hTargetLine - p.y - 25;
        addFloatingText("دبل جمب الكابتن! ⚽🚀", sheepScreenX, sheepScreenY - 30, '#38bdf8');
      }
      createDustParticles(p.currentX, 10);
    }
  };

  const triggerDuck = () => {
    if (isOfflineFrozenRef.current || !isConnected() || gameState !== GameState.PLAYING) return;
    if (stateRef.current.intro.active) {
      skipIntro();
      return;
    }
    const p = stateRef.current.player;
    if (!p.isDucking) {
      p.isDucking = true;
      p.duckProgress = 80; // duration in frames
      if (p.isJumping) {
        // Diving down quickly
        p.vy = -8;
      }
      gameSounds.playSlide();
    }
  };

  const triggerSpeechBubble = () => {
    const index = Math.floor(Math.random() * FUNNY_QUOTES.length);
    stateRef.current.runningSpeechBubble.text = FUNNY_QUOTES[index];
    stateRef.current.runningSpeechBubble.timer = 120; // Show for 2 seconds
  };

  const BUTCHER_QUOTES = [
    "خد هنا يا خروف يا فلتان! 🔪🏃‍♂️",
    "طب والله لأعملك كباب وطرب على أول ناصية! 🍢",
    "يا خروف السعد.. بساط الفتة بيناديك! 🥩",
    "الساطور ده ملوش صاحب.. هجيبك هجيبك! 💥",
    "العلبة بالصلصة جاهزة.. ناقصها فخدتك يا سمين! 🍛",
    "المعلم بسيوني وراك والزمن طويل! ⚖️",
    "أنا ساطوري حامي وسريع.. اقف مكانك يا غاوي تعب! 🏃‍♂️",
    "هو دة جري ولا طيران يا بن الإيه؟! 😱🚀",
    "تعاميت ولا إيه ده أنت ركبت بساط الفتة! 🛸🍲"
  ];

  const triggerButcherSpeechBubble = (customText?: string) => {
    const text = customText || BUTCHER_QUOTES[Math.floor(Math.random() * BUTCHER_QUOTES.length)];
    stateRef.current.butcherSpeechBubble.text = text;
    stateRef.current.butcherSpeechBubble.timer = 125;
  };

  // Particles generator
  const createDustParticles = (x: number, count: number) => {
    const particles = stateRef.current.particles;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const h = canvas.height / window.devicePixelRatio;

    for (let i = 0; i < count; i++) {
      particles.push({
        x: x + (Math.random() * 20 - 10),
        y: h - 65 - Math.random() * 15,
        color: `rgba(210, 180, 140, ${0.4 + Math.random() * 0.4})`, // sandy dust
        vx: (Math.random() * 4 - 2),
        vy: -(Math.random() * 2 + 1),
        size: Math.random() * 4 + 3,
        life: 0,
        maxLife: 30 + Math.random() * 20
      });
    }
  };

  // Vibrant clover collection particle system: clover leaves, golden stardust, and expanding shockwave ring
  const createCloverSpark = (x: number, y: number, streak: number = 1) => {
    const particles = stateRef.current.particles;
    const streakBonus = Math.min(6, Math.floor(streak / 2));

    // 1. Expanding energy shockwave ring (Emerald / Golden)
    particles.push({
      x: x,
      y: y,
      color: streak > 2 ? '#4ade80' : '#22c55e',
      vx: 0,
      vy: -0.3,
      size: 26 + streakBonus * 3,
      life: 0,
      maxLife: 18 + streakBonus * 2,
      shape: 'ring'
    });

    // 2. Fluttering Clover Leaf particles (أوراق برسيم زمردية تدور وتتطاير)
    const leafColors = ['#22c55e', '#16a34a', '#4ade80', '#86efac', '#15803d'];
    const leafCount = 8 + streakBonus * 2;
    for (let i = 0; i < leafCount; i++) {
      const angle = (Math.PI * 2 * i) / leafCount + (Math.random() * 0.4 - 0.2);
      const speed = 2.2 + Math.random() * 3.8;
      particles.push({
        x: x + (Math.random() * 8 - 4),
        y: y + (Math.random() * 8 - 4),
        color: leafColors[Math.floor(Math.random() * leafColors.length)],
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.5,
        size: 5 + Math.random() * 4,
        life: 0,
        maxLife: 28 + Math.random() * 16,
        shape: 'leaf',
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() * 0.3 - 0.15),
        gravity: 0.12,
        drag: 0.94
      });
    }

    // 3. Sparkling Golden Stardust Stars (نجوم ذهبية لامعة)
    const starColors = ['#facc15', '#fef08a', '#fbbf24', '#ffffff'];
    const starCount = 6 + streakBonus * 2;
    for (let i = 0; i < starCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.8 + Math.random() * 4.2;
      particles.push({
        x: x,
        y: y,
        color: starColors[Math.floor(Math.random() * starColors.length)],
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.2,
        size: 3.5 + Math.random() * 3.5,
        life: 0,
        maxLife: 22 + Math.random() * 14,
        shape: 'star',
        rotation: Math.random() * Math.PI,
        vRot: (Math.random() * 0.4 - 0.2),
        drag: 0.92
      });
    }

    // 4. Subtle ambient glowing dots
    for (let i = 0; i < 6; i++) {
      particles.push({
        x: x + (Math.random() * 10 - 5),
        y: y + (Math.random() * 10 - 5),
        color: '#bbf7d0',
        vx: (Math.random() * 3 - 1.5),
        vy: (Math.random() * 3 - 2),
        size: 2 + Math.random() * 2,
        life: 0,
        maxLife: 20 + Math.random() * 10,
        shape: 'circle',
        drag: 0.95
      });
    }
  };

  // Spectacular radiant golden burst with glittering stars for Radiant Golden Clover
  const createGoldenCloverParticles = (x: number, y: number) => {
    const particles = stateRef.current.particles;
    const colors = ['#facc15', '#fbbf24', '#f59e0b', '#ffffff', '#fef08a', '#eab308'];
    
    // Radiant Golden shockwave ring
    particles.push({
      x: x,
      y: y,
      color: '#facc15',
      vx: 0,
      vy: -0.5,
      size: 42,
      life: 0,
      maxLife: 24,
      shape: 'ring'
    });

    for (let i = 0; i < 32; i++) {
      const angle = (Math.PI * 2 * i) / 32 + (Math.random() * 0.3 - 0.15);
      const speed = 3.5 + Math.random() * 6.5;
      particles.push({
        x: x,
        y: y,
        color: colors[Math.floor(Math.random() * colors.length)],
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2.0,
        size: Math.random() * 5 + 3,
        life: 0,
        maxLife: 35 + Math.random() * 20,
        shape: i % 2 === 0 ? 'star' : 'leaf',
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() * 0.3 - 0.15),
        gravity: 0.1,
        drag: 0.94
      });
    }
  };

  const addFloatingText = (text: string, x: number, y: number, color: string = '#facc15') => {
    stateRef.current.textIdCounter++;
    stateRef.current.floatingTexts.push({
      id: stateRef.current.textIdCounter,
      text,
      x,
      y,
      color,
      life: 1.0,
      vy: -1.6
    });
  };

  const createFattaRainbowSpark = (x: number, y: number) => {
    const particles = stateRef.current.particles;
    const colors = ['#f87171', '#fb923c', '#fbbf24', '#34d399', '#60a5fa', '#c084fc'];
    for (let i = 0; i < 4; i++) {
      particles.push({
        x: x + (Math.random() * 40 - 20),
        y: y,
        color: colors[Math.floor(Math.random() * colors.length)],
        vx: (Math.random() * 2 - 1),
        vy: (Math.random() * 2 + 1), // floating down
        size: Math.random() * 4 + 2,
        life: 0,
        maxLife: 40 + Math.random() * 20
      });
    }
  };

  const createMagnetTrailParticle = (x: number, y: number) => {
    const particles = stateRef.current.particles;
    for (let i = 0; i < 2; i++) {
      particles.push({
        x: x + (Math.random() * 8 - 4),
        y: y + (Math.random() * 8 - 4),
        color: `rgba(59, 130, 246, ${0.75 + Math.random() * 0.25})`, // Electric magnetic blue
        vx: (Math.random() * 2.4 - 1.2),
        vy: (Math.random() * 2.4 - 1.2),
        size: Math.random() * 3 + 1.5,
        life: 0,
        maxLife: 15 + Math.random() * 10
      });
    }
  };

  const createHurtSpark = (x: number, y: number) => {
    const particles = stateRef.current.particles;
    // Red stars / brown crash smoke
    for (let i = 0; i < 20; i++) {
      particles.push({
        x: x,
        y: y - 20,
        color: Math.random() > 0.4 ? '#ef4444' : '#d97706',
        vx: (Math.random() * 10 - 5),
        vy: (Math.random() * 10 - 5),
        size: Math.random() * 5 + 3,
        life: 0,
        maxLife: 35 + Math.random() * 20
      });
    }
  };

  const isOfflineFrozenRef = useRef(!isConnected());

  const showOfflineOverlay = () => {
    isOfflineFrozenRef.current = true;
    gameSounds.stopMusic();
    if (typeof (window as any).showOfflineOverlay === 'function') {
      (window as any).showOfflineOverlay();
    } else {
      const overlay = document.getElementById('offline-overlay');
      if (overlay) overlay.style.display = 'flex';
    }
  };

  useEffect(() => {
    (window as any).freezeGameMovement = () => {
      isOfflineFrozenRef.current = true;
      gameSounds.stopMusic();
    };

    (window as any).unfreezeGameMovement = () => {
      isOfflineFrozenRef.current = false;
      if (gameState === GameState.PLAYING) {
        gameSounds.startMusic();
      }
    };

    const handleOffline = () => {
      isOfflineFrozenRef.current = true;
      gameSounds.stopMusic();
      showOfflineOverlay();
    };

    const handleOnline = () => {
      isOfflineFrozenRef.current = false;
      if (gameState === GameState.PLAYING) {
        gameSounds.startMusic();
      }
    };

    if (APP_CONFIG.REQUIRE_INTERNET) {
      window.addEventListener('offline', handleOffline);
      window.addEventListener('online', handleOnline);
    }

    return () => {
      delete (window as any).freezeGameMovement;
      delete (window as any).unfreezeGameMovement;
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('online', handleOnline);
    };
  }, [gameState]);

  // Main process Game Loop
  useEffect(() => {
    let animationId: number;
    let lastTime = performance.now();

    const loop = (timestamp: number) => {
      // Freezes all game movement completely if paused or offline, exactly like pressing the pause button!
      if (!isConnected() || isOfflineFrozenRef.current) {
        if (!isConnected() && !isOfflineFrozenRef.current) {
          showOfflineOverlay();
        }
        lastTime = timestamp;
        gameSounds.stopMusic();
        animationId = requestAnimationFrame(loop);
        return;
      }

      if (gameState !== GameState.PLAYING) {
        lastTime = timestamp;
        gameSounds.stopMusic();
        animationId = requestAnimationFrame(loop);
        return;
      }

      if (isReviveActiveRef.current || showTutorialRef.current) {
        lastTime = timestamp;
        drawGame();
        animationId = requestAnimationFrame(loop);
        return;
      }

      const dt = (timestamp - lastTime) / 16.666; // Normalize to 60fps
      lastTime = timestamp;

      updateGame(dt);
      drawGame();

      animationId = requestAnimationFrame(loop);
    };

    if (gameState === GameState.PLAYING) {
      if (isConnected()) {
        isOfflineFrozenRef.current = false;
      }
      if (!isOfflineFrozenRef.current) {
        // Start/Resume background beat
        gameSounds.startMusic();
        animationId = requestAnimationFrame(loop);
      } else {
        gameSounds.stopMusic();
      }
    } else {
      gameSounds.stopMusic();
    }

    return () => {
      cancelAnimationFrame(animationId);
      gameSounds.stopMusic();
    };
  }, [gameState]);

  // 3D Perspective calculation helper:
  // z starts at 1200 on the far horizon vanishing line, down to 0 at the sheep player
  const getPerspective = (
    z: number, 
    w: number, 
    h: number, 
    horizonY: number, 
    hTargetLine: number
  ) => {
    const MAX_Z = 1200;
    const normZ = Math.max(0, (MAX_Z - z) / MAX_Z);
    // Quadratic perspective foreshortening: elements on far horizon stay small and move slowly,
    // then accelerate as they approach the player for a fair and comfortable 3D visual preview
    const perspectiveT = Math.pow(Math.min(1.15, normZ), 2.2);
    const screenY = horizonY + (hTargetLine - horizonY) * perspectiveT;
    
    // Wide track road dimensions filling most of the screen
    const roadBottomHalfWidth = Math.min(w * 0.44, Math.max(w * 0.40, 280));
    const roadTopHalfWidth = Math.max(14, roadBottomHalfWidth * 0.08);
    const currentHalfRoad = roadTopHalfWidth + (roadBottomHalfWidth - roadTopHalfWidth) * perspectiveT;
    const laneSpacing = currentHalfRoad * 0.64;
    
    // Smooth 3D scale: begins small (0.12) right at the horizon and expands gradually to 1.35 at sheep
    const scale = 0.12 + 1.23 * Math.pow(Math.min(1.15, normZ), 1.8);
    
    return { perspectiveT, screenY, laneSpacing, scale, currentHalfRoad, roadBottomHalfWidth, roadTopHalfWidth };
  };

  // Game updates & mechanics
  const updateGame = (dt: number) => {
    // حط السطر ده في أول دالة التحديث بتاعة حركة اللعبة
    if (!isConnected()) {
      showOfflineOverlay(); // يظهر شاشة الجزار قطع النت فوراً ويوقف حركة الخروف
      return;
    }

    const s = stateRef.current;
    s.elapsedFrames++;

    // Increment timeOfDay for smooth dynamic skies and street lantern glows
    s.timeOfDay = (s.timeOfDay + dt) % 3600;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const w = canvas.width / window.devicePixelRatio;
    const h = canvas.height / window.devicePixelRatio;
    const horizonY = h * 0.20;
    const hTargetLine = h - 90;

    // Advance Game Intro Cutscene if active
    if (s.intro.active) {
      updateIntroPhysics(s.intro, dt, w, hTargetLine, () => {
        gameSounds.playCrash();
        gameSounds.playBaa();
        onObstacleCollision?.();
      });
      if (!s.intro.active) {
        setIsIntroActive(false);
      }
      return;
    }

    // Advance Dynamic Egyptian Weather progression
    s.weatherTimer += dt;
    // Transition to next weather every ~900 frames (~15 seconds of gameplay)
    if (s.weatherTimer >= 900) {
      s.weatherTimer = 0;
      s.weatherCycleIndex = (s.weatherCycleIndex + 1) % WEATHER_CYCLE.length;
      s.weather = WEATHER_CYCLE[s.weatherCycleIndex];
      const cfg = WEATHER_PRESETS[s.weather];
      setHudStats(prev => ({ ...prev, currentWeather: s.weather }));
      setWeatherToast({
        text: cfg.announcement,
        subtitle: cfg.subtitle,
        emoji: cfg.badgeEmoji,
      });
    }

    // Update ambient weather particles (sand dust, sun motes, fireflies)
    updateWeatherParticles(s.weatherParticles, s.weather, dt, w, h, horizonY);

    // Decay consecutive collection combo timer
    if (s.comboTimer > 0) {
      s.comboTimer -= dt;
      if (s.comboTimer <= 0) {
        s.comboCount = 0;
        s.comboTimer = 0;
      }
    }

    // 1. Speeds decay & growth complying to selected difficulty with strict Max Speed Caps
    const cornActive = s.powerups.BOOST.durationLeft > 0;
    const nitroActive = (s.powerups.NITRO?.durationLeft || 0) > 0;
    const difficulty = (typeof window !== 'undefined' && localStorage.getItem('sheep_game_difficulty')) || 'normal';
    
    // Balanced Speed Curves & Strict Max Speed Caps
    // سهل: سرعة هادئة ثابتة تقريباً (سقف 6.0)
    // عادي: تسارع تدريجي بطيء حتى يصل للحد الأقصى المريح (سقف 9.2)
    // صعب ناري: تبدأ سريعة ولكن تصمد عند السقف الأقصى للسرعة (سقف 10.8) لمنع تخطي العقبات أو الاختفاء
    let baseTargetSpeed = 5.8;
    let maxSpeedCap = 9.2;

    if (difficulty === 'easy') {
      // سهل: سرعة هادئة ثابتة تقريباً
      const speedGrowth = Math.floor(s.player.distance / 250) * 0.12;
      baseTargetSpeed = Math.min(6.0, 4.8 + speedGrowth);
      maxSpeedCap = 6.0;
    } else if (difficulty === 'hard') {
      // صعب ناري: تبدأ سريعة ولكن تصمد عند السقف الأقصى للسرعة
      const speedGrowth = Math.floor(s.player.distance / 120) * 0.35;
      baseTargetSpeed = Math.min(10.8, 7.8 + speedGrowth);
      maxSpeedCap = 10.8;
    } else {
      // عادي: تسارع تدريجي بطيء حتى يصل للحد الأقصى المريح
      const speedGrowth = Math.floor(s.player.distance / 160) * 0.22;
      baseTargetSpeed = Math.min(9.2, 5.8 + speedGrowth);
      maxSpeedCap = 9.2;
    }
    
    // Nitro gives turbo boost (+3.2), Corn gives (+1.8)
    const boostBonus = nitroActive ? 3.2 : (cornActive ? 1.8 : 0);
    const targetSpeed = nitroActive ? maxSpeedCap + 3.2 : Math.min(maxSpeedCap + 1.2, baseTargetSpeed + boostBonus);
    s.gameSpeed += (targetSpeed - s.gameSpeed) * 0.05 * dt;

    // Adjust synthesized drum music tempo to match running speed
    gameSounds.adjustTempo(Math.min(0.6, Math.max(-0.3, s.gameSpeed / 6.5 - 1)));

    // 2. Play distances decay or catch up
    s.player.distance += (s.gameSpeed * 0.06) * dt;
    // Points multiplier: Nitro x3, Corn x2
    const scoreMultiplier = nitroActive ? 3 : (cornActive ? 2 : 1);
    s.player.score += Math.ceil((s.gameSpeed * 0.15) * dt * scoreMultiplier);

    // Decay clover streak timer
    if (s.cloverStreakTimer > 0) {
      s.cloverStreakTimer -= dt;
      if (s.cloverStreakTimer <= 0) {
        s.cloverStreak = 0;
      }
    }

    // Decaying butcher distance if hurt cooldown is active
    if (s.isHurtCooldown > 0) {
      s.isHurtCooldown -= dt;
    }

    // Butcher system tracking
    if (s.player.butcherDistance < 70) {
      // If safe, butcher slowly falls back to default spacing
      if (s.isHurtCooldown <= 0) {
        s.player.butcherDistance += 0.08 * dt;
        if (s.player.butcherDistance > 70) {
          s.player.butcherDistance = 70;
        }
      }
    }

    // Speech bubble cooling down
    if (s.runningSpeechBubble.timer > 0) {
      s.runningSpeechBubble.timer -= dt;
    }
    if (s.butcherSpeechBubble && s.butcherSpeechBubble.timer > 0) {
      s.butcherSpeechBubble.timer -= dt;
    }

    // Comical random butcher rage yelling while chasing the sheep
    if (s.player.butcherDistance < 72 && (!s.butcherSpeechBubble || s.butcherSpeechBubble.timer <= 0) && Math.random() < 0.0035 * dt) {
      triggerButcherSpeechBubble();
    }

    // Warning screen flash if butcher is dangerously close
    s.player.warningFlash = (s.player.butcherDistance < 40) && (Math.floor(s.elapsedFrames / 10) % 2 === 0);

    // 3. Update active power-ups time
    Object.keys(s.powerups).forEach((key) => {
      const p = s.powerups[key as keyof typeof s.powerups];
      if (p.durationLeft > 0) {
        p.durationLeft -= dt;
        if (p.durationLeft <= 0) {
          p.durationLeft = 0;
          if (key === 'NITRO') {
            gameSounds.playShieldBreak(); // Impact/landing sound on touchdown
            createDustParticles(s.player.currentX, 12);
          } else {
            gameSounds.playShieldBreak(); // audio feedback
          }
        }
      }
    });

    // Flight warning sound alert when Nitro flight is ending soon (within last 1.8 seconds)
    const nitroRemaining = s.powerups.NITRO?.durationLeft || 0;
    if (nitroRemaining > 0 && nitroRemaining <= 110) {
      const beepInterval = nitroRemaining <= 45 ? 12 : 24;
      if (Math.floor(s.elapsedFrames) % beepInterval === 0) {
        const urgencyPitch = 1.0 + ((110 - nitroRemaining) / 110) * 0.6;
        gameSounds.playFlightWarning(urgencyPitch);
      }
    }

    // Corn Boost golden sparkles trail
    const cornBoostActive = s.powerups.BOOST.durationLeft > 0;
    if (cornBoostActive) {
      s.fattaStardustTimer += dt;
      if (s.fattaStardustTimer > 3) {
        const canvas = canvasRef.current;
        if (canvas) {
          createFattaRainbowSpark(s.player.currentX, hTargetLine - s.player.y);
        }
        s.fattaStardustTimer = 0;
      }
    }

    // 4. Update Player lateral position & jumping - WIDE TRACK PERSPECTIVE
    const p = s.player;
    const roadBottomHalfWidth = Math.min(w * 0.44, Math.max(w * 0.40, 280));
    const bottomLaneSpacing = roadBottomHalfWidth * 0.64;
    p.targetX = (p.lane - 1) * bottomLaneSpacing;
    p.currentX += (p.targetX - p.currentX) * 0.25 * dt;

    // Handle jump mechanics & Nitro flying
    const gravity = 0.52 * dt;
    if (nitroActive) {
      // Sheep hovers above street in Nitro state
      p.y += (55 - p.y) * 0.15 * dt;
      p.vy = 0;
      p.isJumping = true;
    } else if (p.isJumping) {
      p.y += p.vy * dt;
      p.vy -= gravity;
      if (p.y <= 0) {
        p.y = 0;
        p.vy = 0;
        p.isJumping = false;
        p.canDoubleJump = false;
        // Spawn little impact dust
        createDustParticles(p.currentX, 6);
      }
    } else {
      p.y = 0;
    }

    // Handle slide mechanics
    if (p.isDucking) {
      p.duckProgress -= dt;
      if (p.duckProgress <= 0) {
        p.isDucking = false;
        p.duckProgress = 0;
      }
    }

    // 5. Update and Move Coin Collectibles (z changes from 1200 down to -50)
    for (let i = s.coins.length - 1; i >= 0; i--) {
      const coin = s.coins[i];
      const prevCoinZ = coin.z;
      // Coins speed up according to gameSpeed
      coin.z -= s.gameSpeed * 1.5 * dt;

      // Nitro vacuum logic: attracts all clovers & collectibles in all lanes automatically!
      if (nitroActive && coin.z < 750 && coin.z > 0) {
        coin.lane += (p.lane - coin.lane) * 0.35 * dt;
        coin.z -= 15 * dt;
        coin.y += (p.y - coin.y) * 0.3 * dt;
      }

      // Magnet power-up logic: Attracts both CLOVER and CORN items towards the sheep
      const magnetActive = s.powerups.MAGNET.durationLeft > 0;
      const magnetRange = p.activeOutfit === 'tarbush' ? 550 : 450; // +20% magnet range for ElMallem!
      if (!nitroActive && magnetActive && coin.z < magnetRange && coin.z > 0) {
        const { screenY: coinYAtZ, laneSpacing: coinLaneSpacing } = getPerspective(coin.z, w, h, horizonY, hTargetLine);
        const coinXAtZ = w / 2 + (coin.lane - 1) * coinLaneSpacing;
        
        // Magnet attraction vector
        coin.z -= 9 * dt; // speed up depth attraction
        const targetLaneIndex = p.lane;
        coin.lane += (targetLaneIndex - coin.lane) * 0.22 * dt;

        // Spawn a magnetic trace tail
        createMagnetTrailParticle(coinXAtZ, coinYAtZ - coin.y);
      }

      // Check collision with player using anti-tunneling swept detection
      const inCoinHitbox = (coin.z <= 48 && coin.z >= -20) || (prevCoinZ >= 0 && coin.z <= 25);
      if (inCoinHitbox) {
        // Must be in the same lane
        const laneDist = Math.abs(coin.lane - p.lane);
        // And height matches
        const sheepHeight = p.y;
        const coinHeight = coin.y;
        const heightMatch = Math.abs(sheepHeight - coinHeight) < 48;

        if (laneDist < 0.45 && heightMatch) {
          const sheepScreenX = w / 2 + p.currentX;
          const sheepScreenY = hTargetLine - p.y - 20;

          // Increment combo counter & reset decay timer
          s.comboCount++;
          s.comboTimer = 160; // ~2.6s at 60fps
          const currMultiplier = Math.min(5, 1 + Math.floor(s.comboCount / 8));

          // Trigger special effect on multiplier upgrade milestones
          if (s.comboCount % 8 === 0) {
            addFloatingText(`المضاعف x${currMultiplier}! 🔥🚀`, sheepScreenX, sheepScreenY - 35, '#22c55e');
            // Synthesized little retro melody chirp
            try {
              const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
              const osc = audioCtx.createOscillator();
              const gain = audioCtx.createGain();
              osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
              osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.08); // A5
              gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
              gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
              osc.connect(gain);
              gain.connect(audioCtx.destination);
              osc.start();
              osc.stop(audioCtx.currentTime + 0.25);
            } catch (e) {}
          }

          // ALL COLLECTIBLE TYPES: NITRO, FATTA_SHIELD, GOLDEN_CLOVER, CORN, MAGNET, CLOVER
          if (coin.type === 'NITRO') {
            // شطة الجزار النارية: طيران فائق وسرعة خارقة وجذب كل البرسيم وتحطيم العقبات
            s.powerups.NITRO.durationLeft = 360;
            s.powerups.NITRO.maxDuration = 360;
            const pointsGained = 400 * currMultiplier;
            p.score += pointsGained;
            gameSounds.playNitro();
            createHurtSpark(sheepScreenX, sheepScreenY);
            addFloatingText("شطة الجزار النارية! طيران وسرعة خارقة! 🌶️🔥", sheepScreenX, sheepScreenY - 30, '#ef4444');
          } else if (coin.type === 'FATTA_SHIELD') {
            // درع صينية الفتة بالثوم: هالة حماية مؤقتة ضد أول اصطدام
            s.powerups.SHIELD.durationLeft = 400 + (fattaLevel || 1) * 80;
            const pointsGained = 250 * currMultiplier;
            p.score += pointsGained;
            gameSounds.playPowerUp();
            createFattaRainbowSpark(sheepScreenX, sheepScreenY);
            addFloatingText("درع صينية الفتة بالثوم! حماية ضد الصدمات! 🍲🧄", sheepScreenX, sheepScreenY - 30, '#10b981');
          } else if (coin.type === 'GOLDEN_CLOVER') {
            // البرسيم الذهبي المشع: 5 زهور دفعة واحدة مع تأثيرات بصرية ضخمة
            const cloversGain = 5;
            p.cloversCollected += cloversGain;
            setCloversCollected((prev) => prev + cloversGain);
            s.roundCloverCount += cloversGain;
            const pointsGained = 350 * (cornActive ? 2 : 1) * currMultiplier;
            p.score += pointsGained;
            gameSounds.playGoldenClover();
            createGoldenCloverParticles(sheepScreenX, sheepScreenY);
            addFloatingText(`🌟 برسيم ذهبي مشع! +5 🍀 (+${pointsGained}) 🌟`, sheepScreenX, sheepScreenY - 30, '#facc15');

            const cloverCh = challenges.find(c => c.id === 'collect_clovers_50');
            if (cloverCh && !cloverCh.completed) {
              const nextProg = cloverCh.progress + cloversGain;
              if (nextProg >= cloverCh.target) {
                onChallengeCompleted('collect_clovers_50', cloverCh.rewardClovers, cloverCh.title);
              } else {
                onChallengeProgress('collect_clovers_50', nextProg);
              }
            }
          } else if (coin.type === 'CORN') {
            // 2. الذرة: (تعطي سرعة مؤقتة و نقاط مضاعفة)
            s.powerups.BOOST.durationLeft = 360 + cornLevel * 60;
            s.roundCornCount++;
            const pointsGained = 200 * currMultiplier;
            p.score += pointsGained;

            const cornCh = challenges.find(c => c.id === 'collect_corn_10');
            if (cornCh && !cornCh.completed) {
              const nextProg = cornCh.progress + 1;
              if (nextProg >= cornCh.target) {
                onChallengeCompleted('collect_corn_10', cornCh.rewardClovers, cornCh.title);
              } else {
                onChallengeProgress('collect_corn_10', nextProg);
              }
            }

            addFloatingText(`ذرة سحرية! سرعة ونقاط مضاعفة x2! 🌽⚡`, sheepScreenX, sheepScreenY - 20, '#f59e0b');
            gameSounds.playClover();
            createFattaRainbowSpark(sheepScreenX, sheepScreenY);
          } else if (coin.type === 'MAGNET') {
            // 3. المغناطيس: (يقوم بجذب البرسيم والذرة والكنوز تلقائياً)
            s.powerups.MAGNET.durationLeft = 360 + magnetLevel * 60;
            const pointsGained = 150 * (cornActive ? 2 : 1) * currMultiplier;
            p.score += pointsGained;

            addFloatingText(`مغناطيس البرسيم والذرة! 🧲✨`, sheepScreenX, sheepScreenY - 20, '#38bdf8');
            gameSounds.playSlide();
            createMagnetTrailParticle(sheepScreenX, sheepScreenY);
          } else {
            // 1. البرسيم: (يعطي نقاطاً متزايدة)
            s.cloverStreak++;
            s.cloverStreakTimer = 180; // ~3 seconds window to keep streak going
            s.roundCloverCount++;

            let cloversGain = 1;
            if (cornActive && p.activeOutfit === 'cool') {
              cloversGain = 2;
            }
            p.cloversCollected += cloversGain;
            setCloversCollected((prev) => prev + cloversGain);

            // Increasing points calculation: +25 base, plus +15 per streak level!
            const streakBonus = Math.min(300, (s.cloverStreak - 1) * 15);
            const baseScore = 25 + streakBonus;
            const pointsGained = baseScore * (cornActive ? 2 : 1) * currMultiplier;
            p.score += pointsGained;

            const streakText = s.cloverStreak > 1 ? `+${pointsGained} 🍀 متزايد x${s.cloverStreak}` : `+${pointsGained} 🍀`;
            addFloatingText(`${streakText}${cornActive ? ' (x2 ذرة!)' : ''}`, sheepScreenX, sheepScreenY - 10, '#22c55e');
            gameSounds.playClover();
            createCloverSpark(sheepScreenX, sheepScreenY, s.cloverStreak);

            const cloverCh = challenges.find(c => c.id === 'collect_clovers_50');
            if (cloverCh && !cloverCh.completed) {
              const nextProg = cloverCh.progress + 1;
              if (nextProg >= cloverCh.target) {
                onChallengeCompleted('collect_clovers_50', cloverCh.rewardClovers, cloverCh.title);
              } else {
                onChallengeProgress('collect_clovers_50', nextProg);
              }
            }
          }

          // Remove coin
          s.coins.splice(i, 1);
          continue;
        }
      }

      // Out of bounds cleanup
      if (coin.z <= -20) {
        s.coins.splice(i, 1);
      }
    }

    // 6. Update and Move Obstacles
    for (let i = s.obstacles.length - 1; i >= 0; i--) {
      const ob = s.obstacles[i];
      const prevZ = ob.z;
      ob.z -= s.gameSpeed * 1.5 * dt;

      // Swept Collision trigger with player (Anti-tunneling Hitbox Check):
      // Player is at z = 0 with a hitbox depth from -15 to 45.
      // Even with high speed or frame deltas, any obstacle crossing this depth window is captured.
      const inObstacleHitbox = (ob.z <= 45 && ob.z >= -20) || (prevZ >= 0 && ob.z <= 25);
      if (inObstacleHitbox) {
        if (ob.lane === p.lane && !ob.scraped) {
          
          let collided = false;
          // Check heights based on obstacle type
          if (ob.type === 'CLOTHESLINE') {
            // Must duck slide under, cannot jump
            if (!p.isDucking) collided = true;
          } else if (ob.type === 'VEG_CART') {
            // Can slide under if it's tall canopy, or jump over. Let's make it demanding slide
            if (!p.isDucking && p.y < 22) collided = true;
          } else {
            // Standard wall or cart, jump over is possible if y is high
            const requiresJumpHeight = ob.type === 'TUKTUK' ? 32 : 18;
            if (p.y < requiresJumpHeight && !p.isDucking) {
              collided = true;
            }
          }

          if (collided) {
            ob.scraped = true; // prevent multi collisions
            
            // Trigger arcade shake/rumble effect
            onObstacleCollision?.();
            
            // Reset consecutive avoiding streak and combo multipliers
            s.avoidedStreak = 0;
            s.comboCount = 0;
            s.comboTimer = 0;
            const avoidCh = challenges.find(c => c.id === 'avoid_5');
            if (avoidCh && !avoidCh.completed) {
              onChallengeProgress('avoid_5', 0);
            }
            
            // If Nitro Boost is active, we smash through obstacles with fiery explosion!
            const nitroBoostActive = (s.powerups.NITRO?.durationLeft || 0) > 0;
            if (nitroBoostActive) {
              gameSounds.playCrash();
              const { screenY: obScreenY, laneSpacing: obLaneSpacing } = getPerspective(ob.z, w, h, horizonY, hTargetLine);
              const obScreenX = w / 2 + (ob.lane - 1) * obLaneSpacing;
              createHurtSpark(obScreenX, obScreenY);
              s.obstacles.splice(i, 1);
              p.score += 100;
              addFloatingText("تحطيم ناري خارق! +100 🌶️🔥", obScreenX, obScreenY - 20, '#ef4444');
              continue;
            }

            // If Corn Boost is active, we smash through obstacles cleanly!
            const cornBoostActive = s.powerups.BOOST.durationLeft > 0;
            if (cornBoostActive) {
              gameSounds.playCrash();
              const { screenY: obScreenY, laneSpacing: obLaneSpacing } = getPerspective(ob.z, w, h, horizonY, hTargetLine);
              const obScreenX = w / 2 + (ob.lane - 1) * obLaneSpacing;
              createHurtSpark(obScreenX, obScreenY);
              s.obstacles.splice(i, 1);
              p.score += 50; // extra reward for smashing obstacles during Corn boost
              continue;
            }

            // Check if shield was active
            const shieldActive = (s.powerups.SHIELD?.durationLeft || 0) > 0;
            if (shieldActive) {
              // Destroy shield
              if (s.powerups.SHIELD) s.powerups.SHIELD.durationLeft = 0;
              gameSounds.playShieldBreak();
              // Spawn defensive spark particles
              createHurtSpark(w / 2 + p.currentX, hTargetLine - p.y);
              s.obstacles.splice(i, 1);
              continue;
            }

            // Check Boxer Tyson perk: One-time Crash Shield per round
            if (p.activeOutfit === 'boxer_tyson' && !p.boxerShieldUsed) {
              p.boxerShieldUsed = true;
              gameSounds.playPunchKO();
              const sheepScreenX = w / 2 + p.currentX;
              const sheepScreenY = hTargetLine - p.y;
              createHurtSpark(sheepScreenX, sheepScreenY);
              s.obstacles.splice(i, 1);
              s.isHurtCooldown = 90; // invulnerability
              addFloatingText("لكمة تايسون القاضية! تحطيم العقبة 🥊💥", sheepScreenX, sheepScreenY - 35, '#ef4444');
              continue;
            }

            // Real impact!
            gameSounds.playCrash();
            createHurtSpark(w / 2 + p.currentX, hTargetLine - p.y);
            s.isHurtCooldown = 90; // invulnerability frames

            // If butcher is already close, Game Over or Revival Modal!
            // Major obstacle like TukTuk or extremely decaying distance triggers immediate catch
            if (p.butcherDistance < 45 || ob.type === 'TUKTUK') {
              if (p.activeOutfit === 'pharaoh' && !p.extraLifeUsed) {
                p.extraLifeUsed = true;
                p.butcherDistance = 85; // reset butcher to safe distance!
                if (s.powerups.SHIELD) s.powerups.SHIELD.durationLeft = 180; // ~3 seconds of safety
                s.isHurtCooldown = 180; // invulnerable

                const sheepScreenX = w / 2 + p.currentX;
                const sheepScreenY = hTargetLine - p.y - 25;
                addFloatingText("بركة الفراعنة! بعث جديد 👑🌟🇪🇬", sheepScreenX, sheepScreenY - 30, '#facc15');

                try {
                  const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
                  const notes = [440, 554.37, 659.25, 880, 1108.73, 1318.51];
                  notes.forEach((freq, idx) => {
                    const osc = audioCtx.createOscillator();
                    const gain = audioCtx.createGain();
                    osc.frequency.setValueAtTime(freq, audioCtx.currentTime + idx * 0.08);
                    gain.gain.setValueAtTime(0.04, audioCtx.currentTime + idx * 0.08);
                    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + idx * 0.08 + 0.3);
                    osc.connect(gain);
                    gain.connect(audioCtx.destination);
                    osc.start(audioCtx.currentTime + idx * 0.08);
                    osc.stop(audioCtx.currentTime + idx * 0.08 + 0.35);
                  });
                } catch (e) {}

                s.runningSpeechBubble.text = "فالكون الفراعنة لا يفنى! هربت من الساطور! 𓁹🇪🇬";
                s.runningSpeechBubble.timer = 140;

                s.obstacles.splice(i, 1);
                continue;
              }

              // Check if player can be revived with Eid Balloons!
              if (!p.extraLifeUsed && ((eidBalloons || 0) > 0 || (cloversTotal || 0) >= 60)) {
                p.extraLifeUsed = true;
                setIsReviveActive(true);
                return;
              }

              p.butcherDistance = 0;
              // End game!
              onGameOver(p.score, p.cloversCollected);
              setGameState(GameState.GAME_OVER);
              return;
            } else {
              // Minor scrape, butcher catches up closer
              p.butcherDistance -= 25;
              if (p.butcherDistance < 15) p.butcherDistance = 15;
              gameSounds.playButcherShout();
              triggerButcherSpeechBubble();
            }
          }
        }
      }

      if (ob.z <= -20) {
        if (!ob.scraped) {
          s.avoidedStreak++;
          
          // Check for challenge progress
          const avoidCh = challenges.find(c => c.id === 'avoid_5');
          if (avoidCh && !avoidCh.completed) {
            if (s.avoidedStreak >= avoidCh.target) {
              onChallengeCompleted('avoid_5', avoidCh.rewardClovers, avoidCh.title);
            } else if (s.avoidedStreak > avoidCh.progress) {
              onChallengeProgress('avoid_5', s.avoidedStreak);
            }
          }

          // Visual floating text indicator on 5 avoided obstacles!
          if (s.avoidedStreak % 5 === 0) {
            const sheepScreenX = w / 2 + p.currentX;
            const sheepScreenY = hTargetLine - p.y - 20;
            addFloatingText(`هروب متتالي x${s.avoidedStreak}! 🔥`, sheepScreenX, sheepScreenY - 20, '#e67e22');
          }
        }
        s.obstacles.splice(i, 1);
      }
    }

    // 7. Update particles with physics (velocity, drag, gravity, rotation)
    for (let i = s.particles.length - 1; i >= 0; i--) {
      const part = s.particles[i];
      if (part.drag) {
        part.vx *= Math.pow(part.drag, dt);
        part.vy *= Math.pow(part.drag, dt);
      }
      if (part.gravity) {
        part.vy += part.gravity * dt;
      }
      part.x += part.vx * dt;
      part.y += part.vy * dt;
      if (part.vRot !== undefined) {
        part.rotation = (part.rotation || 0) + part.vRot * dt;
      }
      part.life += dt;
      if (part.life >= part.maxLife) {
        s.particles.splice(i, 1);
      }
    }

    // 8. Update Decorations (scrolling on sides of streets)
    for (let i = s.decorations.length - 1; i >= 0; i--) {
      const dec = s.decorations[i];
      dec.z -= s.gameSpeed * 1.5 * dt;
      if (dec.z <= -50) {
        s.decorations.splice(i, 1);
      }
    }

    // 9. Dynamic Spawning logic: Synchronized with current speed and road travel distance
    const stepZ = s.gameSpeed * 1.5 * dt;
    s.obstacleSpawnDistAccumulator += stepZ;
    s.coinSpawnDistAccumulator += stepZ;
    s.decSpawnDistAccumulator += stepZ;

    // Obstacle spacing calibrated by difficulty:
    // Easy: ~490 units spacing (very relaxed, spacious corridor)
    // Normal: ~380 units spacing (balanced rhythm, ample time to react)
    // Hard: ~300 units spacing (intense challenge, but strictly fair and separated)
    const obstacleThreshold = difficulty === 'easy' ? 490 : difficulty === 'hard' ? 300 : 380;

    if (s.obstacleSpawnDistAccumulator >= obstacleThreshold) {
      s.obstacleSpawnDistAccumulator = 0;
      spawnObstacle();
    }

    // Coin clusters spaced by distance (~560 units, previously 390) - 40% reduction in clover density on road
    if (s.coinSpawnDistAccumulator >= 560) {
      s.coinSpawnDistAccumulator = 0;
      // 55% chance to spawn a coin cluster (previously 72%)
      if (Math.random() < 0.55) {
        spawnCoins();
      }
    }

    // Side decorations spaced by distance (~140 units)
    if (s.decSpawnDistAccumulator >= 140) {
      s.decSpawnDistAccumulator = 0;
      spawnDecorations();
    }

    // 10. Update Road Scrolling track texture offset
    s.roadOffset = (s.roadOffset + s.gameSpeed) % 80;

    // Synchronize UI State to avoid high-freq rendering stuttering in React overlay
    if (s.elapsedFrames % 3 === 0) {
      setHudStats({
        score: p.score,
        distance: Math.floor(p.distance),
        clovers: p.cloversCollected,
        butcherDist: Math.floor(p.butcherDistance),
        activeMagnet: Math.ceil(s.powerups.MAGNET.durationLeft / 60),
        activeBoost: Math.ceil(s.powerups.BOOST.durationLeft / 60),
        activeNitro: Math.ceil((s.powerups.NITRO?.durationLeft || 0) / 60),
        activeNitroFrames: Math.max(0, Math.floor(s.powerups.NITRO?.durationLeft || 0)),
        activeNitroMax: s.powerups.NITRO?.maxDuration || 360,
        activeShield: Math.ceil((s.powerups.SHIELD?.durationLeft || 0) / 60),
        speechBubbleText: s.runningSpeechBubble.timer > 0 ? s.runningSpeechBubble.text : '',
        comboCount: s.comboCount,
        comboTimer: s.comboTimer,
        cloverStreak: s.cloverStreak,
        currentWeather: s.weather,
      });
      // push current scores to master overlay periodically
      updateScoreAndDistance(p.score, Math.floor(p.distance));

      // Check distance and score challenges dynamically
      const distCh = challenges.find(c => c.id === 'dist_1000');
      if (distCh && !distCh.completed) {
        const curDist = Math.floor(p.distance);
        if (curDist >= distCh.target) {
          onChallengeCompleted('dist_1000', distCh.rewardClovers, distCh.title);
        } else if (curDist > distCh.progress) {
          onChallengeProgress('dist_1000', curDist);
        }
      }

      const scoreCh = challenges.find(c => c.id === 'score_5000');
      if (scoreCh && !scoreCh.completed) {
        if (p.score >= scoreCh.target) {
          onChallengeCompleted('score_5000', scoreCh.rewardClovers, scoreCh.title);
        } else if (p.score > scoreCh.progress) {
          onChallengeProgress('score_5000', p.score);
        }
      }
    }

    // 11. Update Floating Texts decays and movement
    for (let i = s.floatingTexts.length - 1; i >= 0; i--) {
      const ft = s.floatingTexts[i];
      ft.y += ft.vy * dt;
      ft.life -= 0.02 * dt;
      if (ft.life <= 0) {
        s.floatingTexts.splice(i, 1);
      }
    }
  };

  // Generators for road collectibles: CLOVER, GOLDEN_CLOVER, NITRO, FATTA_SHIELD, CORN, MAGNET
  const spawnCoins = () => {
    const s = stateRef.current;
    const lane = Math.floor(Math.random() * 3) as LaneType;
    // 1 clover (or rarely 2) - reduced count by 40% to keep road clean & clear
    const count = Math.random() < 0.7 ? 1 : 2;
    
    // Check if lane is free of immediate obstacles in depth
    const laneObstructed = s.obstacles.some(ob => ob.lane === lane && ob.z > 1050);
    if (laneObstructed) return;

    const cornActive = s.powerups.BOOST.durationLeft > 0;
    
    if (cornActive) {
      // During Corn Boost, spawn 1 clover per lane (reduced by 40% from 2)
      for (let l = 0; l <= 2; l++) {
        s.coinIdCounter++;
        s.coins.push({
          id: s.coinIdCounter,
          lane: l as LaneType,
          z: 1200,
          y: 35,
          type: 'CLOVER',
        });
      }
    } else {
      const randType = Math.random();

      // Chance for Radiant Golden Clover based on upgrade level (10% base + 6% per level)
      const goldenChance = (goldenCloverLevel && goldenCloverLevel >= 1) 
        ? Math.min(0.40, 0.10 + goldenCloverLevel * 0.06) 
        : 0;

      // Normal wave of Clovers or Golden Clovers
      for (let i = 0; i < count; i++) {
        s.coinIdCounter++;
        
        let coinY = 0;
        if (randType > 0.6) {
          coinY = Math.sin((i / Math.max(1, count - 1)) * Math.PI) * 35;
        }

        const isGolden = Math.random() < goldenChance;

        s.coins.push({
          id: s.coinIdCounter,
          lane,
          z: 1200 + i * 65,
          y: coinY,
          type: isGolden ? 'GOLDEN_CLOVER' : 'CLOVER'
        });
      }

      // Special magical items appearance:
      // ~7% Nitro (شطة الجزار), ~8% Fatta Garlic Shield (درع الفتة بالثوم), ~10% Corn (الذرة), ~10% Magnet (المغناطيس)
      const specialRand = Math.random();
      if (specialRand < 0.35) {
        let specialType: 'CORN' | 'MAGNET' | 'NITRO' | 'FATTA_SHIELD';
        if (specialRand < 0.07) {
          specialType = 'NITRO'; // شطة الجزار النارية
        } else if (specialRand < 0.15) {
          specialType = 'FATTA_SHIELD'; // درع صينية الفتة بالثوم
        } else if (specialRand < 0.25) {
          specialType = 'CORN';
        } else {
          specialType = 'MAGNET';
        }

        const specialLane = Math.floor(Math.random() * 3) as LaneType;
        s.coinIdCounter++;
        s.coins.push({
          id: s.coinIdCounter,
          lane: specialLane,
          z: 1200 + count * 65 + 45,
          y: 30,
          type: specialType
        });
      }
    }
  };

  const spawnObstacle = () => {
    const s = stateRef.current;
    
    // Check lanes currently occupied near the horizon (z > 1060)
    const horizonObs = s.obstacles.filter(ob => ob.z > 1060);
    const blockedLanes = horizonObs.map(ob => ob.lane);

    // Filter available free lanes to guarantee a safe corridor
    const freeLanes = ([0, 1, 2] as LaneType[]).filter(l => !blockedLanes.includes(l));
    
    // If all 3 lanes are somehow blocked or 2 are occupied with zero remaining, skip this spawn
    if (freeLanes.length === 0) {
      return;
    }

    const lane = freeLanes[Math.floor(Math.random() * freeLanes.length)];
    
    // Choose randomized ancient Egyptian street obstacles (Removed WATERMELON and any green obstacles to prevent interference with clovers!)
    const types: ObstacleType[] = ['TUKTUK', 'VEG_CART', 'BARRIER', 'FOUL_POT', 'CLOTHESLINE'];
    const type = types[Math.floor(Math.random() * types.length)];

    s.obstacleIdCounter++;
    s.obstacles.push({
      id: s.obstacleIdCounter,
      type,
      lane,
      z: 1200, // Starts directly at the far horizon line!
      xOffset: (Math.random() * 10 - 5), // slight drift for realism
      scraped: false
    });
  };

  const spawnDecorations = () => {
    const s = stateRef.current;
    const sides: ('left' | 'right')[] = ['left', 'right'];
    
    // Choose decoration elements (ancient Islamic Cairo balconies, mosques dome, street poles, trees)
    const types: ('FANOOS' | 'BALCONY' | 'DOME' | 'TREE' | 'STREET_LIGHT' | 'BANNER')[] = 
      ['BALCONY', 'FANOOS', 'STREET_LIGHT', 'TREE', 'BANNER'];
    
    sides.forEach(side => {
      if (Math.random() < 0.55) {
        s.decIdCounter++;
        s.decorations.push({
          id: s.decIdCounter,
          type: types[Math.floor(Math.random() * types.length)],
          side,
          z: 1200,
          scale: 0.6 + Math.random() * 0.5,
          variety: Math.floor(Math.random() * 4)
        });
      }
    });

    // Enforce decoration separation
    const horizonDecs = s.decorations.filter(d => d.z > 1150);
    if (horizonDecs.length > 4) {
      s.decorations.pop();
    }
  };

  // Capture custom item pickup trigger
  const handlePowerupAcquired = (type: 'MAGNET' | 'SHIELD' | 'BOOST') => {
    const s = stateRef.current;
    gameSounds.playPowerUp();
    
    // Boost starts complete invincibility
    if (type === 'BOOST') {
      s.player.y = 120; // launch in air
      s.player.isJumping = true;
    }

    // Activate state duration timer
    let duration = s.powerups[type].maxDuration;
    if (type === 'SHIELD' && s.player.activeOutfit === 'saidi') {
      duration = Math.round(duration * 1.25);
    }
    s.powerups[type].durationLeft = duration;

    // Trigger funny sheep saying
    s.runningSpeechBubble.text = type === 'BOOST' 
      ? 'بساط الفتة السحري طيرني فوق السطوح! 🎈🍲' 
      : type === 'MAGNET' 
        ? 'جاذب البرسيم القوي.. هات الفلوس اللي عليك! 🧲💰'
        : 'الخوذة الحديدية! مفيش جزار يقدر عليا! 🪖🛡️';
    s.runningSpeechBubble.timer = 110;

    if (type === 'BOOST') {
      triggerButcherSpeechBubble("يا بن اللعيبة ركب بساط الريح وطار! 🛸🍲");
    }
  };

  // Intercept coin loop check to see if we clicked / grabbed custom payload
  // We'll run a custom listener on the array:
  const checkCustomPayloadCol = () => {
    const s = stateRef.current;
    const p = s.player;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const hTargetLine = (canvas.height / window.devicePixelRatio) - 110;

    for (let i = s.coins.length - 1; i >= 0; i--) {
      const coin = s.coins[i] as any;
      if (coin.powerUpPayload && coin.z < 35 && coin.z > -10) {
        const laneDist = Math.abs(coin.lane - p.lane);
        const heightMatch = Math.abs(p.y - coin.y) < 55;
        if (laneDist < 0.4 && heightMatch) {
          handlePowerupAcquired(coin.powerUpPayload);
          s.coins.splice(i, 1);
        }
      }
    }
  };
  
  // Connect frame ticker tick check:
  const oldUpdate = updateGame;
  const newUpdate = (dt: number) => {
    oldUpdate(dt);
    checkCustomPayloadCol();
  };
  stateRef.current.elapsedFrames; // trace to avoid unused, let React load smoothly.

  // --------------------------------------------------------------------
  // DRAWING SYSTEM ON CANVAS
  // --------------------------------------------------------------------
  const drawGame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width / window.devicePixelRatio;
    const h = canvas.height / window.devicePixelRatio;

    ctx.clearRect(0, 0, w, h);

    const s = stateRef.current;
    const p = s.player;
    const horizonY = h * 0.20;
    const hTargetLine = h - 90;
    const roadBottomHalfWidth = Math.min(w * 0.44, Math.max(w * 0.40, 280));
    const roadTopHalfWidth = Math.max(14, roadBottomHalfWidth * 0.08);

    // 1. Draw Sky Backdrop (Dynamic Egyptian Weather Skies: Sunny Blazing, Khamaseen Dust, Golden Asr, Night Breeze)
    const boostActive = s.powerups.BOOST.durationLeft > 0;
    let silhouetteColor = 'rgba(234, 88, 12, 0.25)';

    if (boostActive) {
      // Cosmic magical starlight sky!
      const skyGrad = ctx.createLinearGradient(0, 0, 0, horizonY);
      skyGrad.addColorStop(0, '#1e1b4b'); // deep twilight purple indigo
      skyGrad.addColorStop(0.6, '#311042');
      skyGrad.addColorStop(1, '#581c87');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, w, horizonY);
      silhouetteColor = 'rgba(49, 46, 129, 0.45)';
    } else {
      silhouetteColor = drawWeatherSky(ctx, s.weather, w, horizonY);
    }

    // Draw Cairo Minarets & Domes in the far horizon background (silhouettes)
    ctx.fillStyle = silhouetteColor;
    drawCairoFarHorizon(ctx, w, horizonY);

    // Draw Sun, Crepuscular God Rays, Pigeons, Moon and Clouds
    if (boostActive) {
      // Draw flying stars / cosmic crescents
      ctx.fillStyle = 'rgba(255, 255, 255, 0.82)';
      for (let i = 0; i < 15; i++) {
        const starX = (Math.sin(i + s.elapsedFrames * 0.02) * 0.5 + 0.5) * w;
        const starY = (Math.cos(i * 3) * 0.5 + 0.5) * (horizonY - 10);
        ctx.beginPath();
        ctx.arc(starX, starY, Math.random() * 2 + 1, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      drawSunAndRays(ctx, s.weather, w, h, horizonY, s.elapsedFrames);
      drawEgyptianPigeons(ctx, s.weather, w, horizonY, s.elapsedFrames);
    }

    // 2. Draw ancient Egyptian Popular Alley Walls & Ground floor
    // Bottom cobblestone road
    const groundGrad = ctx.createLinearGradient(0, horizonY, 0, h);
    groundGrad.addColorStop(0, '#eab308'); // yellow sand
    groundGrad.addColorStop(1, '#ca8a04'); // deep mustard gold sand
    ctx.fillStyle = groundGrad;
    ctx.fillRect(0, horizonY, w, h - horizonY);

    // Draw cobblestone perspective tile dividers
    ctx.strokeStyle = 'rgba(113, 63, 18, 0.15)';
    ctx.lineWidth = 2;
    // Draw 3 primary lanes lines extending from vanishing center (w/2, horizonY) to bottom
    const laneDivs = [-150, -50, 50, 150]; // relative edge limits
    
    // Draw continuous wide road
    ctx.fillStyle = '#ca8a04';
    ctx.beginPath();
    ctx.moveTo(w / 2 - roadTopHalfWidth, horizonY);
    ctx.lineTo(w / 2 + roadTopHalfWidth, horizonY);
    ctx.lineTo(w / 2 + roadBottomHalfWidth, h);
    ctx.lineTo(w / 2 - roadBottomHalfWidth, h);
    ctx.closePath();
    ctx.fill();

    // Cobblestone outer lane boundaries
    ctx.lineWidth = 6;
    ctx.strokeStyle = '#854d0e'; // brown clay mortar
    ctx.beginPath();
    ctx.moveTo(w / 2 - roadTopHalfWidth, horizonY);
    ctx.lineTo(w / 2 - roadBottomHalfWidth, h);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(w / 2 + roadTopHalfWidth, horizonY);
    ctx.lineTo(w / 2 + roadBottomHalfWidth, h);
    ctx.stroke();

    // Lane tracks dividing lines (ancient dashed mortar in 3D perspective)
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.45)';
    ctx.lineWidth = 3.5;
    ctx.setLineDash([20, 25]);
    ctx.lineDashOffset = -s.roadOffset;
    // Divider 1 (between lane 0 and 1)
    ctx.beginPath();
    ctx.moveTo(w / 2 - roadTopHalfWidth * 0.32, horizonY);
    ctx.lineTo(w / 2 - roadBottomHalfWidth * 0.32, h);
    ctx.stroke();
    // Divider 2 (between lane 1 and 2)
    ctx.beginPath();
    ctx.moveTo(w / 2 + roadTopHalfWidth * 0.32, horizonY);
    ctx.lineTo(w / 2 + roadBottomHalfWidth * 0.32, h);
    ctx.stroke();
    ctx.setLineDash([]); // clear dash

    // 3. Draw Side Buildings (Popular Alleys / Old Cairo style)
    drawStreetWallsAndBuildings(ctx, w, h, horizonY, roadBottomHalfWidth, roadTopHalfWidth);

    // 3.5. Dynamic Weather Road Effects: Heat Shimmer & Khamaseen Sand Wisps
    drawHeatShimmer(ctx, s.weather, w, horizonY, s.elapsedFrames);
    drawKhamaseenSandWisps(ctx, s.weather, w, h, horizonY, s.elapsedFrames);

    // 4. Draw Decorations (Fanoos, Balcony windows) sorted by depth z
    // Make a copy of state arrays so we don't mutate during rendering
    const sortedDecorations = [...s.decorations].sort((a, b) => b.z - a.z);
    sortedDecorations.forEach(dec => {
      drawDecoration(ctx, dec, w, h, horizonY, hTargetLine);
    });

    // 5. Draw Coins/Clovers & Power-up objects sorted by depth z (Draw furthest first)
    const sortedCoins = [...s.coins].sort((a, b) => b.z - a.z);
    sortedCoins.forEach(coin => {
      drawCoin(ctx, coin, w, h, horizonY, hTargetLine);
    });

    // 6. Draw Obstacles sorted by depth z
    const sortedObstacles = [...s.obstacles].sort((a, b) => b.z - a.z);
    sortedObstacles.forEach(ob => {
      drawObstacle(ctx, ob, w, h, horizonY, hTargetLine);
    });

    // 7. Draw all particles (clovers, leaves, stardust stars, shockwave rings, wool & dust)
    s.particles.forEach(part => {
      const progress = Math.max(0, Math.min(1, part.life / part.maxLife));
      const fade = Math.max(0, 1 - progress);

      if (part.shape === 'ring') {
        const radius = part.size * (0.35 + progress * 1.6);
        ctx.save();
        ctx.strokeStyle = part.color;
        ctx.globalAlpha = fade * 0.9;
        ctx.lineWidth = Math.max(1, 3 * fade);
        ctx.beginPath();
        ctx.arc(part.x, part.y, radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      } else if (part.shape === 'star') {
        const sSize = part.size * (0.8 + Math.sin(progress * Math.PI) * 0.3) * fade;
        if (sSize <= 0.1) return;
        ctx.save();
        ctx.translate(part.x, part.y);
        if (part.rotation !== undefined) ctx.rotate(part.rotation);
        ctx.fillStyle = part.color;
        ctx.globalAlpha = fade;
        // 4-point sparkling star
        ctx.beginPath();
        ctx.moveTo(0, -sSize);
        ctx.quadraticCurveTo(0, 0, sSize, 0);
        ctx.quadraticCurveTo(0, 0, 0, sSize);
        ctx.quadraticCurveTo(0, 0, -sSize, 0);
        ctx.quadraticCurveTo(0, 0, 0, -sSize);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      } else if (part.shape === 'leaf') {
        const leafSize = part.size * fade;
        if (leafSize <= 0.1) return;
        ctx.save();
        ctx.translate(part.x, part.y);
        if (part.rotation !== undefined) ctx.rotate(part.rotation);
        ctx.fillStyle = part.color;
        ctx.globalAlpha = fade;
        // Stylized clover leaf petal
        ctx.beginPath();
        ctx.moveTo(0, leafSize * 0.4);
        ctx.bezierCurveTo(-leafSize * 0.9, -leafSize * 0.1, -leafSize * 0.9, -leafSize * 0.9, 0, -leafSize * 0.5);
        ctx.bezierCurveTo(leafSize * 0.9, -leafSize * 0.9, leafSize * 0.9, -leafSize * 0.1, 0, leafSize * 0.4);
        ctx.fill();
        ctx.restore();
      } else {
        // Standard circular particle
        const radius = part.size * fade;
        if (radius <= 0.1) return;
        ctx.save();
        ctx.fillStyle = part.color;
        ctx.globalAlpha = fade;
        ctx.beginPath();
        ctx.arc(part.x, part.y, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    });

    // 8. Player coordinate reference
    const sheepX = w / 2 + p.currentX;

    // If intro cutscene is active, draw the butcher shop door ramming & breakout animation!
    if (s.intro.active) {
      drawIntroCutscene(ctx, w, h, horizonY, hTargetLine, s.intro, p.activeOutfit);
    } else {
      // Draw Player Sheep
      // vertical bounce trotting curve
      const bounceY = p.isJumping ? p.y : Math.abs(Math.sin(s.elapsedFrames * 0.18)) * 8;
      const sheepY = hTargetLine - bounceY;
      
      // Draw Shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.28)';
      ctx.beginPath();
      const shadowWidth = p.isDucking ? 35 : 28 - (p.y * 0.12);
      ctx.ellipse(sheepX, hTargetLine + 2, Math.max(8, shadowWidth), Math.max(2, shadowWidth * 0.25), 0, 0, Math.PI * 2);
      ctx.fill();

      // Draw actual custom sheep with accessories
      drawSheep(ctx, sheepX, sheepY, p, bounceY);

      // 9. Draw Chasing Butcher "بسيوني"
      // He's ALWAYS trailing depending on butcherDistance (0 to 100)
      // If distance = 70, he is partially clipped at bottom boundary or running slightly off screen.
      // If distance is smaller, he is fully visible in foreground.
      if (p.butcherDistance < 72) {
        // Mirror the player's lateral coordinate to make the chase intensely dynamic!
        const butcherX = w / 2 + p.currentX * 0.95; 
        // Scale based on how close he is. Close = very large inside screen. Space = barely entering.
        const closenessFactor = (72 - p.butcherDistance) / 72; // 0 to 1
        const butcherY = h + 150 - (closenessFactor * 185); // glides up the screen
        
        drawButcher(ctx, butcherX, butcherY, closenessFactor);

        // Draw angry speech bubble above the butcher!
        if (s.butcherSpeechBubble && s.butcherSpeechBubble.timer > 0) {
          const scale = 1.1 + closenessFactor * 0.55;
          drawSpeechBubble(ctx, butcherX, butcherY - (scale * 82), s.butcherSpeechBubble.text, true);
        }
      }
    }

    // 9.5. Dynamic Ambient Weather Effects: Sand Particles, Convection Sun Motes, Night Fireflies & Atmospheric Color Fog
    drawWeatherParticles(ctx, s.weatherParticles, s.weather, s.elapsedFrames);
    drawWeatherAtmosphere(ctx, s.weather, w, h, horizonY);

    // 10. Draw floating HUD notifications inside canvas
    // Dynamic Arabic Speech Bubble if Sheep has something comical to say!
    if (hudStats.speechBubbleText) {
      drawSpeechBubble(ctx, sheepX, hTargetLine - p.y - 82, hudStats.speechBubbleText);
    }

    // 11. Draw Floating Arcade Texts
    s.floatingTexts.forEach(ft => {
      ctx.save();
      ctx.globalAlpha = Math.max(0, Math.min(1, ft.life));
      ctx.fillStyle = ft.color;
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      // Outline/Shadow for supreme contrast
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 3.5;
      ctx.strokeText(ft.text, ft.x, ft.y);
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.restore();
    });
  };

  // Silhouette Mosque Minarets in Horizon
  const drawCairoFarHorizon = (ctx: CanvasRenderingContext2D, w: number, horizonY: number) => {
    // Left Mosques
    ctx.beginPath();
    ctx.moveTo(w * 0.1, horizonY);
    ctx.lineTo(w * 0.1, horizonY - 25);
    ctx.lineTo(w * 0.12, horizonY - 35); // dome top
    ctx.quadraticCurveTo(w * 0.15, horizonY - 50, w * 0.18, horizonY - 30); // dome
    ctx.lineTo(w * 0.2, horizonY);

    // Minaret 1
    ctx.moveTo(w * 0.25, horizonY);
    ctx.lineTo(w * 0.25, horizonY - 55);
    ctx.lineTo(w * 0.26, horizonY - 60);
    ctx.lineTo(w * 0.27, horizonY - 55);
    ctx.lineTo(w * 0.27, horizonY);

    // Right Mosques
    ctx.moveTo(w * 0.72, horizonY);
    ctx.lineTo(w * 0.75, horizonY - 45); // minaret
    ctx.lineTo(w * 0.75, horizonY - 75); // needle spire
    ctx.lineTo(w * 0.77, horizonY - 45);
    ctx.lineTo(w * 0.8, horizonY);

    ctx.moveTo(w * 0.82, horizonY);
    ctx.quadraticCurveTo(w * 0.86, horizonY - 40, w * 0.9, horizonY); // dome
    ctx.fill();
  };

  // Procedural ancient street stone wall pillars on sides
  const drawStreetWallsAndBuildings = (
    ctx: CanvasRenderingContext2D, 
    w: number, 
    h: number, 
    horizonY: number,
    roadBottomHalfWidth: number,
    roadTopHalfWidth: number
  ) => {
    ctx.fillStyle = '#b45309'; // brick clay brown
    // Left street wall wedge
    ctx.beginPath();
    ctx.moveTo(0, horizonY);
    ctx.lineTo(w / 2 - roadTopHalfWidth, horizonY);
    ctx.lineTo(w / 2 - roadBottomHalfWidth, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fill();

    // Right street wall wedge
    ctx.beginPath();
    ctx.moveTo(w, horizonY);
    ctx.lineTo(w / 2 + roadTopHalfWidth, horizonY);
    ctx.lineTo(w / 2 + roadBottomHalfWidth, h);
    ctx.lineTo(w, h);
    ctx.closePath();
    ctx.fill();

    // Add brick stripes on left/right walls in perspective
    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 1.5;
    for (let i = 0.1; i <= 1.0; i += 0.15) {
      const edgeY = horizonY + (h - horizonY) * i;
      const leftEdgeX = (w / 2 - roadTopHalfWidth) + ((w / 2 - roadBottomHalfWidth) - (w / 2 - roadTopHalfWidth)) * i;
      const rightEdgeX = (w / 2 + roadTopHalfWidth) + ((w / 2 + roadBottomHalfWidth) - (w / 2 + roadTopHalfWidth)) * i;

      // Draw horizontal mortar lines
      ctx.beginPath();
      ctx.moveTo(0, edgeY);
      ctx.lineTo(leftEdgeX, edgeY);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(w, edgeY);
      ctx.lineTo(rightEdgeX, edgeY);
      ctx.stroke();
    }
  };

  // Draw discrete stylized decoration objects on walls in perspective!
  const drawDecoration = (
    ctx: CanvasRenderingContext2D, 
    dec: DecorativeAsset, 
    w: number, 
    h: number, 
    horizonY: number,
    hTargetLine: number
  ) => {
    const { screenY, scale, currentHalfRoad } = getPerspective(dec.z, w, h, horizonY, hTargetLine);
    const posX = dec.side === 'left' 
      ? w / 2 - currentHalfRoad - 32 * scale 
      : w / 2 + currentHalfRoad + 32 * scale;

    ctx.save();
    ctx.translate(posX, screenY);
    const appliedScale = Math.max(0.08, scale * dec.scale * 0.75);
    ctx.scale(appliedScale, appliedScale);

    if (dec.type === 'BALCONY') {
      // Famous Mashrabiya (wooden lattice window)
      ctx.fillStyle = '#3f1a04'; // dark wood
      ctx.fillRect(-22, -90, 44, 75);
      // roof grid
      ctx.fillStyle = '#450a0a';
      ctx.fillRect(-24, -98, 48, 8);
      // decorative gold trim
      ctx.fillStyle = '#d97706';
      ctx.fillRect(-15, -80, 5, 55);
      ctx.fillRect(10, -80, 5, 55);
      // lattice hatch drawing
      ctx.strokeStyle = '#1e0c02';
      ctx.lineWidth = 2;
      for (let offset = -75; offset < -20; offset += 10) {
        ctx.beginPath();
        ctx.moveTo(-20, offset);
        ctx.lineTo(20, offset + 10);
        ctx.stroke();
      }
    } else if (dec.type === 'FANOOS') {
      // Traditional Egyptian Lantern swinging on a wire
      ctx.strokeStyle = '#78350f';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(dec.side === 'left' ? -35 : 35, -110);
      ctx.lineTo(0, -90); // ceiling hanger
      ctx.stroke();

      // Glowing body
      const gradient = ctx.createRadialGradient(0, -70, 2, 0, -70, 25);
      gradient.addColorStop(0, '#fef08a'); // central yellow lamp
      gradient.addColorStop(0.7, '#f97316'); // amber body
      gradient.addColorStop(1, 'rgba(120, 53, 4, 0)');
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(0, -70, 30, 0, Math.PI * 2);
      ctx.fill();

      // Brass metal frames
      ctx.strokeStyle = '#a16207';
      ctx.fillStyle = '#ca8a04';
      ctx.lineWidth = 3;
      // hexagon lantern body
      ctx.beginPath();
      ctx.moveTo(0, -92); // peak top
      ctx.lineTo(15, -78);
      ctx.lineTo(12, -55);
      ctx.lineTo(0, -42); // peak bottom
      ctx.lineTo(-12, -55);
      ctx.lineTo(-15, -78);
      ctx.closePath();
      ctx.stroke();
      ctx.fill();

      // center core glass light source glow
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, -68, 8, 0, Math.PI * 2);
      ctx.fill();

      // Downward Warm Cozy light Cone in Nighttime/Boost/Night Breeze
      const isNightMode = stateRef.current.weather === 'NIGHT_BREEZE' || (stateRef.current.timeOfDay >= 2000 && stateRef.current.timeOfDay < 3200);
      const boostActive = stateRef.current.powerups.BOOST.durationLeft > 0;
      if (isNightMode || boostActive) {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        const coneGrad = ctx.createLinearGradient(0, -70, 0, 160);
        coneGrad.addColorStop(0, 'rgba(254, 240, 138, 0.42)');
        coneGrad.addColorStop(1, 'rgba(254, 240, 138, 0)');
        ctx.fillStyle = coneGrad;
        ctx.beginPath();
        ctx.moveTo(-5, -70);
        ctx.lineTo(5, -70);
        ctx.lineTo(60, 160);
        ctx.lineTo(-60, 160);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
    } else if (dec.type === 'STREET_LIGHT') {
      // Classic gas light post
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-4, -135, 8, 135); // pole
      // lantern head
      ctx.fillStyle = '#ca8a04';
      ctx.fillRect(-14, -150, 28, 15);
      // glass bulb glow
      const bulbGrad = ctx.createRadialGradient(0, -140, 2, 0, -140, 15);
      bulbGrad.addColorStop(0, '#fff');
      bulbGrad.addColorStop(1, 'rgba(234, 180, 8, 0.4)');
      ctx.fillStyle = bulbGrad;
      ctx.beginPath();
      ctx.arc(0, -140, 15, 0, Math.PI * 2);
      ctx.fill();

      // Downward Warm Cozy Light Cone in Nighttime/Boost/Night Breeze
      const isNightMode = stateRef.current.weather === 'NIGHT_BREEZE' || (stateRef.current.timeOfDay >= 2000 && stateRef.current.timeOfDay < 3200);
      const boostActive = stateRef.current.powerups.BOOST.durationLeft > 0;
      if (isNightMode || boostActive) {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        const coneGrad = ctx.createLinearGradient(0, -140, 0, 160);
        coneGrad.addColorStop(0, 'rgba(254, 240, 138, 0.48)');
        coneGrad.addColorStop(1, 'rgba(254, 240, 138, 0)');
        ctx.fillStyle = coneGrad;
        ctx.beginPath();
        ctx.moveTo(-7, -140);
        ctx.lineTo(7, -140);
        ctx.lineTo(75, 160);
        ctx.lineTo(-75, 160);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
    } else if (dec.type === 'BANNER') {
      // Colorful Egyptian Ramadan & Eid street flags hanging across with wind sway
      const windFlutter = Math.sin(stateRef.current.elapsedFrames * 0.1 + dec.id) * 4;
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(dec.side === 'left' ? -80 : 80, -100);
      ctx.quadraticCurveTo(0, -65 + windFlutter, dec.side === 'left' ? 40 : -40, -90);
      ctx.stroke();

      // Draw little triangles
      ctx.fillStyle = '#f43f5e';
      drawTriangleBanner(ctx, -30, -75 + windFlutter * 0.7, 12, 14);
      ctx.fillStyle = '#eab308';
      drawTriangleBanner(ctx, 0, -72 + windFlutter, 12, 14);
      ctx.fillStyle = '#3b82f6';
      drawTriangleBanner(ctx, 30, -75 + windFlutter * 0.7, 12, 14);
    } else {
      // Pottery planters / trees
      ctx.fillStyle = '#9a3412'; // terracotta vase
      ctx.beginPath();
      ctx.moveTo(-12, 0);
      ctx.lineTo(12, 0);
      ctx.lineTo(18, -25);
      ctx.lineTo(-18, -25);
      ctx.closePath();
      ctx.fill();
      // Green bush
      ctx.fillStyle = '#15803d';
      ctx.beginPath();
      ctx.arc(-8, -42, 16, 0, Math.PI * 2);
      ctx.arc(8, -42, 16, 0, Math.PI * 2);
      ctx.arc(0, -60, 20, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  };

  const drawTriangleBanner = (ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) => {
    ctx.beginPath();
    ctx.moveTo(x - w / 2, y);
    ctx.lineTo(x + w / 2, y);
    ctx.lineTo(x, y + h);
    ctx.closePath();
    ctx.fill();
  };

  // Draw golden clover coin or power-up payload
  const drawCoin = (
    ctx: CanvasRenderingContext2D, 
    coin: GameCoin, 
    w: number, 
    h: number, 
    horizonY: number, 
    hTargetLine: number
  ) => {
    const { screenY, laneSpacing, scale } = getPerspective(coin.z, w, h, horizonY, hTargetLine);
    const screenX = w / 2 + (coin.lane - 1) * laneSpacing;
    const adjustedScreenY = screenY - coin.y * (scale / 1.35);

    ctx.save();
    ctx.translate(screenX, adjustedScreenY);
    ctx.scale(scale, scale);

    if (coin.type === 'NITRO') {
      // 🌶️ 1. Draw Red Hot Chili Pepper (شطة الجزار النارية)
      ctx.save();
      const hoverY = Math.sin((stateRef.current.elapsedFrames * 0.15) + coin.id) * 4;
      ctx.translate(0, hoverY);

      // Fiery Red/Orange Aura glow
      ctx.shadowBlur = 18;
      ctx.shadowColor = '#ef4444';

      // Fiery flame petals behind pepper
      ctx.fillStyle = '#f97316';
      ctx.beginPath();
      ctx.ellipse(-2, 4, 6, 12, -0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.ellipse(-2, 4, 3, 8, -0.3, 0, Math.PI * 2);
      ctx.fill();

      // Curved Red Hot Chili Pepper body
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.moveTo(-4, -14);
      ctx.quadraticCurveTo(8, -2, 4, 14);
      ctx.quadraticCurveTo(-6, 2, -4, -14);
      ctx.fill();

      // Shiny highlight
      ctx.fillStyle = '#f87171';
      ctx.beginPath();
      ctx.ellipse(0, -2, 1.5, 6, 0.2, 0, Math.PI * 2);
      ctx.fill();

      // Green Chili Stem
      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(-4, -14);
      ctx.quadraticCurveTo(-7, -20, -2, -22);
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.restore();
    } else if (coin.type === 'FATTA_SHIELD') {
      // 🍲 2. Draw Egyptian Fatta Platter (درع صينية الفتة بالثوم)
      ctx.save();
      const hoverY = Math.sin((stateRef.current.elapsedFrames * 0.1) + coin.id) * 3;
      ctx.translate(0, hoverY);

      // Garlic Emerald Aura Glow
      ctx.shadowBlur = 16;
      ctx.shadowColor = '#10b981';

      // Egyptian Silver Circular Platter
      ctx.fillStyle = '#cbd5e1';
      ctx.beginPath();
      ctx.ellipse(0, 0, 16, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // White fluffy rice base
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.ellipse(0, -2, 13, 7, 0, 0, Math.PI * 2);
      ctx.fill();

      // Crispy toasted pita squares
      ctx.fillStyle = '#b45309';
      ctx.fillRect(-6, -4, 3, 2.5);
      ctx.fillRect(2, -5, 3, 2.5);
      ctx.fillRect(-2, -1, 3.5, 2.5);

      // Red tomato garlic salsa on top
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.ellipse(0, -3, 6, 3.5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Golden fried garlic flakes
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.arc(-2, -4, 1.2, 0, Math.PI * 2);
      ctx.arc(3, -3, 1.2, 0, Math.PI * 2);
      ctx.arc(0, -1, 1.2, 0, Math.PI * 2);
      ctx.fill();

      ctx.shadowBlur = 0;
      ctx.restore();
    } else if (coin.type === 'GOLDEN_CLOVER') {
      // 🌟 3. Draw Radiant Golden Clover (البرسيم الذهبي المشع)
      ctx.save();
      const spinAngle = (stateRef.current.elapsedFrames * 0.12) + coin.id;
      ctx.rotate(spinAngle);

      // Dazzling golden glow
      ctx.shadowBlur = 22;
      ctx.shadowColor = '#eab308';

      // 5 radiant golden petals
      for (let i = 0; i < 5; i++) {
        ctx.rotate((Math.PI * 2) / 5);
        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(0, -8, 6, 0, Math.PI * 2);
        ctx.fill();
        // Inner sparkling white center
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, -8, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // Center golden jewel
      ctx.fillStyle = '#ca8a04';
      ctx.beginPath();
      ctx.arc(0, 0, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, 0, 2, 0, Math.PI * 2);
      ctx.fill();

      ctx.shadowBlur = 0;
      ctx.restore();
    } else if (coin.type === 'CORN') {
      // 🌽 2. Draw Egyptian Sweet Corn Cob (الذرة)
      ctx.save();
      const hoverY = Math.sin((stateRef.current.elapsedFrames * 0.1) + coin.id) * 3;
      ctx.translate(0, hoverY);

      // Golden aura glow
      ctx.shadowBlur = 12;
      ctx.shadowColor = '#f59e0b';

      // Green husk leaves at base
      ctx.fillStyle = '#16a34a';
      ctx.beginPath();
      ctx.ellipse(-5, 4, 3.5, 9, -Math.PI / 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(5, 4, 3.5, 9, Math.PI / 6, 0, Math.PI * 2);
      ctx.fill();

      // Main golden corn ear
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.roundRect(-7, -14, 14, 22, 6);
      ctx.fill();

      // Kernel texture grid
      ctx.fillStyle = '#d97706';
      for (let r = -10; r <= 4; r += 3.5) {
        for (let c = -4; c <= 4; c += 3.5) {
          ctx.beginPath();
          ctx.arc(c, r, 1.2, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Corn Silk golden threads on top
      ctx.strokeStyle = '#ca8a04';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(-3, -14);
      ctx.lineTo(-5, -19);
      ctx.moveTo(0, -14);
      ctx.lineTo(0, -20);
      ctx.moveTo(3, -14);
      ctx.lineTo(5, -19);
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.restore();
    } else if (coin.type === 'MAGNET') {
      // 🧲 3. Draw Horseshoe Magnet (المغناطيس)
      ctx.save();
      const spinAngle = Math.sin((stateRef.current.elapsedFrames * 0.08) + coin.id) * 0.2;
      ctx.rotate(spinAngle);

      // Electric blue glow
      ctx.shadowBlur = 14;
      ctx.shadowColor = '#38bdf8';

      // Outer horseshoe curve (Red)
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 5.5;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.arc(0, 0, 11, Math.PI, 0, false);
      ctx.stroke();

      // Magnet legs
      ctx.beginPath();
      ctx.moveTo(-11, 0);
      ctx.lineTo(-11, 10);
      ctx.moveTo(11, 0);
      ctx.lineTo(11, 10);
      ctx.stroke();

      // Silver / Blue metal tips
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 5.5;
      ctx.beginPath();
      ctx.moveTo(-11, 6);
      ctx.lineTo(-11, 11);
      ctx.moveTo(11, 6);
      ctx.lineTo(11, 11);
      ctx.stroke();

      // Electric spark arcs between poles
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-7, 10);
      ctx.lineTo(0, 8);
      ctx.lineTo(7, 10);
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.restore();
    } else {
      // 🍀 1. Draw Eid Clover (البرسيم) - Vibrant golden 4-leaf clover
      const spinAngle = (stateRef.current.elapsedFrames * 0.08) + coin.id;
      ctx.rotate(spinAngle);

      ctx.fillStyle = '#22c55e'; // Vibrant fresh clover green
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#16a34a';
      
      // Draw 4 rounded pedals
      for (let i = 0; i < 4; i++) {
        ctx.rotate(Math.PI / 2);
        ctx.beginPath();
        ctx.arc(0, -6, 5.5, 0, Math.PI * 2);
        ctx.fill();
        // Inner golden highlight
        ctx.fillStyle = '#86efac';
        ctx.beginPath();
        ctx.arc(0, -6, 2.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#22c55e';
      }

      // Stem
      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(3, 8, 5, 10);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    ctx.restore();
  };

  // Draw 3D-looking cartoon Obstacle
  const drawObstacle = (
    ctx: CanvasRenderingContext2D, 
    ob: GameObstacle, 
    w: number, 
    h: number, 
    horizonY: number, 
    hTargetLine: number
  ) => {
    const { screenY, laneSpacing, scale } = getPerspective(ob.z, w, h, horizonY, hTargetLine);
    const screenX = w / 2 + (ob.lane - 1) * laneSpacing + ob.xOffset * (scale / 1.35);

    ctx.save();
    ctx.translate(screenX, screenY);
    ctx.scale(scale, scale);

    if (ob.type === 'TUKTUK') {
      // Draw a Red Popular Egyptian Tuk Tuk!
      // Backing wheel shadows
      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      ctx.fillRect(-22, -4, 44, 5);

      // Main Cab body
      ctx.fillStyle = '#dc2626'; // bright red
      ctx.beginPath();
      ctx.roundRect(-24, -38, 48, 34, 4);
      ctx.fill();

      // Cab frame details / glass window
      ctx.fillStyle = '#e2e8f0'; // glass
      ctx.beginPath();
      ctx.roundRect(-19, -34, 38, 14, 2);
      ctx.fill();
      
      // Driver seat boundary black lines
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-24, -18, 48, 3);

      // Yellow Headlights
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(-16, -11, 4, 0, Math.PI * 2);
      ctx.arc(16, -11, 4, 0, Math.PI * 2);
      ctx.fill();

      // Slogans "توك توك جدعان" / popular eyes
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 5px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('توك توك', 0, -3);

      // License plate
      ctx.fillStyle = '#ca8a04';
      ctx.fillRect(-10, -8, 20, 5);
      ctx.fillStyle = '#000';
      ctx.font = 'bold 4px sans-serif';
      ctx.fillText('ب ب س 1', 0, -4);

      // Front steering handle & tire
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-4, -4, 8, 5); // mud wheel

    } else if (ob.type === 'VEG_CART') {
      // Wood vegetable cart "عربية خضار شعبية"
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      ctx.ellipse(0, 0, 24, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      // Wooden beams
      ctx.fillStyle = '#78350f'; // brown oak
      ctx.fillRect(-22, -15, 44, 11); // base cart bed
      
      // Wheel spokes left & right
      ctx.fillStyle = '#451a03';
      ctx.beginPath();
      ctx.arc(-22, -6, 6, 0, Math.PI * 2);
      ctx.arc(22, -6, 6, 0, Math.PI * 2);
      ctx.fill();

      // Red/White striped canopy awning
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-20, -15);
      ctx.lineTo(-20, -45); // pole left
      ctx.moveTo(20, -15);
      ctx.lineTo(20, -45); // pole right
      ctx.stroke();

      // Canopy
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(-24, -48, 48, 8);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-16, -48, 8, 8);
      ctx.fillRect(8, -48, 8, 8);

      // Fruits (Red Ripe Tomatoes & Oranges inside wooden bed - NO green to avoid confusion with clovers!)
      ctx.fillStyle = '#ef4444'; // bright red tomatoes
      ctx.beginPath();
      ctx.arc(-10, -18, 5, 0, Math.PI * 2);
      ctx.arc(10, -18, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#f97316'; // orange citrus
      ctx.beginPath();
      ctx.arc(0, -18, 5, 0, Math.PI * 2);
      ctx.fill();

    } else if (ob.type === 'BARRIER') {
      // Road barrier with striped warning paint
      ctx.fillStyle = '#475569';
      ctx.fillRect(-20, -2, 4, 2); // left leg
      ctx.fillRect(16, -2, 4, 2); // right leg
      
      // Horizontal warning block
      ctx.fillStyle = '#facc15'; // yellow base
      ctx.fillRect(-22, -15, 44, 13);

      // Draw black diagonal warning stripes
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.moveTo(-16, -15); ctx.lineTo(-10, -15); ctx.lineTo(-15, -2); ctx.lineTo(-21, -2); ctx.fill();
      ctx.moveTo(-4, -15); ctx.lineTo(2, -15); ctx.lineTo(-3, -2); ctx.lineTo(-9, -2); ctx.fill();
      ctx.moveTo(8, -15); ctx.lineTo(14, -15); ctx.lineTo(9, -2); ctx.lineTo(3, -2); ctx.fill();

    } else if (ob.type === 'CLOTHESLINE') {
      // High-hanging poles with traditional Egyptian clothes hanging down!
      // Must slide, as it blocks the top area.
      ctx.strokeStyle = '#451a03';
      ctx.lineWidth = 3;
      // Tall side poles
      ctx.beginPath();
      ctx.moveTo(-45, 0); ctx.lineTo(-45, -65);
      ctx.moveTo(45, 0); ctx.lineTo(45, -65);
      ctx.stroke();

      // Saggy laundry thread
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(-45, -55);
      ctx.quadraticCurveTo(0, -42, 45, -55);
      ctx.stroke();

      // Hanging visual clothes (little colored blocks - NO green!)
      ctx.fillStyle = '#3b82f6'; // blue pants
      ctx.fillRect(-25, -46, 8, 12);
      ctx.fillStyle = '#f59e0b'; // golden yellow shirt (changed from green)
      ctx.fillRect(-8, -43, 11, 10);
      ctx.fillStyle = '#ec4899'; // pink towel
      ctx.fillRect(12, -45, 12, 10);

    } else if (ob.type === 'WATERMELON') {
      // Traditional Egyptian Clay Jugs (قلل فخار مصرية) - warm terracotta, ZERO green!
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.ellipse(0, 0, 15, 3, 0, 0, Math.PI * 2);
      ctx.fill();

      // Three terracotta clay pots
      ctx.fillStyle = '#c2410c'; // terracotta red-orange
      ctx.beginPath();
      ctx.arc(-6, -6, 5.5, 0, Math.PI * 2);
      ctx.arc(6, -6, 5.5, 0, Math.PI * 2);
      ctx.arc(0, -12, 6, 0, Math.PI * 2);
      ctx.fill();
      
      // Clay jug necks
      ctx.fillStyle = '#ea580c';
      ctx.fillRect(-8, -13, 4, 4);
      ctx.fillRect(4, -13, 4, 4);
      ctx.fillRect(-2, -20, 4, 5);

    } else {
      // 'FOUL_POT' (Traditional copper Foul bean pot - القدرة)
      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      ctx.ellipse(0, 0, 10, 3, 0, 0, Math.PI * 2);
      ctx.fill();

      // Shining brass/bronze pot body
      ctx.fillStyle = '#b45309';
      ctx.beginPath();
      ctx.arc(0, -11, 11, 0, Math.PI * 2); // round body
      ctx.fill();
      
      // Neck
      ctx.fillStyle = '#d97706';
      ctx.fillRect(-6, -23, 12, 6);
      // Rim
      ctx.fillStyle = '#ca8a04';
      ctx.fillRect(-8, -25, 16, 3);
      
      // Shadow shine/handle
      ctx.strokeStyle = '#451a03';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, -11, 11, -Math.PI / 4, Math.PI / 2);
      ctx.stroke();
    }

    ctx.restore();
  };

  // --------------------------------------------------------------------
  // DRAW CUTE CARTOON SHEEP WITH OUTIFITS
  // --------------------------------------------------------------------
  const drawSheep = (ctx: CanvasRenderingContext2D, x: number, y: number, p: PlayerState, bounceY: number) => {
    // Collect outfit config
    const activeOutfit = OUTFITS.find(o => o.id === p.activeOutfit) || OUTFITS[0];
    const woolColor = activeOutfit.color;

    ctx.save();
    ctx.translate(x, y);

    // Apply squashing factor when sliding
    if (p.isDucking) {
      ctx.scale(1.22, 0.58);
    } else {
      // standard slight lateral stretch based on moving speed
      const stretchSign = (p.targetX - p.currentX) * 0.0035;
      ctx.rotate(stretchSign);
    }

    // 1. Draw 4 thin black trotting legs (oscillating if running on ground)
    ctx.fillStyle = '#111827';
    const runningCycle = p.isJumping ? 0 : stateRef.current.elapsedFrames * 0.22;
    // Left front leg
    const lfAngle = Math.sin(runningCycle) * 11;
    ctx.save();
    ctx.translate(-8, -4);
    ctx.rotate((lfAngle * Math.PI) / 180);
    ctx.fillRect(-2, 0, 4.5, 12);
    ctx.restore();

    // Right front leg
    const rfAngle = -Math.sin(runningCycle) * 11;
    ctx.save();
    ctx.translate(8, -4);
    ctx.rotate((rfAngle * Math.PI) / 180);
    ctx.fillRect(-2.2, 0, 4.5, 12);
    ctx.restore();

    // Back legs
    const lbAngle = Math.cos(runningCycle) * 9;
    ctx.save();
    ctx.translate(-14, -4);
    ctx.rotate((lbAngle * Math.PI) / 180);
    ctx.fillRect(-2, 0, 4.5, 11);
    ctx.restore();

    const rbAngle = -Math.cos(runningCycle) * 9;
    ctx.save();
    ctx.translate(14, -4);
    ctx.rotate((rbAngle * Math.PI) / 180);
    ctx.fillRect(-2, 0, 4.5, 11);
    ctx.restore();

    // 2. Draw fluffy cloud-like white Wool body (Main sheep sphere)
    const shieldActive = (stateRef.current.powerups.SHIELD?.durationLeft || 0) > 0;
    if (shieldActive) {
      // Subtle garlic shield shimmer/flash pulse on sheep wool
      const pulse = 0.5 + 0.5 * Math.sin(stateRef.current.elapsedFrames * 0.35);
      ctx.shadowBlur = 10 + pulse * 14;
      ctx.shadowColor = pulse > 0.5 ? '#10b981' : '#facc15';
    }
    ctx.fillStyle = woolColor;
    ctx.beginPath();
    // Use multi-circle fluff overlapping for nice distinct cartoon style look
    ctx.arc(0, -18, 17, 0, Math.PI * 2); // central body
    ctx.arc(-11, -18, 13, 0, Math.PI * 2); // left puff
    ctx.arc(11, -18, 13, 0, Math.PI * 2); // right puff
    ctx.arc(-6, -26, 11, 0, Math.PI * 2); // top puff left
    ctx.arc(6, -26, 11, 0, Math.PI * 2); // top puff right
    ctx.fill();

    // Inner shadow details for cloud effect
    ctx.fillStyle = p.activeOutfit === 'pharaoh' ? 'rgba(217,119,6,0.1)' : 'rgba(0,0,0,0.06)';
    ctx.beginPath();
    ctx.arc(-8, -12, 8, 0, Math.PI * 2);
    ctx.arc(8, -12, 8, 0, Math.PI * 2);
    ctx.fill();

    // 3. Draw black/pink cartoon Head centered
    ctx.fillStyle = '#1f2937'; // deep dark grey leather sheep face
    ctx.beginPath();
    ctx.ellipse(0, -20, 11, 12, 0, 0, Math.PI * 2);
    ctx.fill();

    // Floppy ears on the sides
    ctx.beginPath();
    ctx.ellipse(-14, -22, 4, 10, (15 * Math.PI) / 180, 0, Math.PI * 2); // left ear
    ctx.ellipse(14, -22, 4, 10, (-15 * Math.PI) / 180, 0, Math.PI * 2); // right ear
    ctx.fill();

    // Ear inside pink skin
    ctx.fillStyle = '#fda4af';
    ctx.beginPath();
    ctx.ellipse(-13.5, -22, 1.8, 7, (15 * Math.PI) / 180, 0, Math.PI * 2);
    ctx.ellipse(13.5, -22, 1.8, 7, (-15 * Math.PI) / 180, 0, Math.PI * 2);
    ctx.fill();

    // 4. Large comic Eyes (They look back panicked, or close contentedly in Fatta boost!)
    const boostActive = stateRef.current.powerups.BOOST.durationLeft > 0;
    const isHurt = stateRef.current.isHurtCooldown > 0;
    
    if (boostActive) {
      // Happy content curved closed eyes ^_^
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      // left happy arch
      ctx.arc(-5, -21, 3, Math.PI, 0, false);
      // right happy arch
      ctx.arc(5, -21, 3, Math.PI, 0, false);
      ctx.stroke();
    } else if (isHurt) {
      // Dizzy crossed 'X X' eyes
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.beginPath();
      // Left X
      ctx.moveTo(-7, -23); ctx.lineTo(-3, -19);
      ctx.moveTo(-3, -23); ctx.lineTo(-7, -19);
      // Right X
      ctx.moveTo(3, -23); ctx.lineTo(7, -19);
      ctx.moveTo(7, -23); ctx.lineTo(3, -19);
      ctx.stroke();
    } else {
      // Large panicked wide-open round white eyes looking backwards/downwards (at chasing butcher!)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(-5.2, -22, 4.2, 0, Math.PI * 2);
      ctx.arc(5.2, -22, 4.2, 0, Math.PI * 2);
      ctx.fill();

      // Black pupils shifted down-right looking at the butcher chasing behind!
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.arc(-4.2, -21, 2, 0, Math.PI * 2);
      ctx.arc(6.2, -21, 2, 0, Math.PI * 2);
      ctx.fill();
    }

    // Little pink smile/tongue
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.arc(0, -14, 2.5, 0, Math.PI);
    ctx.fill();

    // 5. Draw outfit specific accessories!
    if (p.activeOutfit === 'tarbush') {
      // Red Egyptian Tarbush (Fez) tilted!
      ctx.fillStyle = '#dc2626'; // pure red
      ctx.beginPath();
      ctx.moveTo(-7, -32);
      ctx.lineTo(-4, -45);
      ctx.lineTo(4, -45);
      ctx.lineTo(7, -32);
      ctx.closePath();
      ctx.fill();
      
      // Black tassel thread hanging
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(0, -45);
      ctx.quadraticCurveTo(-10, -43, -13, -33);
      ctx.stroke();

    } else if (p.activeOutfit === 'saidi') {
      // Thick Egyptian Saidi Turban wrap
      ctx.fillStyle = '#f3f4f6'; // Clean white folded cloth wrapped
      ctx.beginPath();
      ctx.roundRect(-10, -35, 20, 8, 4);
      ctx.fill();
      ctx.beginPath();
      ctx.roundRect(-7, -39, 14, 6, 3);
      ctx.fill();

    } else if (p.activeOutfit === 'cool') {
      // Cool black sunglasses
      ctx.fillStyle = '#1e293b';
      // Left glass box
      ctx.beginPath();
      ctx.moveTo(-9, -24); ctx.lineTo(-2, -24); ctx.lineTo(-3, -19); ctx.lineTo(-9, -19);
      ctx.closePath(); ctx.fill();
      // Right glass box
      ctx.beginPath();
      ctx.moveTo(2, -24); ctx.lineTo(9, -24); ctx.lineTo(9, -19); ctx.lineTo(3, -19);
      ctx.closePath(); ctx.fill();
      // Bridge connection
      ctx.strokeStyle = '#d97706'; // Golden shades metal bridge
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-2, -22); ctx.lineTo(2, -22);
      ctx.stroke();

      // Shiny golden neck chain
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(0, -10, 8, 0.1 * Math.PI, 0.9 * Math.PI);
      ctx.stroke();

    } else if (p.activeOutfit === 'pharaoh') {
      // Golden Pharaoh striped crown (Nemes look)
      ctx.fillStyle = '#fbbf24'; // main gold
      ctx.beginPath();
      ctx.moveTo(-11, -30);
      ctx.lineTo(-8, -48);
      ctx.lineTo(-2, -49);
      ctx.lineTo(0, -56); // peak center
      ctx.lineTo(2, -49);
      ctx.lineTo(8, -48);
      ctx.lineTo(11, -30);
      ctx.closePath();
      ctx.fill();

      // Blue horizontal crown stripes
      ctx.strokeStyle = '#1e3a8a';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-8, -35); ctx.lineTo(8, -35);
      ctx.moveTo(-8, -42); ctx.lineTo(8, -42);
      ctx.stroke();

    } else if (p.activeOutfit === 'mallem_baladi') {
      // 1. Traditional Baladi Scarf / Kafiyyeh draped over shoulders
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.roundRect(-14, -14, 28, 9, 3);
      ctx.fill();
      // Scarf checkered pattern
      ctx.fillStyle = '#ffffff';
      for (let xPos = -12; xPos <= 10; xPos += 5) {
        ctx.fillRect(xPos, -13, 2.5, 7);
      }
      // Hanging scarf fringes
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(-11, -5, 6, 12);
      ctx.fillRect(5, -5, 6, 10);

      // 2. Impressive Black Baladi Mustache on sheep face!
      ctx.fillStyle = '#111827';
      ctx.beginPath();
      ctx.ellipse(-4, -15, 5, 2.5, 0.2, 0, Math.PI * 2);
      ctx.ellipse(4, -15, 5, 2.5, -0.2, 0, Math.PI * 2);
      ctx.fill();

      // 3. Amber Sibha (prayer beads) around neck
      ctx.fillStyle = '#f59e0b';
      for (let b = 0; b < 5; b++) {
        ctx.beginPath();
        ctx.arc(-8 + b * 4, -3, 1.8, 0, Math.PI * 2);
        ctx.fill();
      }

    } else if (p.activeOutfit === 'boxer_tyson') {
      // 1. Red Boxing Gloves on front hooves!
      ctx.fillStyle = '#ef4444';
      ctx.shadowBlur = 6;
      ctx.shadowColor = '#dc2626';
      ctx.beginPath();
      ctx.arc(-16, -6, 7, 0, Math.PI * 2);
      ctx.arc(16, -6, 7, 0, Math.PI * 2);
      ctx.fill();
      // White laces
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-18, -8, 4, 1.5);
      ctx.fillRect(14, -8, 4, 1.5);
      ctx.shadowBlur = 0;

      // 2. Championship Gold Belt around torso
      ctx.fillStyle = '#facc15';
      ctx.fillRect(-14, -10, 28, 5);
      ctx.fillStyle = '#ca8a04';
      ctx.beginPath();
      ctx.arc(0, -7.5, 4, 0, Math.PI * 2);
      ctx.fill();

      // 3. Blue athletic fighter headband
      ctx.fillStyle = '#2563eb';
      ctx.beginPath();
      ctx.roundRect(-10, -29, 20, 4.5, 2);
      ctx.fill();

    } else if (p.activeOutfit === 'captain_stadium') {
      // 1. Green football jersey pattern on torso with white #10
      ctx.fillStyle = '#16a34a';
      ctx.beginPath();
      ctx.ellipse(0, -9, 13, 8, 0, 0, Math.PI * 2);
      ctx.fill();
      // White Number 10
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 8px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('10', 0, -6);

      // 2. Yellow Captain Armband (شارة الكابتن) on left leg
      ctx.fillStyle = '#facc15';
      ctx.fillRect(-17, -12, 5, 6);
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 6px sans-serif';
      ctx.fillText('C', -14.5, -7);

      // 3. Athletic headband with soccer ball motif
      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.roundRect(-10, -29, 20, 4.5, 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, -26.5, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.arc(0, -26.5, 1, 0, Math.PI * 2);
      ctx.fill();
    }

    // 6. Active Shield / Helmet visual barrier around whole sheep
    const shieldLeft = stateRef.current.powerups.SHIELD?.durationLeft || 0;
    if (shieldLeft > 0) {
      // Draw outer emerald green force-field bubble
      ctx.strokeStyle = `rgba(16, 185, 129, ${0.45 + (Math.sin(stateRef.current.elapsedFrames * 0.15) * 0.15)})`;
      ctx.lineWidth = 3.5;
      ctx.shadowBlur = 15;
      ctx.shadowColor = '#10b981';
      ctx.beginPath();
      ctx.arc(0, -16, 26, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    // 🎈 Floating Eid Balloons above sheep if isBalloonFloating is active!
    if (isBalloonFloating) {
      ctx.save();
      const bBob = Math.sin(stateRef.current.elapsedFrames * 0.18) * 3;
      // Golden strings from back (-26) up to balloons
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(0, -26); ctx.lineTo(-14, -58 + bBob);
      ctx.moveTo(0, -26); ctx.lineTo(0, -66 + bBob);
      ctx.moveTo(0, -26); ctx.lineTo(14, -60 + bBob);
      ctx.stroke();

      // 3 Glossy Shaded Balloons
      const bCols = [
        { fill: '#ef4444', light: '#fca5a5' },
        { fill: '#eab308', light: '#fef08a' },
        { fill: '#0ea5e9', light: '#7dd3fc' }
      ];
      const bOffsets = [{ x: -14, y: -58 }, { x: 0, y: -66 }, { x: 14, y: -60 }];
      bOffsets.forEach((b, i) => {
        // Balloon
        ctx.fillStyle = bCols[i].fill;
        ctx.beginPath();
        ctx.arc(b.x, b.y + bBob, 10, 0, Math.PI * 2);
        ctx.fill();
        // Highlight
        ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
        ctx.beginPath();
        ctx.arc(b.x - 3, b.y - 3 + bBob, 3, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.restore();
    }

    // Magnet visual magnetic spark lines
    const magnetLeft = stateRef.current.powerups.MAGNET.durationLeft;
    if (magnetLeft > 0) {
      ctx.strokeStyle = `rgba(59, 130, 246, ${0.4 + (Math.sin(stateRef.current.elapsedFrames * 0.2) * 0.2)})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(-18, -15, 6, Math.PI * 0.5, Math.PI * 1.5);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(18, -15, 6, Math.PI * 1.5, Math.PI * 2.5);
      ctx.stroke();
    }

    // Flying magic carpet below sheep if Fatta boost is active!
    if (boostActive) {
      // Draw beautiful red pattern oriental flying carpet
      ctx.fillStyle = '#dc2626'; // red base
      ctx.beginPath();
      ctx.roundRect(-25, 4, 50, 6, 2);
      ctx.fill();
      
      // golden fringes
      ctx.fillStyle = '#facc15';
      ctx.fillRect(-28, 5, 3, 4);
      ctx.fillRect(25, 5, 3, 4);
      
      // glowing carpet dust
      ctx.fillStyle = 'rgba(234, 179, 8, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, 7, 20, 2, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Nitro Rocket Propulsion flames beneath sheep!
    const nitroActive = (stateRef.current.powerups.NITRO?.durationLeft || 0) > 0;
    if (nitroActive) {
      const flicker = Math.sin(stateRef.current.elapsedFrames * 0.8) * 5;
      // Outer fiery orange exhaust flame
      ctx.fillStyle = '#f97316';
      ctx.beginPath();
      ctx.moveTo(-11, 4);
      ctx.lineTo(0, 22 + flicker);
      ctx.lineTo(11, 4);
      ctx.closePath();
      ctx.fill();

      // Inner golden yellow core flame
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.moveTo(-5, 4);
      ctx.lineTo(0, 14 + flicker * 0.6);
      ctx.lineTo(5, 4);
      ctx.closePath();
      ctx.fill();
    }

    ctx.restore();
  };

  // --------------------------------------------------------------------
  // DRAW CHASING BUTCHER "بسيوني"
  // --------------------------------------------------------------------
  const drawButcher = (ctx: CanvasRenderingContext2D, x: number, y: number, clFactor: number) => {
    // clFactor determines overall scale: 0.1 (far away) to 1.0 (extremely close catching up)
    const scale = 1.1 + clFactor * 0.55; 

    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    const runBeat = stateRef.current.elapsedFrames * 0.18;

    // Head backing shadow
    ctx.fillStyle = 'rgba(0,0,0,0.18)';
    ctx.beginPath();
    ctx.ellipse(0, -6, 28, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // 1. Stout comical Body (wears striped baladi galabeya with white apron over it)
    ctx.fillStyle = '#1e3a8a'; // blue galabeya
    ctx.beginPath();
    ctx.ellipse(0, -32, 22, 24, 0, 0, Math.PI * 2);
    ctx.fill();

    // White stained Apron
    ctx.fillStyle = '#f1f5f9';
    ctx.beginPath();
    ctx.moveTo(-11, -44);
    ctx.lineTo(11, -44);
    ctx.lineTo(15, -16);
    ctx.lineTo(-15, -16);
    ctx.closePath();
    ctx.fill();

    // Red sauce/ketchup comical spots on apron
    ctx.fillStyle = '#dc2626';
    ctx.beginPath();
    ctx.arc(-4, -28, 2.5, 0, Math.PI * 2);
    ctx.arc(5, -20, 1.8, 0, Math.PI * 2);
    ctx.fill();

    // 2. Head with giant mustache
    ctx.fillStyle = '#fdba74'; // warm tanned fat neck/face
    ctx.beginPath();
    ctx.arc(0, -62, 14, 0, Math.PI * 2);
    ctx.fill();

    // Stubby ears
    ctx.beginPath();
    ctx.arc(-14, -62, 3.5, 0, Math.PI * 2);
    ctx.arc(14, -62, 3.5, 0, Math.PI * 2);
    ctx.fill();
    
    // Angry black eyebrows
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.moveTo(-11, -70); ctx.lineTo(-2, -66); // tilted angry left
    ctx.moveTo(11, -70); ctx.lineTo(2, -66); // tilted angry right
    ctx.stroke();

    // Rolling cartoon bulging wide eyes
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-5.5, -61, 4.2, 0, Math.PI * 2);
    ctx.arc(5.5, -61, 4.2, 0, Math.PI * 2);
    ctx.fill();

    // Pupils looking straight ahead locked onto sheep butt!
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(-5.5, -63, 1.8, 0, Math.PI * 2);
    ctx.arc(5.5, -63, 1.8, 0, Math.PI * 2);
    ctx.fill();

    // Giant curved black Egyptian mustache!
    ctx.fillStyle = '#111827';
    ctx.beginPath();
    ctx.moveTo(-18, -52);
    ctx.quadraticCurveTo(0, -62, 18, -52);
    ctx.quadraticCurveTo(0, -42, -18, -52);
    ctx.fill();

    // Sweat beads flying out of head (comical chase indicator)
    ctx.fillStyle = '#60a5fa';
    const sweatL = Math.sin(runBeat) * 5;
    ctx.beginPath();
    ctx.arc(-18 + sweatL, -66, 2, 0, Math.PI * 2);
    ctx.arc(18 - sweatL, -66, 2, 0, Math.PI * 2);
    ctx.fill();

    // 3. Thick arms waving a giant wooden spoon (or comical paper flyswatter or light cleaver)
    ctx.strokeStyle = '#fdba74';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    
    // Left arm shaking
    const lArmOsc = Math.sin(runBeat) * 20;
    ctx.save();
    ctx.translate(-18, -38);
    ctx.rotate((lArmOsc * Math.PI) / 180);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-14, -14);
    ctx.stroke();
    ctx.restore();

    // Right arm holding wooden weapon waving
    const rArmOsc = Math.cos(runBeat) * 20;
    ctx.save();
    ctx.translate(18, -38);
    ctx.rotate((-rArmOsc * Math.PI) / 180);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(14, -14); // arm line
    ctx.stroke();

    // Draw weapons: Wooden rolling pin / big ladle
    ctx.fillStyle = '#b45309'; // wood color
    ctx.beginPath();
    ctx.roundRect(10, -32, 7, 22, 2); // paddle ladle handle
    ctx.fill();
    ctx.beginPath();
    ctx.arc(13.5, -34, 7.5, 0, Math.PI * 2); // spoon spoon scoop
    ctx.fill();
    ctx.restore();

    // 4. Heavy boots stomping (left/right up and down)
    ctx.fillStyle = '#450a0a'; // dark red leather boots
    const stompL = Math.sin(runBeat) > 0 ? -10 : 0;
    const stompR = Math.sin(runBeat) <= 0 ? -10 : 0;
    ctx.fillRect(-16, stompL - 8, 8, 10);
    ctx.fillRect(8, stompR - 8, 8, 10);

    ctx.restore();
  };

  // Comical Speech bubble drawing
  const drawSpeechBubble = (ctx: CanvasRenderingContext2D, x: number, y: number, text: string, isButcher?: boolean) => {
    ctx.font = 'bold 12px sans-serif';
    const textWidth = ctx.measureText(text).width;
    const bubW = textWidth + 18;
    const bubH = 26;

    ctx.fillStyle = isButcher ? '#fff5f5' : '#ffffff';
    ctx.strokeStyle = isButcher ? '#dc2626' : '#1e293b';
    ctx.lineWidth = isButcher ? 3.5 : 2.5;
    
    // Bubble Rounded rectangle
    ctx.beginPath();
    ctx.roundRect(x - bubW / 2, y - bubH / 2, bubW, bubH, 8);
    ctx.fill();
    ctx.stroke();

    // Triangle arrow pointing down
    ctx.fillStyle = isButcher ? '#fff5f5' : '#ffffff';
    ctx.beginPath();
    ctx.moveTo(x - 6, y + bubH / 2);
    ctx.lineTo(x + 6, y + bubH / 2);
    ctx.lineTo(x, y + bubH / 2 + 7);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x - 6, y + bubH / 2);
    ctx.lineTo(x, y + bubH / 2 + 7);
    ctx.lineTo(x + 6, y + bubH / 2);
    ctx.strokeStyle = isButcher ? '#dc2626' : '#1e293b';
    ctx.stroke();

    // Egyptian Quote Arabic Text centered
    ctx.fillStyle = isButcher ? '#bc1212' : '#1e293b';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, x, y);
  };

  // --------------------------------------------------------------------
  // INTERACTIVE TOUCH SWIPE OVERLAY AND TAP BUTTON PANEL FOR ACCESSIBILITY
  // --------------------------------------------------------------------
  // السحب: سحبة واحدة = حركة واحدة فقط، تُنفَّذ لحظة تجاوز الإصبع للحد الأدنى
  // (دون انتظار رفع الإصبع)، مهما كانت السحبة قوية أو طويلة. فالسحبة القوية من
  // اليمين تنقل الخروف للوسط فقط، ولا تتجاوزه لليسار.
  const SWIPE_THRESHOLD_PX = 22;
  const gesture = useRef({ active: false, handled: false, x: 0, y: 0 });

  const gestureStart = (x: number, y: number, target: EventTarget | null) => {
    // لا نبدأ سحبة من فوق الأزرار (للأزرار ضغطاتها الخاصة)
    const el = target as HTMLElement | null;
    const onButton = !!(el && typeof el.closest === 'function' && el.closest('button'));
    gesture.current = { active: !onButton, handled: false, x, y };
  };

  const gestureMove = (x: number, y: number) => {
    const g = gesture.current;
    if (!g.active || g.handled) return;
    if (gameState !== GameState.PLAYING || isOfflineFrozenRef.current || !isConnected()) return;
    const dx = x - g.x;
    const dy = y - g.y;
    if (Math.abs(dx) < SWIPE_THRESHOLD_PX && Math.abs(dy) < SWIPE_THRESHOLD_PX) return;
    g.handled = true; // سحبة واحدة = حركة واحدة
    if (Math.abs(dx) > Math.abs(dy)) {
      changeLane(dx > 0 ? 1 : -1); // يمين / يسار
    } else if (dy < 0) {
      triggerJump(); // لأعلى
    } else {
      triggerDuck(); // لأسفل
    }
  };

  const gestureEnd = () => {
    gesture.current.active = false;
  };

  const activeMagnet = hudStats.activeMagnet;
  const activeBoost = hudStats.activeBoost;

  return (
    <div 
      className="relative w-full h-full flex flex-col justify-between touch-none"
      ref={containerRef}
      onTouchStart={(e) => {
        if (e.touches.length > 1) return; // نتجاهل الإصبع الثاني ونكمل السحبة الأولى
        const t = e.touches[0];
        gestureStart(t.clientX, t.clientY, e.target);
      }}
      onTouchMove={(e) => {
        if (e.touches.length > 1) return;
        const t = e.touches[0];
        gestureMove(t.clientX, t.clientY);
      }}
      onTouchEnd={gestureEnd}
      onTouchCancel={gestureEnd}
      onMouseDown={(e) => gestureStart(e.clientX, e.clientY, e.target)}
      onMouseMove={(e) => { if (e.buttons === 1) gestureMove(e.clientX, e.clientY); }}
      onMouseUp={gestureEnd}
      onMouseLeave={gestureEnd}
    >
      {/* CANVAS ELEMENT FOR BUTTERY-SMOOTH RENDERING */}
      <canvas 
        ref={canvasRef} 
        id="sheep-game-canvas" 
        className="absolute top-0 left-0 w-full h-full block select-none touch-none bg-[#fdf2e9] rounded-[2.5rem] shadow-xl overflow-hidden"
      />

      {/* ⚠️ RED CRITICAL FLASH PULSING IF BUTCHER IS WITHIN GRASP */}
      {stateRef.current.player.warningFlash && (
        <div className="absolute inset-0 pointer-events-none border-[12px] border-red-600 animate-pulse bg-red-600/10 z-15 select-none rounded-[2.5rem]" />
      )}

      {/* COMPACT UNIFIED TOP HUD: CLOVERS, DISTANCE, SCORE, WEATHER & PAUSE IN A SINGLE SLEEK ROW */}
      <div className="absolute top-2 left-2 right-2 sm:left-4 sm:right-4 z-20 pointer-events-none select-none flex items-center justify-between gap-1.5 px-2.5 py-1.5 rounded-2xl bg-black/35 backdrop-blur-md border border-white/20 shadow-md">
        
        {/* Right side in Arabic RTL: Clovers & Pause Button */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Pause Button */}
          <button 
            id="compact-pause-btn"
            onClick={() => setGameState(GameState.PAUSED)}
            className="pointer-events-auto w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-orange-500/90 hover:bg-orange-500 active:scale-90 text-white flex items-center justify-center text-xs font-black shadow backdrop-blur-sm border border-white/40 transition-transform cursor-pointer"
            title="توقف مؤقت"
          >
            ⏸️
          </button>

          {/* Clovers Counter */}
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-xl bg-white/10 border border-white/15 text-white">
            <span className="text-xs sm:text-sm animate-bounce">🍀</span>
            <span className="text-emerald-300 font-black font-mono text-xs sm:text-sm">{hudStats.clovers}</span>
            <span className="text-[10px] text-white/60 font-bold hidden xs:inline">برسيم</span>
          </div>
        </div>

        {/* Center: Dynamic Weather Switcher */}
        <div className="flex items-center">
          <button
            onClick={() => changeWeather()}
            className="pointer-events-auto flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/15 hover:bg-white/25 active:scale-95 text-white text-[11px] font-bold border border-white/25 backdrop-blur-sm transition-all cursor-pointer shadow-sm"
            title="الطقس الحالي - اضغط للتغيير"
          >
            <span className="text-xs">{WEATHER_PRESETS[hudStats.currentWeather]?.badgeEmoji || '☀️'}</span>
            <span className="text-[10px] text-amber-200 font-bold hidden xs:inline">
              {WEATHER_PRESETS[hudStats.currentWeather]?.arabicName || 'شمس'}
            </span>
            <span className="text-[9px] text-amber-300 opacity-70">🔄</span>
          </button>
        </div>

        {/* Left side in Arabic RTL: Distance & Points */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Distance */}
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-xl bg-white/10 border border-white/15 text-white">
            <span className="text-[10px] text-white/70 font-bold">مسافة:</span>
            <span className="text-amber-300 font-black font-mono text-xs sm:text-sm">{hudStats.distance}m</span>
          </div>

          {/* Score */}
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-xl bg-white/10 border border-white/15 text-white">
            <span className="text-[10px] text-white/70 font-bold">نقاط:</span>
            <span className="text-yellow-300 font-black font-mono text-xs sm:text-sm">{hudStats.score}</span>
          </div>
        </div>
      </div>

      {/* SUB-BAR: SLIM BUTCHER DISTANCE TRACKER & POWER-UP BADGES (WITHOUT OVERLAP) */}
      <div className="absolute top-[44px] left-2 right-2 sm:left-4 sm:right-4 z-15 pointer-events-none select-none flex items-center justify-between gap-1.5">
        
        {/* Slim Butcher Distance Tracker */}
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-black/30 backdrop-blur-md border border-white/15 text-[10px] text-white">
          <span className="text-xs">🔪</span>
          <span className="font-bold text-[10px] text-red-300">بسيوني:</span>
          {hudStats.butcherDist < 35 ? (
            <span className="text-red-400 font-black animate-pulse text-[10px]">على قفاك!</span>
          ) : hudStats.butcherDist < 55 ? (
            <span className="text-amber-300 font-bold text-[10px]">بيقرّب!</span>
          ) : (
            <span className="text-emerald-300 font-bold text-[10px]">بعيد</span>
          )}
          <div className="w-12 sm:w-16 h-1.5 bg-white/20 rounded-full overflow-hidden border border-white/10">
            <div 
              className={`h-full rounded-full transition-all duration-300 ${hudStats.butcherDist < 32 ? 'bg-red-500' : hudStats.butcherDist < 52 ? 'bg-orange-500' : 'bg-green-500'}`}
              style={{ width: `${hudStats.butcherDist}%` }}
            />
          </div>
        </div>

        {/* Power-up Multipliers & Streak Badges */}
        <div className="flex items-center gap-1 flex-wrap justify-end">
          {hudStats.activeNitro > 0 && (
            <span className="px-1.5 py-0.5 rounded-full bg-red-600/90 backdrop-blur-md text-[9px] text-white font-black border border-red-400/50 animate-pulse flex items-center gap-0.5 shadow-sm">
              🌶️ شطة {hudStats.activeNitro}ث
            </span>
          )}
          {hudStats.activeShield > 0 && (
            <span className="px-1.5 py-0.5 rounded-full bg-emerald-600/90 backdrop-blur-md text-[9px] text-white font-black border border-emerald-400/50 animate-pulse flex items-center gap-0.5 shadow-sm">
              🍲 درع فتة {hudStats.activeShield}ث
            </span>
          )}
          {activeMagnet > 0 && (
            <span className="px-1.5 py-0.5 rounded-full bg-sky-500/80 backdrop-blur-md text-[9px] text-white font-black border border-sky-400/40 animate-pulse flex items-center gap-0.5">
              🧲 {activeMagnet}ث
            </span>
          )}
          {activeBoost > 0 && (
            <span className="px-1.5 py-0.5 rounded-full bg-amber-500/80 backdrop-blur-md text-[9px] text-white font-black border border-amber-400/40 animate-pulse flex items-center gap-0.5">
              🌽 x2 ({activeBoost}ث)
            </span>
          )}
          {hudStats.cloverStreak > 1 && (
            <span className="px-1.5 py-0.5 rounded-full bg-emerald-600/80 backdrop-blur-md text-[9px] text-white font-black border border-emerald-400/40 flex items-center gap-0.5">
              🍀 x{hudStats.cloverStreak}
            </span>
          )}
          {hudStats.comboCount > 1 && (
            <span className="px-1.5 py-0.5 rounded-full bg-orange-600/80 backdrop-blur-md text-[9px] text-white font-black border border-orange-400/40 flex items-center gap-0.5">
              🔥 x{Math.min(5, 1 + Math.floor(hudStats.comboCount / 8))}
            </span>
          )}
        </div>
      </div>

      {/* 🔥🚀 عداد تنازلي ومؤشر وقت طيران شطة الجزار النارية (Nitro Boost) والتنبيه لوقت النزول */}
      {hudStats.activeNitroFrames > 0 && (
        <div 
          id="nitro-flight-countdown-bar"
          className="absolute top-[72px] sm:top-[74px] left-1/2 -translate-x-1/2 z-25 pointer-events-none select-none transition-all duration-200 w-[92%] max-w-sm flex flex-col items-center"
          dir="rtl"
        >
          {/* Main Glowing Fiery Banner */}
          <div className={`w-full px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-2xl backdrop-blur-md shadow-2xl flex flex-col gap-1 border-2 transition-all duration-300 ${
            hudStats.activeNitroFrames <= 110 
              ? 'bg-gradient-to-r from-red-700/95 via-amber-600/95 to-red-700/95 border-yellow-300 animate-pulse shadow-[0_0_30px_rgba(239,68,68,0.9)] scale-[1.02]' 
              : 'bg-gradient-to-r from-red-600/90 via-orange-600/90 to-red-600/90 border-amber-300/80 shadow-[0_0_20px_rgba(239,68,68,0.6)]'
          }`}>
            
            {/* Top Row: Title, Chili Rocket Icon, and Remaining Time Countdown */}
            <div className="flex items-center justify-between text-white">
              <div className="flex items-center gap-1.5">
                <span className="text-base sm:text-lg animate-bounce">🌶️🚀</span>
                <div className="flex flex-col">
                  <span className="text-xs sm:text-sm font-black text-yellow-200 tracking-tight flex items-center gap-1">
                    شطة الجزار النارية
                    <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-black/40 text-yellow-300 font-bold border border-yellow-400/40">
                      طيران فائق
                    </span>
                  </span>
                </div>
              </div>

              {/* Big High-Visibility Countdown Timer */}
              <div className="flex items-center gap-1 bg-black/40 px-2 sm:px-2.5 py-0.5 rounded-xl border border-yellow-300/50 shadow-inner">
                <span className="text-[9px] text-yellow-300/80 font-bold">باقي:</span>
                <span className="font-mono text-sm sm:text-base font-black text-yellow-300 tracking-wider">
                  {(hudStats.activeNitroFrames / 60).toFixed(1)}
                </span>
                <span className="text-[9px] text-yellow-200 font-black">ثانية</span>
              </div>
            </div>

            {/* Visual Dynamic Progress Bar */}
            <div className="w-full h-2 bg-black/40 rounded-full overflow-hidden p-0.5 border border-white/20">
              <div 
                className={`h-full rounded-full transition-all duration-100 ${
                  hudStats.activeNitroFrames <= 110 
                    ? 'bg-gradient-to-r from-yellow-300 via-red-500 to-amber-300 animate-pulse' 
                    : 'bg-gradient-to-r from-yellow-300 via-amber-400 to-red-500'
                }`}
                style={{ 
                  width: `${Math.max(0, Math.min(100, (hudStats.activeNitroFrames / (hudStats.activeNitroMax || 360)) * 100))}%` 
                }}
              />
            </div>

            {/* Warning when approaching landing/descent (< 1.8 seconds remaining) */}
            {hudStats.activeNitroFrames <= 110 ? (
              <div className="flex items-center justify-center gap-1 py-0.5 px-2 rounded-lg bg-red-900/85 border border-yellow-300/80 text-[10px] sm:text-[11px] font-black text-yellow-200 animate-bounce">
                <span>⚠️</span>
                <span>انتبه! الهبوط للشارع وشيك.. استعد لتفادي العقبات!</span>
                <span>⚠️</span>
              </div>
            ) : (
              <div className="flex items-center justify-between text-[9px] text-amber-100/90 font-medium px-1">
                <span>✨ طيران فوق السيارات وتحطيم العقبات وجذب البرسيم!</span>
                <span className="text-yellow-300 font-black">سرعة x3 ⚡</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TRANSIENT WEATHER CHANGE TOAST BANNER */}
      {weatherToast && (
        <div className={`absolute ${hudStats.activeNitroFrames > 0 ? 'top-[144px]' : 'top-[70px]'} left-1/2 -translate-x-1/2 z-25 pointer-events-none select-none transition-all duration-300`}>
          <div className="bg-black/40 backdrop-blur-md text-white px-3 py-1 rounded-full border border-amber-400/50 flex items-center gap-1.5 text-[11px] shadow-lg animate-fadeIn">
            <span className="text-sm">{weatherToast.emoji}</span>
            <span className="text-yellow-200 font-black">{weatherToast.text}</span>
            <span className="text-amber-300 text-[9px] opacity-80">({weatherToast.subtitle})</span>
          </div>
        </div>
      )}

      {/* 🎈 EID BALLOON REVIVAL MODAL DIALOG */}
      {isReviveActive && (
        <div 
          id="revive-modal-overlay" 
          className="absolute inset-0 bg-black/80 backdrop-blur-md z-45 flex items-center justify-center p-4 text-center select-none animate-fadeIn"
          dir="rtl"
        >
          <div className="w-full max-w-xs bg-white rounded-3xl p-5 shadow-2xl border-4 border-rose-400 flex flex-col gap-3.5 text-center relative overflow-hidden animate-scale-up">
            {/* Header with balloons */}
            <div className="flex flex-col items-center justify-center">
              <span className="text-5xl animate-bounce">🎈🐑✨</span>
              <h3 className="text-rose-600 text-lg font-black tracking-tight mt-1">
                استخدم بالونة العيد واستمر!
              </h3>
              <p className="text-gray-500 text-xs mt-0.5 leading-relaxed">
                طر فوق ساطور المعلم بسيوني وكمل الجولة فوراً دون خسارة النتيجة!
              </p>
            </div>

            {/* Countdown circular timer */}
            <div className="flex items-center justify-center">
              <div className="w-14 h-14 rounded-full bg-rose-50 border-4 border-rose-500 flex items-center justify-center text-rose-600 font-mono font-black text-2xl animate-pulse shadow-sm">
                {reviveTimer}
              </div>
            </div>

            {/* Current Balloons inventory */}
            <div className="bg-rose-50 border border-rose-200 py-2 px-3 rounded-2xl flex items-center justify-between text-xs font-black">
              <span className="text-gray-600">رصيدك من بالونات العيد:</span>
              <span className="font-mono text-base text-rose-600 flex items-center gap-1">
                <span>{eidBalloons}</span>
                <span>🎈</span>
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-2 mt-1">
              {/* 1. فرار سريع 🏃‍♂️ (شاهد إعلان) */}
              <button
                onClick={() => setShowReviveAd(true)}
                className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:brightness-105 active:scale-95 text-white font-black text-sm py-2.5 px-3 rounded-2xl shadow-xl border-b-4 border-orange-700 cursor-pointer flex items-center justify-center gap-1.5 transition-all animate-bounce"
              >
                <span>🎬</span>
                <span>فرار سريع 🏃‍♂️ (شاهد إعلان)</span>
              </button>

              {/* 2. استخدام بالونة العيد إن وجدت */}
              <button
                onClick={handleUseReviveBalloon}
                className="w-full bg-gradient-to-r from-rose-500 to-pink-600 hover:brightness-105 active:scale-95 text-white font-black text-xs sm:text-sm py-2 px-3 rounded-xl shadow-md border-b-2 border-rose-700 cursor-pointer flex items-center justify-center gap-1.5 transition-all"
              >
                <span>🎈 استخدام بالونة العيد</span>
                {eidBalloons <= 0 && <span className="text-[10px] bg-black/20 px-1.5 py-0.5 rounded-full font-mono">(-60 🍀)</span>}
              </button>

              <button
                onClick={handleDeclineRevive}
                className="w-full bg-gray-100 hover:bg-gray-200 active:scale-95 text-gray-500 font-bold text-xs py-1.5 rounded-xl cursor-pointer transition-all"
              >
                استسلام للمصير ونهاية الجولة 🥩
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🎬 REWARDED AD MODAL FOR REVIVE */}
      {showReviveAd && (
        <RewardedAdModal
          placement="REVIVE_RUN"
          title="فرار سريع وإنقاذ الخروف"
          rewardDescription="فرار سريع ودرع حماية لمواصلة الجري فوراً 🏃‍♂️🛡️"
          onRewardGranted={() => {
            executeRevive("فرار سريع أنقذك! استمر في الهروب! 🏃‍♂️💨");
          }}
          onClose={() => {
            setShowReviveAd(false);
          }}
        />
      )}

      {/* 📖 TUTORIAL OVERLAY FOR FIRST-TIME RUNNERS */}
      {showTutorial && (
        <TutorialOverlay
          controlMode={controlMode}
          onClose={() => setShowTutorial(false)}
        />
      )}

      {/* SKIP INTRO CUTSCENE ACTION BUTTON */}
      {isIntroActive && (
        <div className="absolute top-[68px] left-1/2 -translate-x-1/2 z-30 select-none pointer-events-auto">
          <button
            onClick={skipIntro}
            className="bg-amber-600/90 hover:bg-amber-700 active:scale-95 text-white font-black text-[11px] px-3.5 py-1 rounded-full border border-yellow-300 shadow backdrop-blur-md cursor-pointer flex items-center gap-1 transition-all"
            title="تخطي المشهد والبدء فوراً"
          >
            <span>تخطي المشهد</span>
            <span>⏭️</span>
          </button>
        </div>
      )}

      {/* TOUCH CONTROLS HELPER OVERLAY BAR:
          عند اختيار السحب (Touch Swipe)، يتم إخفاء جميع الأزرار تماماً لتصبح الشاشة فارغة ونظيفة! */}
      {controlMode === 'buttons' && (
        <div className="absolute bottom-5 left-4 right-4 flex justify-between items-center z-10 gap-3">
          {/* Left Side Lane control buttons */}
          <div className="flex gap-2.5">
            <button 
              id="lane-left-btn"
              onClick={() => changeLane(-1)}
              className="w-13 h-13 rounded-full flat-btn-blue text-white flex justify-center items-center text-2xl font-black active:scale-95 transition-all shadow-md cursor-pointer pointer-events-auto z-10"
              title="حارة يسار"
            >
              ←
            </button>
            <button 
              id="lane-right-btn"
              onClick={() => changeLane(1)}
              className="w-13 h-13 rounded-full flat-btn-blue text-white flex justify-center items-center text-2xl font-black active:scale-95 transition-all shadow-md cursor-pointer pointer-events-auto z-10"
              title="حارة يمين"
            >
              →
            </button>
          </div>

          {/* Action Controls Side (Jump and Slide) */}
          <div className="flex gap-2.5">
            <button 
              id="jump-action-btn"
              onClick={triggerJump}
              className="px-5 h-13 rounded-2xl flat-btn-green text-white font-extrabold text-sm flex items-center gap-1.5 active:scale-95 transition-all shadow-md cursor-pointer pointer-events-auto z-10"
              title="قفز"
            >
              🦘 نطّ
            </button>
            <button 
              id="duck-action-btn"
              onClick={triggerDuck}
              className="px-5 h-13 rounded-2xl flat-btn-orange text-white font-extrabold text-sm flex items-center gap-1.5 active:scale-95 transition-all shadow-md cursor-pointer pointer-events-auto z-10"
              title="تزحلق"
            >
              🛹 اتزحلق
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
