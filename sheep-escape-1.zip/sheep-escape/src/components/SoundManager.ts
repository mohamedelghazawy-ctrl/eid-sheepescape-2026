/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

function safeGet(key: string, fallback: string | null = null): string | null {
  try {
    if (typeof window !== 'undefined' && typeof window.localStorage !== 'undefined') {
      return window.localStorage.getItem(key) ?? fallback;
    }
  } catch (e) {}
  return fallback;
}

function safeSet(key: string, value: string): void {
  try {
    if (typeof window !== 'undefined' && typeof window.localStorage !== 'undefined') {
      window.localStorage.setItem(key, value);
    }
  } catch (e) {}
}

class SoundManager {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private beatInterval: number | null = null;
  private currentTempo: number = 110; // BPM
  private currentTrack: 'ataba' | 'baladi' = 'ataba';

  constructor() {
    this.isMuted = safeGet('sheep_game_muted') === 'true';
    const savedTrack = safeGet('sheep_game_track');
    if (savedTrack === 'ataba' || savedTrack === 'baladi') {
      this.currentTrack = savedTrack;
    }
  }

  public setTrack(track: 'ataba' | 'baladi') {
    this.currentTrack = track;
    safeSet('sheep_game_track', track);
    if (!this.isMuted && this.beatInterval) {
      this.stopMusic();
      this.startMusic();
    }
  }

  public getTrack() {
    return this.currentTrack;
  }

  private initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public setMute(muted: boolean) {
    this.isMuted = muted;
    safeSet('sheep_game_muted', String(muted));
    if (muted) {
      this.stopMusic();
    } else {
      this.startMusic();
    }
  }

  public getMuted() {
    return this.isMuted;
  }

  // A cute synthetic sheep bleat "Baaa!"
  public playBaa() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    
    // Main vocal wave: FM synthesis
    const voiceOsc = this.ctx.createOscillator();
    const modulator = this.ctx.createOscillator();
    const modGain = this.ctx.createGain();
    const gainNode = this.ctx.createGain();

    voiceOsc.type = 'sawtooth';
    modulator.type = 'triangle';

    // Sheep-like vibrato and modulation
    voiceOsc.frequency.setValueAtTime(140 + Math.random() * 30, t);
    voiceOsc.frequency.exponentialRampToValueAtTime(120, t + 0.5);

    modulator.frequency.setValueAtTime(60, t);
    modGain.gain.setValueAtTime(100, t);

    // Filter to make it sound nasal/sheepish
    const biquad = this.ctx.createBiquadFilter();
    biquad.type = 'bandpass';
    biquad.Q.setValueAtTime(1.8, t);
    biquad.frequency.setValueAtTime(320, t);
    biquad.frequency.linearRampToValueAtTime(450, t + 0.35);

    gainNode.gain.setValueAtTime(0, t);
    gainNode.gain.linearRampToValueAtTime(0.3, t + 0.05);
    // tremolo wavering of the volume "ba-a-a-a"
    for (let i = 0.05; i < 0.45; i += 0.08) {
      gainNode.gain.linearRampToValueAtTime(0.12, t + i);
      gainNode.gain.linearRampToValueAtTime(0.28, t + i + 0.04);
    }
    gainNode.gain.exponentialRampToValueAtTime(0.01, t + 0.5);

    modulator.connect(modGain);
    modGain.connect(voiceOsc.frequency);
    voiceOsc.connect(biquad);
    biquad.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    modulator.start(t);
    voiceOsc.start(t);

    modulator.stop(t + 0.55);
    voiceOsc.stop(t + 0.55);
  }

  // Butcher shout: Grunt "Hah!" or "Ta'ala!"
  public playButcherShout() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(85, t);
    osc.frequency.exponentialRampToValueAtTime(45, t + 0.3);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(600, t);

    gainNode.gain.setValueAtTime(0, t);
    gainNode.gain.linearRampToValueAtTime(0.25, t + 0.03);
    gainNode.gain.exponentialRampToValueAtTime(0.01, t + 0.35);

    osc.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.4);
  }

  // Jump bounce
  public playJump() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(150, t);
    osc.frequency.exponentialRampToValueAtTime(320, t + 0.25);

    gainNode.gain.setValueAtTime(0.2, t);
    gainNode.gain.exponentialRampToValueAtTime(0.01, t + 0.25);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.3);
  }

  // Slide swoosh
  public playSlide() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const bufferSize = this.ctx.sampleRate * 0.25; // 0.25s swoosh
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    
    // Add white noise
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(800, t);
    filter.frequency.exponentialRampToValueAtTime(200, t + 0.25);

    const gainNode = this.ctx.createGain();
    gainNode.gain.setValueAtTime(0.2, t);
    gainNode.gain.exponentialRampToValueAtTime(0.01, t + 0.25);

    noise.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    noise.start(t);
    noise.stop(t + 0.25);
  }

  // Clover pickup sound (retro coin chime)
  public playClover() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(523.25, t); // C5
    osc.frequency.setValueAtTime(659.25, t + 0.08); // E5
    osc.frequency.setValueAtTime(783.99, t + 0.16); // G5 (musical arpeggio)

    gainNode.gain.setValueAtTime(0, t);
    gainNode.gain.linearRampToValueAtTime(0.12, t + 0.02);
    gainNode.gain.exponentialRampToValueAtTime(0.01, t + 0.35);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.38);
  }

  // Power Up acquire
  public playPowerUp() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(261.63, t); // C4
    osc.frequency.linearRampToValueAtTime(523.25, t + 0.1);
    osc.frequency.linearRampToValueAtTime(1046.5, t + 0.2);

    gainNode.gain.setValueAtTime(0.2, t);
    gainNode.gain.linearRampToValueAtTime(0.2, t + 0.1);
    gainNode.gain.exponentialRampToValueAtTime(0.005, t + 0.3);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.35);
  }

  // Crash hit (metal/trash explosion)
  public playCrash() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    // White noise explosion
    const bufferSize = this.ctx.sampleRate * 0.4;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
       data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    // Deep low sub boom
    const boom = this.ctx.createOscillator();
    boom.type = 'sawtooth';
    boom.frequency.setValueAtTime(120, t);
    boom.frequency.exponentialRampToValueAtTime(20, t + 0.3);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(400, t);

    const gainNode = this.ctx.createGain();
    gainNode.gain.setValueAtTime(0.35, t);
    gainNode.gain.exponentialRampToValueAtTime(0.01, t + 0.4);

    noise.connect(filter);
    filter.connect(gainNode);
    boom.connect(gainNode);
    
    gainNode.connect(this.ctx.destination);

    noise.start(t);
    boom.start(t);

    noise.stop(t + 0.42);
    boom.stop(t + 0.42);
  }

  // Shield Break or Powerup wearoff
  public playShieldBreak() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(500, t);
    osc.frequency.linearRampToValueAtTime(100, t + 0.25);

    gainNode.gain.setValueAtTime(0.25, t);
    gainNode.gain.exponentialRampToValueAtTime(0.01, t + 0.3);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.32);
  }

  // Punch KO for Boxer Tyson skin
  public playPunchKO() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, t);
    osc.frequency.exponentialRampToValueAtTime(35, t + 0.28);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.32);
  }

  // Double jump athletic whistle for Captain Stadium skin
  public playDoubleJump() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, t);
    osc.frequency.exponentialRampToValueAtTime(880, t + 0.12);
    osc.frequency.exponentialRampToValueAtTime(1320, t + 0.22);

    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.25);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.28);
  }

  // Cartoon engine revving & fast turbo buzz for 'شطة الجزار النارية' (Nitro Boost)
  public playNitro() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;

    // 1. Comic Ignition Pop / Backfire
    const popOsc = this.ctx.createOscillator();
    const popGain = this.ctx.createGain();
    popOsc.type = 'triangle';
    popOsc.frequency.setValueAtTime(340, t);
    popOsc.frequency.exponentialRampToValueAtTime(70, t + 0.08);
    popGain.gain.setValueAtTime(0.35, t);
    popGain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
    popOsc.connect(popGain);
    popGain.connect(this.ctx.destination);
    popOsc.start(t);
    popOsc.stop(t + 0.1);

    // 2. Cartoon Engine Fast Buzz ("زنة محرك كرتوني سريعة") using rapid FM modulation
    const carrier = this.ctx.createOscillator();
    const mod = this.ctx.createOscillator();
    const modGain = this.ctx.createGain();
    const mainGain = this.ctx.createGain();

    carrier.type = 'sawtooth';
    // Revving from mid growl up to high-speed cartoon whine
    carrier.frequency.setValueAtTime(140, t);
    carrier.frequency.exponentialRampToValueAtTime(680, t + 0.45);
    carrier.frequency.linearRampToValueAtTime(580, t + 0.7);

    // High frequency vibrato/flutter LFO to produce the signature cartoon motor buzz ("زنة سريعة")
    mod.type = 'square';
    mod.frequency.setValueAtTime(42, t); // 42Hz rapid buzzing flutter
    mod.frequency.linearRampToValueAtTime(65, t + 0.5);

    modGain.gain.setValueAtTime(55, t); // modulation depth for raspy engine rumble
    modGain.gain.linearRampToValueAtTime(90, t + 0.45);

    mod.connect(carrier.frequency);

    mainGain.gain.setValueAtTime(0.28, t);
    mainGain.gain.setValueAtTime(0.32, t + 0.15);
    mainGain.gain.exponentialRampToValueAtTime(0.01, t + 0.75);

    carrier.connect(mainGain);
    mainGain.connect(this.ctx.destination);

    mod.start(t);
    carrier.start(t);
    mod.stop(t + 0.76);
    carrier.stop(t + 0.76);

    // 3. Fiery Turbo Rocket Exhaust Hiss (Filtered noise burst)
    try {
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.65);
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(500, t);
      filter.frequency.exponentialRampToValueAtTime(3200, t + 0.4);
      filter.Q.value = 2.5;

      const noiseGain = this.ctx.createGain();
      noiseGain.gain.setValueAtTime(0.01, t);
      noiseGain.gain.linearRampToValueAtTime(0.22, t + 0.12);
      noiseGain.gain.exponentialRampToValueAtTime(0.005, t + 0.65);

      whiteNoise.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(this.ctx.destination);

      whiteNoise.start(t);
      whiteNoise.stop(t + 0.66);
    } catch (e) {
      // Fallback if AudioBuffer creation is restricted
    }
  }

  // Radiant Golden Clover crystalline collection sound
  public playGoldenClover() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const notes = [659.25, 830.61, 987.77, 1318.51, 1661.22];
    notes.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, this.ctx!.currentTime + idx * 0.05);
      gain.gain.setValueAtTime(0.12, this.ctx!.currentTime + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx!.currentTime + idx * 0.05 + 0.3);
      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(this.ctx!.currentTime + idx * 0.05);
      osc.stop(this.ctx!.currentTime + idx * 0.05 + 0.35);
    });
  }

  // Eid Balloon revival celebratory fanfare
  public playBalloonRevive() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const notes = [523.25, 659.25, 783.99, 1046.50, 1318.51];
    notes.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, this.ctx!.currentTime + idx * 0.08);
      gain.gain.setValueAtTime(0.16, this.ctx!.currentTime + idx * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.005, this.ctx!.currentTime + idx * 0.08 + 0.45);
      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(this.ctx!.currentTime + idx * 0.08);
      osc.stop(this.ctx!.currentTime + idx * 0.08 + 0.5);
    });
  }

  // Flight countdown warning sound when approaching descent
  public playFlightWarning(pitchFactor: number = 1.0) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'sine';
    const baseFreq = 880 * pitchFactor; // High pitch alert ping
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.25, t + 0.08);

    gainNode.gain.setValueAtTime(0.12, t);
    gainNode.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.13);
  }

  // Play synthetic Egyptian "Darbouka" (Tabla) folk-beat loop with high-fidelity retro synth melodies!
  // It gives the game that classic baladi feel
  public startMusic() {
    if (this.isMuted) return;
    if (this.beatInterval) return; // Already running

    this.initContext();
    if (!this.ctx) return;

    let step = 0;
    const bpm = this.currentTempo;
    const intervalSec = 60 / bpm / 4; // 16th notes or sixteenth-note feel

    // Define retro synthesized melodies for the two traditional Egyptian tracks
    const ATABA_MELODY = [
      392.00, 0, 392.00, 466.16, 523.25, 0, 523.25, 466.16,
      392.00, 0, 349.23, 392.00, 466.16, 392.00, 349.23, 0, // El Ataba Gazaz (Bar 1)
      392.00, 0, 392.00, 466.16, 523.25, 0, 523.25, 0,
      587.33, 523.25, 466.16, 392.00, 349.23, 392.00, 392.00, 0   // El Ataba Gazaz (Bar 2)
    ];

    const BALADI_MELODY = [
      523.25, 523.25, 587.33, 622.25, 523.25, 0, 587.33, 466.16,
      523.25, 0, 523.25, 523.25, 587.33, 622.25, 698.46, 0, // Saidi Baladi Beat (Bar 1)
      622.25, 698.46, 783.99, 0, 698.46, 622.25, 587.33, 0,
      523.25, 587.33, 466.16, 392.00, 523.25, 523.25, 523.25, 0   // Saidi Baladi Beat (Bar 2)
    ];

    const dumm = (time: number) => {
      // Deep bass strike
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(65, time); // Deep low
      osc.frequency.exponentialRampToValueAtTime(45, time + 0.15);

      gain.gain.setValueAtTime(0.28, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(time);
      osc.stop(time + 0.22);
    };

    const takk = (time: number, isEdge = false) => {
      // Sharp crisp slap
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(isEdge ? 1800 : 1200, time);
      
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1000, time);

      gain.gain.setValueAtTime(isEdge ? 0.08 : 0.12, time);
      gain.gain.exponentialRampToValueAtTime(0.005, time + 0.08);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx!.destination);
      osc.start(time);
      osc.stop(time + 0.1);
    };

    const playLeadNote = (freq: number, time: number, isShort = false) => {
      if (!this.ctx || freq === 0) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      // Retro chiptune sound
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, time);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1200, time);

      gain.gain.setValueAtTime(0.05, time); // Sweet, subtle level so it doesn't blast ears
      const dur = isShort ? 0.07 : 0.15;
      gain.gain.exponentialRampToValueAtTime(0.001, time + dur);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start(time);
      osc.stop(time + dur + 0.02);
    };

    const scheduler = () => {
      if (!this.ctx) return;
      const lookahead = 0.15;
      const playTime = this.ctx.currentTime + lookahead;

      // Traditional Egyptian Maqsum/Saidi Rhythm (DUM - DUM - TAK - DUM - TAK)
      const beatPattern = step % 8;
      
      if (beatPattern === 0) {
        dumm(playTime); // DUM (Strong center hit)
      } else if (beatPattern === 2) {
        takk(playTime); // TAK (Heavy slap)
      } else if (beatPattern === 4) {
        dumm(playTime); // DUM (Second bass-strike)
      } else if (beatPattern === 6) {
        takk(playTime, true); // TAK (Quick filler slap)
      } else if (beatPattern === 7) {
        takk(playTime); // TAK
      }

      // Play melody lead layer in sync 
      const melody = this.currentTrack === 'ataba' ? ATABA_MELODY : BALADI_MELODY;
      const noteFreq = melody[step % melody.length];
      if (noteFreq > 0) {
        const isShortNote = (step % 2 !== 0);
        playLeadNote(noteFreq, playTime, isShortNote);
      }

      step++;
    };

    // Low latency scheduler using real setInterval
    this.beatInterval = window.setInterval(scheduler, intervalSec * 1000);
  }

  public stopMusic() {
    if (this.beatInterval) {
      window.clearInterval(this.beatInterval);
      this.beatInterval = null;
    }
  }

  public adjustTempo(speedMultiplier: number) {
    this.currentTempo = Math.min(180, 110 + speedMultiplier * 15);
    if (!this.isMuted) {
      this.stopMusic();
      this.startMusic();
    }
  }
}

export const gameSounds = new SoundManager();
