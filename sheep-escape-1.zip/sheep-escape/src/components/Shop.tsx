/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { OUTFITS, UPGRADES, getUpgradeCost } from '../utils/gameData';
import { SheepOutfit } from '../types';
import {
  getDailyAdLimits,
  recordCloverBalloonPurchase,
  canBuyCloverBalloonToday,
  recordAdBalloonWatched,
  getRemainingAdBalloons,
  recordLuckyBoxOpened,
  getRemainingLuckyBoxes,
  recordEidBundlePurchase,
  getEidBundleStatus,
  AdPlacement,
  DAILY_LIMITS,
} from '../utils/adsManager';
import { isEgyptianEidActive, getEidStatusDescription } from '../utils/eidCalendar';
import RewardedAdModal from './RewardedAdModal';
import BannerAdSpace from './BannerAdSpace';

interface ShopProps {
  clovers: number;
  subClovers: (amount: number) => void;
  unlockedOutfits: string[];
  unlockOutfit: (id: string) => void;
  activeOutfitId: string;
  setActiveOutfitId: (id: string) => void;
  magnetLevel: number;
  levelUpMagnet: () => void;
  cornLevel: number;
  levelUpCorn: () => void;
  shieldLevel: number;
  levelUpShield: () => void;
  goldenCloverLevel: number;
  levelUpGoldenClover: () => void;
  eidBalloons: number;
  addEidBalloons: (count: number) => void;
  onBack: () => void;
}

// --- High-Fidelity Custom Animated Icons for Shop ---
export function BalloonClusterIcon({ size = 'md', className = '' }: { size?: 'sm' | 'md' | 'lg' | 'hero'; className?: string }) {
  const dim = size === 'sm' ? 'w-7 h-7' : size === 'lg' ? 'w-16 h-16' : size === 'hero' ? 'w-24 h-24' : 'w-11 h-11';
  return (
    <div className={`relative inline-flex items-center justify-center select-none ${dim} ${className}`}>
      <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-lg overflow-visible">
        <defs>
          {/* 3D Glossy Balloon Gradients */}
          <radialGradient id="balloonRuby" cx="35%" cy="30%" r="72%">
            <stop offset="0%" stopColor="#fecdd3" />
            <stop offset="20%" stopColor="#f43f5e" />
            <stop offset="65%" stopColor="#be123c" />
            <stop offset="90%" stopColor="#881337" />
            <stop offset="100%" stopColor="#4c0519" />
          </radialGradient>
          <radialGradient id="balloonAzure" cx="35%" cy="30%" r="72%">
            <stop offset="0%" stopColor="#cffafe" />
            <stop offset="25%" stopColor="#06b6d4" />
            <stop offset="65%" stopColor="#0e7490" />
            <stop offset="90%" stopColor="#155e75" />
            <stop offset="100%" stopColor="#083344" />
          </radialGradient>
          <radialGradient id="balloonGold" cx="35%" cy="30%" r="72%">
            <stop offset="0%" stopColor="#fef9c3" />
            <stop offset="25%" stopColor="#facc15" />
            <stop offset="65%" stopColor="#ca8a04" />
            <stop offset="90%" stopColor="#854d0e" />
            <stop offset="100%" stopColor="#422006" />
          </radialGradient>
          <radialGradient id="balloonEmerald" cx="35%" cy="30%" r="72%">
            <stop offset="0%" stopColor="#d1fae5" />
            <stop offset="25%" stopColor="#10b981" />
            <stop offset="65%" stopColor="#047857" />
            <stop offset="90%" stopColor="#065f46" />
            <stop offset="100%" stopColor="#022c22" />
          </radialGradient>
          <radialGradient id="balloonViolet" cx="35%" cy="30%" r="72%">
            <stop offset="0%" stopColor="#f3e8ff" />
            <stop offset="25%" stopColor="#a855f7" />
            <stop offset="65%" stopColor="#7e22ce" />
            <stop offset="90%" stopColor="#581c87" />
            <stop offset="100%" stopColor="#2e1065" />
          </radialGradient>

          {/* Golden Silk Cord Gradient */}
          <linearGradient id="silkCord" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="50%" stopColor="#f59e0b" />
            <stop offset="100%" stopColor="#b45309" />
          </linearGradient>

          {/* Medallion Gold */}
          <radialGradient id="goldMedallion" cx="35%" cy="30%" r="65%">
            <stop offset="0%" stopColor="#fef9c3" />
            <stop offset="40%" stopColor="#eab308" />
            <stop offset="85%" stopColor="#ca8a04" />
            <stop offset="100%" stopColor="#713f12" />
          </radialGradient>

          <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2.5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Ambient Halo behind balloons */}
        <circle cx="60" cy="50" r="48" fill="rgba(251, 191, 36, 0.15)" />

        {/* Balloon Strings - Elegant flowing silk cords */}
        <path d="M34 56 Q 46 80 58 102" stroke="url(#silkCord)" strokeWidth="1.8" fill="none" strokeLinecap="round" />
        <path d="M44 48 Q 52 75 59 102" stroke="url(#silkCord)" strokeWidth="2" fill="none" strokeLinecap="round" />
        <path d="M60 48 Q 60 78 60 102" stroke="url(#silkCord)" strokeWidth="2.2" fill="none" strokeLinecap="round" />
        <path d="M78 52 Q 68 78 61 102" stroke="url(#silkCord)" strokeWidth="2" fill="none" strokeLinecap="round" />
        <path d="M88 58 Q 74 82 62 102" stroke="url(#silkCord)" strokeWidth="1.8" fill="none" strokeLinecap="round" />

        {/* Balloon 1: Azure Sky (Back Left) */}
        <g>
          {/* Nozzle */}
          <polygon points="32,54 36,54 34,57" fill="#083344" />
          {/* Body */}
          <ellipse cx="32" cy="38" rx="16" ry="19" fill="url(#balloonAzure)" />
          {/* Reflection */}
          <ellipse cx="27" cy="30" rx="4" ry="8" transform="rotate(-25 27 30)" fill="white" opacity="0.6" />
          <circle cx="31" cy="24" r="2" fill="white" opacity="0.8" />
        </g>

        {/* Balloon 2: Emerald Clover (Back Right) */}
        <g>
          <polygon points="86,56 90,56 88,59" fill="#022c22" />
          <ellipse cx="88" cy="40" rx="15" ry="18" fill="url(#balloonEmerald)" />
          <ellipse cx="93" cy="32" rx="4" ry="7.5" transform="rotate(25 93 32)" fill="white" opacity="0.6" />
          <circle cx="89" cy="26" r="2" fill="white" opacity="0.8" />
        </g>

        {/* Balloon 3: Royal Violet (Top Center) */}
        <g>
          <polygon points="58,45 62,45 60,48" fill="#2e1065" />
          <ellipse cx="60" cy="27" rx="17" ry="20" fill="url(#balloonViolet)" />
          <ellipse cx="54" cy="18" rx="4.5" ry="8.5" transform="rotate(-15 54 18)" fill="white" opacity="0.6" />
          <circle cx="58" cy="13" r="2.2" fill="white" opacity="0.85" />
        </g>

        {/* Balloon 4: Festive Gold (Middle Right) */}
        <g>
          <polygon points="76,50 80,50 78,53" fill="#422006" />
          <ellipse cx="76" cy="34" rx="17" ry="20.5" fill="url(#balloonGold)" />
          <ellipse cx="81" cy="25" rx="4.5" ry="9" transform="rotate(20 81 25)" fill="white" opacity="0.65" />
          <circle cx="77" cy="19" r="2.5" fill="white" opacity="0.85" />
        </g>

        {/* Balloon 5: Radiant Ruby Red (Center Front - Hero) */}
        <g>
          <polygon points="46,54 52,54 49,58" fill="#4c0519" />
          <ellipse cx="48" cy="36" rx="19" ry="22" fill="url(#balloonRuby)" />
          {/* Specular Curved Gloss Arc */}
          <ellipse cx="41" cy="26" rx="5" ry="10" transform="rotate(-22 41 26)" fill="white" opacity="0.75" />
          <circle cx="45" cy="19" r="3" fill="white" opacity="0.9" />
          <ellipse cx="55" cy="46" rx="8" ry="3" fill="white" opacity="0.15" />
        </g>

        {/* Golden Eid Medallion / Clover Talisman at Cord Joint */}
        <g transform="translate(60, 103)">
          {/* Hanging Bow Ribbon */}
          <path d="M-6 -2 C-14 -12, -2 0, -8 6 C-3 3, 0 1, 0 0" fill="#f59e0b" />
          <path d="M6 -2 C14 -12, 2 0, 8 6 C3 3, 0 1, 0 0" fill="#d97706" />
          {/* Ring */}
          <circle cx="0" cy="0" r="5.5" fill="url(#goldMedallion)" stroke="#78350f" strokeWidth="1" />
          {/* Tiny 4-leaf clover engraved on medallion */}
          <circle cx="-1.5" cy="-1.5" r="1.5" fill="#15803d" />
          <circle cx="1.5" cy="-1.5" r="1.5" fill="#15803d" />
          <circle cx="-1.5" cy="1.5" r="1.5" fill="#15803d" />
          <circle cx="1.5" cy="1.5" r="1.5" fill="#15803d" />
          <circle cx="0" cy="0" r="1" fill="#facc15" />
        </g>

        {/* Twinkling Magical Stardust & Golden Confetti */}
        <g filter="url(#softGlow)">
          {/* Star 1 */}
          <path d="M14 26 L17 31 L22 32 L17 33 L14 38 L12 33 L7 32 L12 31 Z" fill="#fef08a" />
          {/* Star 2 */}
          <path d="M104 22 L106.5 26 L111 27 L106.5 28 L104 32 L101.5 28 L97 27 L101.5 26 Z" fill="#fde047" />
          {/* Star 3 */}
          <circle cx="20" cy="58" r="2.2" fill="#38bdf8" />
          <circle cx="102" cy="55" r="2.2" fill="#f43f5e" />
          <circle cx="60" cy="8" r="2.5" fill="#fde047" />
        </g>
      </svg>
    </div>
  );
}

export function LuckyBoxIcon({ size = 'md', className = '', isOpening = false }: { size?: 'sm' | 'md' | 'lg' | 'hero'; className?: string; isOpening?: boolean }) {
  const dim = size === 'sm' ? 'w-7 h-7' : size === 'lg' ? 'w-16 h-16' : size === 'hero' ? 'w-24 h-24' : 'w-11 h-11';
  return (
    <div className={`relative inline-flex items-center justify-center select-none ${dim} ${className} ${isOpening ? 'animate-bounce' : ''}`}>
      <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-xl overflow-visible">
        <defs>
          {/* Rich Egyptian Cedar / Mahogany Planks */}
          <linearGradient id="chestWoodRich" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#b45309" />
            <stop offset="30%" stopColor="#92400e" />
            <stop offset="65%" stopColor="#78350f" />
            <stop offset="100%" stopColor="#451a03" />
          </linearGradient>

          {/* Intricate Antique Brass Metal Straps */}
          <linearGradient id="chestGoldBrass" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fef9c3" />
            <stop offset="25%" stopColor="#fde047" />
            <stop offset="50%" stopColor="#eab308" />
            <stop offset="80%" stopColor="#ca8a04" />
            <stop offset="100%" stopColor="#713f12" />
          </linearGradient>

          {/* Inside Chest Dark Velvet Shadow */}
          <radialGradient id="chestInterior" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#7f1d1d" />
            <stop offset="70%" stopColor="#450a0a" />
            <stop offset="100%" stopColor="#1a0404" />
          </radialGradient>

          {/* Holy Golden Light Explosion */}
          <radialGradient id="divineLight" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
            <stop offset="30%" stopColor="#fef08a" stopOpacity="0.95" />
            <stop offset="60%" stopColor="#f59e0b" stopOpacity="0.7" />
            <stop offset="100%" stopColor="#ea580c" stopOpacity="0" />
          </radialGradient>

          <filter id="chestGlow" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="3.5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Ambient Ground Shadow */}
        <ellipse cx="60" cy="106" rx="46" ry="9" fill="rgba(0,0,0,0.38)" />

        {/* ✨ ERUPTING GOD-RAYS & CLOVERS WHEN OPENING */}
        {isOpening && (
          <g filter="url(#chestGlow)">
            {/* Blinding Radial Burst */}
            <circle cx="60" cy="52" r="48" fill="url(#divineLight)" className="animate-pulse" />

            {/* Radiant Sunburst Beams */}
            <line x1="60" y1="52" x2="10" y2="8" stroke="#fef08a" strokeWidth="3" strokeLinecap="round" opacity="0.9" />
            <line x1="60" y1="52" x2="35" y2="2" stroke="#fef08a" strokeWidth="2.5" strokeLinecap="round" opacity="0.8" />
            <line x1="60" y1="52" x2="60" y2="0" stroke="#fde047" strokeWidth="3.5" strokeLinecap="round" opacity="1" />
            <line x1="60" y1="52" x2="85" y2="2" stroke="#fef08a" strokeWidth="2.5" strokeLinecap="round" opacity="0.8" />
            <line x1="60" y1="52" x2="110" y2="8" stroke="#fef08a" strokeWidth="3" strokeLinecap="round" opacity="0.9" />

            {/* Flying Golden Clovers & Coins */}
            <g transform="translate(60, 22)">
              {/* Golden Clover */}
              <circle cx="-16" cy="-6" r="4" fill="#22c55e" />
              <circle cx="-11" cy="-10" r="4" fill="#16a34a" />
              <circle cx="-6" cy="-6" r="4" fill="#15803d" />
              <circle cx="-11" cy="-2" r="4" fill="#16a34a" />
              <circle cx="-11" cy="-6" r="2" fill="#facc15" />
              {/* Shiny Gold Coin */}
              <circle cx="16" cy="-8" r="7" fill="#facc15" stroke="#ca8a04" strokeWidth="1.5" />
              <text x="16" y="-5" fontSize="7" fontWeight="bold" textAnchor="middle" fill="#713f12">★</text>
            </g>
          </g>
        )}

        {/* CHEST INTERIOR (Visible when lid opens) */}
        {isOpening && (
          <rect x="18" y="52" width="84" height="22" rx="4" fill="url(#chestInterior)" stroke="#2b0e03" strokeWidth="2" />
        )}

        {/* CHEST MAIN BASE BODY */}
        <g>
          {/* Main Box Outer Frame */}
          <rect x="16" y="54" width="88" height="48" rx="8" fill="url(#chestWoodRich)" stroke="#2d1305" strokeWidth="2.5" />

          {/* Wood Planks Seams */}
          <line x1="16" y1="69" x2="104" y2="69" stroke="#3b1706" strokeWidth="2" />
          <line x1="16" y1="84" x2="104" y2="84" stroke="#3b1706" strokeWidth="2" />
          {/* Plank Highlights */}
          <line x1="18" y1="70.5" x2="102" y2="70.5" stroke="#f59e0b" strokeWidth="0.8" opacity="0.35" />
          <line x1="18" y1="85.5" x2="102" y2="85.5" stroke="#f59e0b" strokeWidth="0.8" opacity="0.35" />

          {/* Heavy Antique Brass Corner Reinforcements */}
          {/* Left Corner Bracket */}
          <path d="M16 56 Q 28 56 28 68 L 28 98 Q 28 102 24 102 L 16 102 Z" fill="url(#chestGoldBrass)" stroke="#713f12" strokeWidth="1" />
          {/* Right Corner Bracket */}
          <path d="M104 56 Q 92 56 92 68 L 92 98 Q 92 102 96 102 L 104 102 Z" fill="url(#chestGoldBrass)" stroke="#713f12" strokeWidth="1" />
          {/* Center Vertical Strap */}
          <rect x="52" y="54" width="16" height="48" fill="url(#chestGoldBrass)" stroke="#713f12" strokeWidth="1" />

          {/* Ornamental Studs (Rivets) */}
          <circle cx="22" cy="62" r="2.2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />
          <circle cx="22" cy="76" r="2.2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />
          <circle cx="22" cy="92" r="2.2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />
          <circle cx="98" cy="62" r="2.2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />
          <circle cx="98" cy="76" r="2.2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />
          <circle cx="98" cy="92" r="2.2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />
          <circle cx="60" cy="88" r="2.2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />
          <circle cx="60" cy="97" r="2.2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />

          {/* Brass Side Carrying Ring Handles */}
          <path d="M14 74 C 7 74, 7 86, 14 86" stroke="url(#chestGoldBrass)" strokeWidth="3" fill="none" strokeLinecap="round" />
          <path d="M106 74 C 113 74, 113 86, 106 86" stroke="url(#chestGoldBrass)" strokeWidth="3" fill="none" strokeLinecap="round" />
        </g>

        {/* CHEST ARCHED DOME LID (Hinged with animation when opening) */}
        <g transform={isOpening ? 'translate(0, -18) rotate(-14 60 52)' : 'translate(0, 0)'} className="transition-transform duration-300">
          {/* Arched Top Cap */}
          <path d="M 14 54 C 14 26, 106 26, 106 54 L 104 57 L 16 57 Z" fill="url(#chestWoodRich)" stroke="#2d1305" strokeWidth="2.5" />

          {/* Curved Wood Grain Lines on Lid */}
          <path d="M 15 45 C 35 32, 85 32, 105 45" stroke="#3b1706" strokeWidth="1.8" fill="none" />
          <path d="M 15 36 C 38 27, 82 27, 105 36" stroke="#3b1706" strokeWidth="1.8" fill="none" />

          {/* Arched Brass Bands Over Lid */}
          <path d="M 14 54 C 14 30, 32 30, 32 54 L 28 56 L 14 56 Z" fill="url(#chestGoldBrass)" stroke="#713f12" strokeWidth="1" />
          <path d="M 106 54 C 106 30, 88 30, 88 54 L 92 56 L 106 56 Z" fill="url(#chestGoldBrass)" stroke="#713f12" strokeWidth="1" />
          <path d="M 52 26 L 68 26 L 68 56 L 52 56 Z" fill="url(#chestGoldBrass)" stroke="#713f12" strokeWidth="1" />

          {/* Lid Rivets */}
          <circle cx="23" cy="44" r="2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />
          <circle cx="97" cy="44" r="2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />
          <circle cx="60" cy="33" r="2.2" fill="#fef08a" stroke="#451a03" strokeWidth="0.8" />

          {/* Embossed Royal Egyptian Sheep Emblem on Center Brass Band */}
          <g transform="translate(60, 42)">
            <ellipse cx="0" cy="0" rx="6" ry="5" fill="#ca8a04" stroke="#713f12" strokeWidth="0.8" />
            {/* Horns */}
            <path d="M -3 -2 Q -6 -6, -2 -5" stroke="#fef08a" strokeWidth="1.4" fill="none" />
            <path d="M 3 -2 Q 6 -6, 2 -5" stroke="#fef08a" strokeWidth="1.4" fill="none" />
            {/* Sheep Face */}
            <circle cx="0" cy="0.5" r="2.2" fill="#1e293b" />
          </g>

          {/* Heavy Gold Padlock & Hasps */}
          <rect x="50" y="52" width="20" height="22" rx="4" fill="url(#chestGoldBrass)" stroke="#713f12" strokeWidth="1.5" />
          <circle cx="60" cy="60" r="3.2" fill="#3b1706" />
          <polygon points="58.5,61 61.5,61 62,67 58,67" fill="#3b1706" />

          {/* Glowing Keyhole when closed or opening */}
          <circle cx="60" cy="60" r="1.5" fill="#fef08a" className="animate-ping" opacity="0.75" />
        </g>

        {/* Festoon Hanging Red Eid Tassels from Lock */}
        <g transform="translate(60, 74)">
          <path d="M-4 0 L-6 12 L-3 11 L0 12 L0 0 Z" fill="#dc2626" />
          <path d="M0 0 L0 12 L3 11 L6 12 L4 0 Z" fill="#b91c1c" />
          <circle cx="0" cy="0" r="2" fill="#eab308" />
        </g>

        {/* Twinkling Lucky Clovers floating nearby */}
        <g>
          {/* Clover Left */}
          <g transform="translate(10, 48) scale(0.8)">
            <circle cx="0" cy="-3" r="3" fill="#22c55e" />
            <circle cx="-3" cy="0" r="3" fill="#16a34a" />
            <circle cx="3" cy="0" r="3" fill="#15803d" />
            <circle cx="0" cy="3" r="3" fill="#16a34a" />
            <circle cx="0" cy="0" r="1.2" fill="#facc15" />
          </g>
          {/* Sparkles */}
          <circle cx="108" cy="46" r="2.5" fill="#fde047" className="animate-ping" />
          <circle cx="14" cy="98" r="1.8" fill="#facc15" />
        </g>
      </svg>
    </div>
  );
}

const REWARD_OPTIONS = [
  { title: 'طربوش الباشا فؤاد 👑⚜️', emoji: '🐐🏆', description: 'يا باشا يا ابن الباشاوات! لقيت طربوش الباشا التاريخي جواه كنز البرسيم الأصلي!', value: 250, rarity: 'ذهبي أسطوري (Jackpot!)' },
  { title: 'طبق فتة كوارع دوبل بالصلصة 🍲', emoji: '🍛🔥', description: 'يا عيني على الفتة! شحنة نشاط وطاقة ممتازة خلتك تكتشف كنز برسيم سري!', value: 120, rarity: 'ذهبي نادر' },
  { title: 'خزنة ورش المدبح السري 💰', emoji: '🧲💸', description: 'فتشت في زريبة المعلم بسيوني بالليل وصادفت خزنة مستخبية مليانة خير!', value: 60, rarity: 'فضي غير مألوف' },
  { title: 'غطاء حلة الفتّة الألومنيوم 🛡️', emoji: '🪖🛡️', description: 'غطا حامية الألومنيوم الأصلي بيحميك من العيون الحامية ورزق طيب!', value: 35, rarity: 'شائع' },
  { title: 'الفرخة البلدي الدايخة 🐣', emoji: '🐔🤪', description: 'طلعت فرخة بلدي دايخة! المعلم بسيوني حب يتذاكى عليك بس الفرخة سابتلك فكة البرسيم!', value: 15, rarity: 'تسلية كرتونية' },
];

export default function Shop({
  clovers,
  subClovers,
  unlockedOutfits,
  unlockOutfit,
  activeOutfitId,
  setActiveOutfitId,
  magnetLevel,
  levelUpMagnet,
  cornLevel,
  levelUpCorn,
  shieldLevel,
  levelUpShield,
  goldenCloverLevel,
  levelUpGoldenClover,
  eidBalloons,
  addEidBalloons,
  onBack,
}: ShopProps) {
  const [openingBox, setOpeningBox] = useState(false);
  const [boxReward, setBoxReward] = useState<typeof REWARD_OPTIONS[0] | null>(null);
  const [luckyBoxError, setLuckyBoxError] = useState<string | null>(null);
  const [balloonFeedback, setBalloonFeedback] = useState<string | null>(null);
  const [dailyLimits, setDailyLimits] = useState(() => getDailyAdLimits());
  const [activeAd, setActiveAd] = useState<{
    placement: AdPlacement;
    description: string;
    onGranted: () => void;
  } | null>(null);

  const refreshLimits = () => {
    setDailyLimits(getDailyAdLimits());
  };

  const gameSoundsPlayClick = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.frequency.setValueAtTime(450, audioCtx.currentTime);
      osc.frequency.setValueAtTime(600, audioCtx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.16);
    } catch (e) {}
  };

  const gameSoundsPlayHurt = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.frequency.setValueAtTime(220, audioCtx.currentTime);
      osc.frequency.setValueAtTime(140, audioCtx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.26);
    } catch (e) {}
  };

  // 1. Shraa Balloon Bel-Barseem (Limit: 1/day)
  const handleBuySingleBalloonClover = () => {
    if (!canBuyCloverBalloonToday()) {
      setBalloonFeedback('تم شراء بالونة اليوم بالفعل! عد غداً لشراء أخرى بالبرسيم ⏳');
      gameSoundsPlayHurt();
      setTimeout(() => setBalloonFeedback(null), 3000);
      return;
    }

    const cost = 60;
    if (clovers >= cost) {
      subClovers(cost);
      addEidBalloons(1);
      recordCloverBalloonPurchase();
      refreshLimits();
      gameSoundsPlayClick();
      setBalloonFeedback('تم شراء بالونة العيد بنجاح! 🎈✨ (تم استيفاء حصة اليوم 1/1)');
      setTimeout(() => setBalloonFeedback(null), 3500);
    } else {
      gameSoundsPlayHurt();
      setBalloonFeedback('تحتاج لـ 60 🍀 على الأقل لشراء بالونة العيد!');
      setTimeout(() => setBalloonFeedback(null), 3000);
    }
  };

  // 2. Free Balloon via Rewarded Ad (Limit: 10/day)
  const handleWatchAdForBalloon = () => {
    const limits = getDailyAdLimits();
    if (limits.adBalloonsWatched >= DAILY_LIMITS.AD_BALLOONS_MAX) {
      setBalloonFeedback('استوفيت الحد الأقصى لإعلانات البالونات المجانية اليوم (10/10)! عد غداً ⏳');
      gameSoundsPlayHurt();
      setTimeout(() => setBalloonFeedback(null), 3000);
      return;
    }

    setActiveAd({
      placement: 'FREE_BALLOON',
      description: 'بالونة عيد مجانية إضافية للأرواح 🎈',
      onGranted: () => {
        const res = recordAdBalloonWatched();
        addEidBalloons(1);
        refreshLimits();
        gameSoundsPlayClick();
        setBalloonFeedback(`مبروك! شاهدت الإعلان وحصلت على بالونة عيد مجانية! 🎈🎬 (متبقي: ${res.remaining}/10)`);
        setTimeout(() => setBalloonFeedback(null), 3500);
      },
    });
  };

  // 3. Eid 3-Balloons Bundle (Eid holidays only, limit 2/day)
  const handleBuyEidBundle = () => {
    const status = getEidBundleStatus();
    if (!status.isEidActive) {
      setBalloonFeedback('باقة العيد مغلقة حالياً، وتُفتح تلقائياً في عطلات العيد الرسمية 🌙🔒');
      gameSoundsPlayHurt();
      setTimeout(() => setBalloonFeedback(null), 3000);
      return;
    }

    if (status.remaining <= 0) {
      setBalloonFeedback('استوفيت الحد اليومي لشراء باقات العيد اليوم (2/2)! عد غداً ⏳');
      gameSoundsPlayHurt();
      setTimeout(() => setBalloonFeedback(null), 3000);
      return;
    }

    const cost = 150;
    if (clovers >= cost) {
      subClovers(cost);
      addEidBalloons(3);
      recordEidBundlePurchase();
      refreshLimits();
      gameSoundsPlayClick();
      setBalloonFeedback('مبارك! تم شراء باقة العيد (3 بالونات) بنجاح! 🎈🎉');
      setTimeout(() => setBalloonFeedback(null), 3500);
    } else {
      gameSoundsPlayHurt();
      setBalloonFeedback('تحتاج لـ 150 🍀 لشراء باقة العيد!');
      setTimeout(() => setBalloonFeedback(null), 3000);
    }
  };

  // 4. Open Lucky Box via Rewarded Ad Only (Limit: 2/day)
  const handleOpenLuckyBox = () => {
    const limits = getDailyAdLimits();
    if (limits.luckyBoxesOpened >= DAILY_LIMITS.LUCKY_BOX_MAX) {
      setLuckyBoxError('استوفيت الحد الأقصى لفتح صناديق الحظ اليوم (2/2)! عد غداً لفتح المزيد ⏳');
      gameSoundsPlayHurt();
      setTimeout(() => setLuckyBoxError(null), 3500);
      return;
    }

    setActiveAd({
      placement: 'LUCKY_BOX',
      description: 'فتح صندوق الحظ والبرسيم البلدي 📦✨',
      onGranted: () => {
        recordLuckyBoxOpened();
        refreshLimits();
        setOpeningBox(true);
        setBoxReward(null);

        // Play funny arcade opening sound effects
        try {
          const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
          const osc = audioCtx.createOscillator();
          const gain = audioCtx.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(140, audioCtx.currentTime);
          osc.frequency.linearRampToValueAtTime(750, audioCtx.currentTime + 1.15);
          gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.2);
          osc.connect(gain);
          gain.connect(audioCtx.destination);
          osc.start();
          osc.stop(audioCtx.currentTime + 1.25);
        } catch (e) {}

        // Track total boxes opened
        try {
          const opened = Number(localStorage.getItem('sheep_game_boxes_opened') || '0') + 1;
          localStorage.setItem('sheep_game_boxes_opened', String(opened));
        } catch (e) {}

        setTimeout(() => {
          const rand = Math.random();
          let picked;
          if (rand < 0.08) {
            picked = REWARD_OPTIONS[0]; // 250
          } else if (rand < 0.25) {
            picked = REWARD_OPTIONS[1]; // 120
          } else if (rand < 0.50) {
            picked = REWARD_OPTIONS[2]; // 60
          } else if (rand < 0.78) {
            picked = REWARD_OPTIONS[3]; // 35
          } else {
            picked = REWARD_OPTIONS[4]; // 15
          }

          setBoxReward(picked);
          setOpeningBox(false);

          // Add prize clovers back to player ledger
          subClovers(-picked.value);

          // Joyful fanfare
          try {
            const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
            const chords = [329.63, 392.00, 523.25, 659.25, 783.99, 1046.50];
            chords.forEach((freq, idx) => {
              const osc = audioCtx.createOscillator();
              const gain = audioCtx.createGain();
              osc.frequency.setValueAtTime(freq, audioCtx.currentTime + idx * 0.08);
              gain.gain.setValueAtTime(0.05, audioCtx.currentTime + idx * 0.08);
              gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + idx * 0.08 + 0.3);
              osc.connect(gain);
              gain.connect(audioCtx.destination);
              osc.start(audioCtx.currentTime + idx * 0.08);
              osc.stop(audioCtx.currentTime + idx * 0.08 + 0.35);
            });
          } catch (e) {}

        }, 1200);
      },
    });
  };

  const handleBuyOutfit = (outfit: SheepOutfit) => {
    if (clovers >= outfit.price) {
      subClovers(outfit.price);
      unlockOutfit(outfit.id);
      setActiveOutfitId(outfit.id);
      gameSoundsPlayClick();
    } else {
      gameSoundsPlayHurt();
    }
  };

  const handleEquipOutfit = (outfit: SheepOutfit) => {
    setActiveOutfitId(outfit.id);
    gameSoundsPlayClick();
  };

  // Upgrades detail lookup helper
  const getUpgradeLevel = (id: string) => {
    if (id === 'magnet_upgrade') return magnetLevel;
    if (id === 'corn_upgrade') return cornLevel;
    if (id === 'shield_upgrade') return shieldLevel;
    if (id === 'golden_clover_upgrade') return goldenCloverLevel;
    return 1;
  };

  const getUpgradeLevelUpFn = (id: string) => {
    if (id === 'magnet_upgrade') return levelUpMagnet;
    if (id === 'corn_upgrade') return levelUpCorn;
    if (id === 'shield_upgrade') return levelUpShield;
    if (id === 'golden_clover_upgrade') return levelUpGoldenClover;
    return () => {};
  };

  return (
    <div className="w-full h-full bg-white p-3.5 sm:p-5 text-right flex flex-col select-none font-sans relative z-30 overflow-hidden">
      
      {/* SHOP HEADER */}
      <div className="flex justify-between items-center border-b-2 border-orange-100 pb-3.5 z-10 shrink-0">
        {/* Clovers count remaining & Balloons counter */}
        <div className="flex items-center gap-2">
          <div className="bg-orange-50 px-3.5 py-1.5 rounded-full flex items-center gap-1.5 border border-orange-200">
            <span className="text-xl">🍀</span>
            <span className="text-amber-600 font-extrabold text-base font-mono">{clovers}</span>
          </div>
          <div className="bg-rose-50 px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-rose-200" title="بالونات العيد للأرواح الإضافية">
            <span className="text-lg">🎈</span>
            <span className="text-rose-600 font-extrabold text-sm font-mono">{eidBalloons}</span>
          </div>
        </div>
        
        <h2 className="text-[#e67e22] text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
          🎪 دكان الخروف السعيد
        </h2>
      </div>

      {/* SCROLLABLE SHOP CONTENT CONTAINER */}
      <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden pr-1 z-10 my-2.5 flex flex-col gap-5 pb-[70px] [scrollbar-width:thin] [scrollbar-color:#e67e22_transparent]">
        
        {/* 0. بالونات العيد (Extra Life Hearts) */}
        <div className="shrink-0 bg-gradient-to-br from-rose-50 via-pink-50 to-rose-100/90 border-2 border-rose-300 rounded-3xl p-4 sm:p-5 shadow-sm text-right relative flex flex-col gap-3.5">
          <div className="flex flex-wrap sm:flex-nowrap justify-between items-center gap-2">
            <div className="bg-rose-500 px-3 py-1 rounded-full text-white font-black text-[11px] uppercase tracking-wider flex items-center gap-1.5 shadow-xs shrink-0">
              <BalloonClusterIcon size="sm" />
              <span>أرواح إضافية</span>
            </div>
            <h3 className="text-[#2c3e50] font-black text-sm sm:text-base flex items-center gap-2">
              <BalloonClusterIcon size="md" />
              <span>بالونات العيد (طيران بعد الاصطدام)</span>
            </h3>
          </div>

          <p className="text-[#2c3e50] text-xs sm:text-[13px] leading-relaxed">
            استخدم بالونة العيد لتطير فوق الساطور وتكمل الجري فوراً بعد أي اصطدام دون خسارة النتيجة أو المسافة!
          </p>

          <div className="flex items-center justify-between bg-white/95 p-3 rounded-2xl border border-rose-200 text-xs shadow-xs">
            <span className="text-rose-800 font-black flex items-center gap-2">
              <BalloonClusterIcon size="sm" />
              <span>رصيدك من بالونات العيد:</span>
              <span className="font-mono text-lg font-black text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded-xl border border-rose-200">{eidBalloons}</span>
            </span>
          </div>

          {/* Balloon Purchase Cards: 3 Distinct Options */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {/* 1. بالونة واحدة بالبرسيم (حد أقصى: 1 يومياً) */}
            <div className="bg-white/90 border-2 border-rose-200 rounded-2xl p-3 flex flex-col items-center justify-between text-center gap-2 shadow-xs">
              <div className="flex flex-col items-center">
                <BalloonClusterIcon size="md" />
                <span className="font-black text-xs text-[#2c3e50] mt-1">بالونة واحدة</span>
                <span className="text-[10px] text-gray-500 font-bold">شراء بالبرسيم (1 يومياً)</span>
              </div>
              <div className="w-full">
                {dailyLimits.cloverBalloonBought ? (
                  <button
                    disabled
                    className="w-full bg-gray-100 text-gray-400 font-black text-[11px] py-2 px-2 rounded-xl cursor-not-allowed border border-gray-200"
                  >
                    تم الشراء اليوم، عد غداً ⏳
                  </button>
                ) : (
                  <button
                    onClick={handleBuySingleBalloonClover}
                    className="w-full bg-rose-50 hover:bg-rose-100 active:scale-95 text-rose-700 font-black text-xs py-2 px-2 rounded-xl border border-rose-300 shadow-xs cursor-pointer flex items-center justify-center gap-1 transition-all"
                  >
                    <span>شراء: 60 🍀</span>
                    <span className="text-[9px] bg-rose-200 text-rose-800 px-1.5 rounded-full font-mono">1/1</span>
                  </button>
                )}
              </div>
            </div>

            {/* 2. بالونة مجانية 🎬 (شاهد إعلان) (حد أقصى: 10 يومياً) */}
            <div className="bg-gradient-to-b from-amber-50 to-orange-50 border-2 border-amber-300 rounded-2xl p-3 flex flex-col items-center justify-between text-center gap-2 shadow-xs relative overflow-hidden">
              <span className="absolute top-1.5 right-1.5 bg-amber-500 text-white text-[8.5px] font-black px-1.5 py-0.5 rounded-full">
                مجاناً! 🎬
              </span>
              <div className="flex flex-col items-center">
                <div className="relative">
                  <BalloonClusterIcon size="md" />
                  <span className="absolute -bottom-1 -right-1 text-sm">🎬</span>
                </div>
                <span className="font-black text-xs text-orange-950 mt-1">بالونة مجانية 🎬</span>
                <span className="text-[10px] font-mono font-bold text-amber-800">
                  متبقي: {DAILY_LIMITS.AD_BALLOONS_MAX - dailyLimits.adBalloonsWatched} / {DAILY_LIMITS.AD_BALLOONS_MAX}
                </span>
              </div>
              <div className="w-full">
                {dailyLimits.adBalloonsWatched >= DAILY_LIMITS.AD_BALLOONS_MAX ? (
                  <button
                    disabled
                    className="w-full bg-gray-100 text-gray-400 font-black text-[11px] py-2 px-2 rounded-xl cursor-not-allowed border border-gray-200"
                  >
                    استوفيت إعلانات اليوم
                  </button>
                ) : (
                  <button
                    onClick={handleWatchAdForBalloon}
                    className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 active:scale-95 text-white font-black text-xs py-2 px-2 rounded-xl shadow-md border-b-2 border-orange-700 cursor-pointer flex items-center justify-center gap-1 transition-all"
                  >
                    <span>شاهد إعلان 🎬</span>
                    <span className="text-[9px] bg-black/20 text-white px-1.5 rounded-full font-mono">
                      {DAILY_LIMITS.AD_BALLOONS_MAX - dailyLimits.adBalloonsWatched}/{DAILY_LIMITS.AD_BALLOONS_MAX}
                    </span>
                  </button>
                )}
              </div>
            </div>

            {/* 3. باقة العيد (3 بالونات) (متاحة في عطلات العيد الرسمية فقط، حد أقصى: 2 يومياً) */}
            {(() => {
              const eidStatus = getEidBundleStatus();
              const isLocked = !eidStatus.isEidActive;
              const isLimitReached = eidStatus.isEidActive && eidStatus.remaining <= 0;

              return (
                <div className={`border-2 rounded-2xl p-3 flex flex-col items-center justify-between text-center gap-2 shadow-xs relative overflow-hidden ${
                  isLocked ? 'bg-gray-50 border-gray-200 opacity-80' : 'bg-gradient-to-b from-rose-50 to-pink-100 border-rose-300'
                }`}>
                  <div className="flex flex-col items-center">
                    <div className="flex items-center justify-center -space-x-2">
                      <BalloonClusterIcon size="md" />
                      <BalloonClusterIcon size="sm" className="opacity-80" />
                    </div>
                    <span className="font-black text-xs text-[#2c3e50] mt-1">باقة العيد (3 بالونات)</span>
                    <span className="text-[9.5px] font-bold text-rose-700">
                      {isLocked ? 'عطلات العيد الرسمية 🌙' : `متبقي اليوم: ${eidStatus.remaining}/2`}
                    </span>
                  </div>
                  <div className="w-full">
                    {isLocked ? (
                      <div className="w-full bg-gray-100 text-gray-500 font-bold text-[10px] py-2 px-1.5 rounded-xl border border-gray-200 leading-tight">
                        متاحة خلال أيام العيد فقط 🔒
                      </div>
                    ) : isLimitReached ? (
                      <button
                        disabled
                        className="w-full bg-gray-100 text-gray-400 font-black text-[10.5px] py-2 px-1.5 rounded-xl cursor-not-allowed border border-gray-200"
                      >
                        استوفيت باقات اليوم (2/2) ⏳
                      </button>
                    ) : (
                      <button
                        onClick={handleBuyEidBundle}
                        className="w-full bg-gradient-to-r from-rose-500 to-pink-600 hover:brightness-105 active:scale-95 text-white font-black text-xs py-2 px-2 rounded-xl shadow-md border-b-2 border-rose-800 cursor-pointer flex items-center justify-center gap-1 transition-all"
                      >
                        <span>شراء: 150 🍀</span>
                        <span className="text-[9px] bg-rose-900/40 text-yellow-200 px-1.5 rounded-full font-mono">
                          {eidStatus.remaining}/2
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })()}
          </div>

          {balloonFeedback && (
            <div className="text-rose-800 text-xs font-black bg-rose-100/90 border border-rose-300 p-2 rounded-xl text-center">
              {balloonFeedback}
            </div>
          )}
        </div>

        {/* 1. صندوق الحظ البلدي (إعلانات فقط - حد أقصى 2 يومياً) */}
        <div className="shrink-0 bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100/90 border-2 border-orange-400 rounded-3xl p-4 sm:p-5 shadow-md text-right relative flex flex-col gap-3.5">
          <div className="flex flex-wrap sm:flex-nowrap justify-between items-center gap-2">
            <div className="bg-[#f59e0b] px-3 py-1 rounded-full text-white font-extrabold text-[11px] uppercase tracking-wider flex items-center gap-1.5 shadow-xs shrink-0">
              <LuckyBoxIcon size="sm" />
              <span>مكافآت الإعلانات فقط 🎬🎁</span>
            </div>
            <h3 className="text-[#2c3e50] font-black text-sm sm:text-base flex items-center gap-2">
              <LuckyBoxIcon size="md" />
              <span>صندوق الحظ والبرسيم البلدي</span>
            </h3>
          </div>

          <p className="text-[#2c3e50] text-xs sm:text-[13px] leading-relaxed">
            شاهد إعلاناً قصيراً وافتح صندوق المفاجآت مجاناً واكسب كنز برسيم سري يصل إلى 250 زهرة، أو طربوش الباشا الأسطوري! 🎩💰 (متاح مرتين يومياً).
          </p>

          <div className="flex flex-col sm:flex-row justify-between items-center bg-white/90 backdrop-blur-xs px-4 py-3 rounded-2xl border border-orange-200 shadow-xs gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black text-gray-600">الفرص المتبقية اليوم:</span>
              <span className="font-mono font-black text-sm text-orange-600 bg-orange-50 border border-orange-200 px-2.5 py-0.5 rounded-lg">
                {DAILY_LIMITS.LUCKY_BOX_MAX - dailyLimits.luckyBoxesOpened} / {DAILY_LIMITS.LUCKY_BOX_MAX}
              </span>
            </div>

            {dailyLimits.luckyBoxesOpened >= DAILY_LIMITS.LUCKY_BOX_MAX ? (
              <button
                disabled
                className="w-full sm:w-auto font-black text-xs sm:text-sm py-2.5 px-4 rounded-xl bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed"
              >
                استوفيت فتح الصناديق اليوم (2/2)، عد غداً ⏳
              </button>
            ) : (
              <button
                onClick={handleOpenLuckyBox}
                disabled={openingBox}
                className={`w-full sm:w-auto font-black text-xs sm:text-sm py-2.5 px-5 rounded-xl active:scale-95 transition-all flex items-center justify-center gap-2 shadow-md ${
                  openingBox 
                    ? 'bg-orange-300 text-amber-50 cursor-not-allowed animate-pulse' 
                    : 'bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:brightness-105 text-white border-b-4 border-orange-700 cursor-pointer'
                }`}
              >
                <LuckyBoxIcon size="sm" isOpening={openingBox} />
                <span>{openingBox ? 'بيتحرك.. افتح! 🥁' : 'افتح الصندوق 🎬 (شاهد إعلان)'}</span>
              </button>
            )}
          </div>

          {luckyBoxError && (
            <div className="text-red-700 text-[10px] font-black leading-tight border border-red-200 bg-red-50 p-2 rounded-xl text-center">
              ⚠️ {luckyBoxError}
            </div>
          )}

          {openingBox && (
            <motion.div 
              className="py-6 flex flex-col items-center justify-center gap-3"
              animate={{ 
                rotate: [-3, 3, -3, 3, -4, 4, -2, 2, 0],
                scale: [1, 1.08, 0.96, 1.06, 0.95, 1.04, 1]
              }}
              transition={{ repeat: Infinity, duration: 0.6 }}
            >
              <LuckyBoxIcon size="hero" isOpening={true} />
              <span className="text-[12px] text-[#e67e22] font-black animate-pulse">جاري فك الحبل وفتح الصندوق البلدي... 🪵🥁✨</span>
            </motion.div>
          )}

          {boxReward && !openingBox && (
            <motion.div 
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="mt-2 text-center p-3.5 bg-white border-2 border-amber-300 rounded-2xl shadow-xl flex flex-col items-center justify-center gap-2 relative"
            >
              <div className="absolute top-2 left-2 text-[9px] bg-amber-100 text-[#b45309] px-2 py-0.5 rounded-full font-black">
                {boxReward.rarity}
              </div>
              <span className="text-5xl my-1 animate-bounce">{boxReward.emoji}</span>
              <span className="text-[#2c3e50] font-black text-sm block">مبروك! كسبت {boxReward.title}</span>
              <p className="text-gray-500 text-[10px] leading-relaxed max-w-sm mt-0.5">
                {boxReward.description}
              </p>
              
              <div className="bg-emerald-50 text-emerald-700 border border-emerald-250 font-extrabold font-mono text-xs px-4 py-1.5 rounded-full mt-1.5 flex items-center gap-1">
                <span>كسبت مكافأة:</span>
                <span className="text-center font-black text-emerald-600 font-mono">+{boxReward.value} 🍀</span>
              </div>

              <button
                onClick={() => setBoxReward(null)}
                className="mt-2 text-[10px] bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-black px-3.5 py-1.5 rounded-xl cursor-pointer"
              >
                استلام الجائزة البلدية تحيا مصر! 🇪🇬👋
              </button>
            </motion.div>
          )}

        </div>

        {/* 2. CLOTHES & OUTFITS (الأزياء والملابس المسلية مع الميزات الجديدة) */}
        <div className="shrink-0">
          <h3 className="text-[#2c3e50] text-xs font-black mb-3 border-r-4 border-orange-500 pr-2 pb-0.5 flex items-center justify-between">
            <span>👕 جلباب وأزياء خروف العيد</span>
            <span className="text-[10px] text-gray-400 font-normal">ميزات حصرية لكل زي!</span>
          </h3>
          
          <div className="grid grid-cols-1 gap-3.5">
            {OUTFITS.map((outfit) => {
              const isUnlocked = unlockedOutfits.includes(outfit.id);
              const isActive = activeOutfitId === outfit.id;
              const canAfford = clovers >= outfit.price;

              return (
                <div 
                  key={outfit.id}
                  className={`border-2 rounded-2xl p-3.5 flex justify-between items-center gap-3 transition-colors ${isActive ? 'bg-orange-100/40 border-orange-400' : 'bg-white border-orange-100 shadow-sm'}`}
                >
                  {/* Left Column (Unlock buy button) */}
                  <div className="flex-shrink-0">
                    {isActive ? (
                      <span className="bg-[#27ae60] text-white font-black text-[11px] px-3.5 py-1.5 rounded-xl border border-emerald-600">
                        مجهز حالياً 🐑
                      </span>
                    ) : isUnlocked ? (
                      <button
                        onClick={() => handleEquipOutfit(outfit)}
                        className="flat-btn-yellow text-[#2c3e50] font-black text-xs px-4 py-2 rounded-xl active:scale-95 transition-transform cursor-pointer"
                      >
                        ارتداء
                      </button>
                    ) : (
                      <button
                        onClick={() => handleBuyOutfit(outfit)}
                        disabled={!canAfford}
                        className={`font-black text-xs px-3.5 py-2 rounded-xl active:scale-95 transition-transform flex items-center gap-1.5 z-10 ${canAfford ? 'flat-btn-orange text-white cursor-pointer shadow-sm' : 'bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed'}`}
                      >
                        <span>شراء</span>
                        <span className="font-mono">{outfit.price} 🍀</span>
                      </button>
                    )}
                  </div>

                  {/* Right Column (Info of Outfit) */}
                  <div className="flex items-center gap-2 flex-1 justify-end">
                    <div className="flex flex-col text-right">
                      <span className="text-[#2c3e50] font-black text-sm flex items-center gap-1.5 justify-end">
                        {outfit.arabicName}
                        <span className="text-xl">{outfit.accessoryEmoji}</span>
                      </span>
                      <p className="text-gray-500 text-[10px] leading-relaxed max-w-[210px] mt-0.5">
                        {outfit.description}
                      </p>
                      {outfit.bonus && (
                        <span className="text-emerald-700 text-[10px] font-bold mt-1 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md inline-block self-end">
                          🎁 {outfit.bonus}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 3. POWER-UP UPGRADES (تطويرات القوى والقدرات بأسعار متصاعدة تدريجياً) */}
        <div className="shrink-0 mt-2">
          <h3 className="text-[#2c3e50] text-xs font-black mb-1 border-r-4 border-orange-500 pr-2 pb-0.5 flex items-center justify-between">
            <span>💪 ترقية المعدات والبرسيم السحري</span>
            <span className="text-[10px] text-orange-600 font-bold">تكلفة متصاعدة مع كل مستوى</span>
          </h3>
          <p className="text-gray-400 text-[11px] mb-3">
            طور قدراتك تدريجياً لزيادة فاعلية المغناطيس والدرع والبرسيم الذهبي المشع!
          </p>

          <div className="flex flex-col gap-3">
            {UPGRADES.map((upgrade) => {
              const currentLevel = getUpgradeLevel(upgrade.id);
              const isMax = currentLevel >= upgrade.maxLevel;
              const cost = getUpgradeCost(upgrade.basePrice, currentLevel);
              const canAfford = clovers >= cost && !isMax;
              const levelUpFn = getUpgradeLevelUpFn(upgrade.id);

              const handleUpgrade = () => {
                if (canAfford) {
                  subClovers(cost);
                  levelUpFn();
                  gameSoundsPlayClick();
                } else {
                  gameSoundsPlayHurt();
                }
              };

              return (
                <div 
                  key={upgrade.id}
                  className="bg-white border-2 border-orange-100 rounded-2xl p-3.5 flex justify-between items-center gap-4 text-right shadow-sm"
                >
                  {/* Upgrade progress bars & button */}
                  <div className="flex flex-col items-start gap-1.5 flex-shrink-0">
                    {isMax ? (
                      <span className="bg-[#27ae60]/10 text-[#27ae60] border border-[#27ae60]/30 font-black text-sm px-3.5 py-1.5 rounded-lg">
                        أقصى جودة 🌟
                      </span>
                    ) : (
                      <button
                        onClick={handleUpgrade}
                        disabled={!canAfford}
                        className={`font-black text-xs px-3.5 py-2 rounded-xl active:scale-95 transition-transform flex items-center gap-1.5 ${canAfford ? 'flat-btn-green text-white cursor-pointer shadow-sm' : 'bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed'}`}
                      >
                        <span>ترقية</span>
                        <span className="font-mono">{cost} 🍀</span>
                      </button>
                    )}

                    {/* Progress Indicator Blocks */}
                    <div className="flex gap-1.5 mt-1 justify-start">
                      {Array.from({ length: upgrade.maxLevel }).map((_, idx) => (
                        <div 
                          key={idx}
                          className={`w-3.5 h-2 rounded-full ${idx < currentLevel ? 'bg-orange-500 shadow-xs' : 'bg-gray-200'}`}
                        />
                      ))}
                    </div>
                    <span className="text-[10px] text-gray-400 font-mono">
                      مستوى {currentLevel} من {upgrade.maxLevel}
                    </span>
                  </div>

                  {/* Upgrade Text Description */}
                  <div className="flex items-center gap-2 justify-end flex-1">
                    <div className="flex flex-col text-right">
                      <span className="text-[#2c3e50] font-black text-sm sm:text-base flex items-center gap-1.5 justify-end">
                        {upgrade.arabicName}
                        <span className="text-xl">{upgrade.emoji}</span>
                      </span>
                      <p className="text-gray-500 text-xs sm:text-[12px] leading-relaxed max-w-[210px] mt-0.5">
                        {upgrade.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* FOOTER ACTION (العودة للرئيسية) */}
      <div className="mt-3 border-t border-orange-100 pt-3 flex flex-col gap-2.5 justify-center z-10 flex-shrink-0">
        <button
          onClick={onBack}
          className="w-full flat-btn-orange text-white font-extrabold text-base py-3 px-6 rounded-xl cursor-pointer"
        >
          العودة للقائمة الرئيسية ↩️
        </button>

        {/* 4. RESERVED BOTTOM BANNER AD SPACE (60px) */}
        <BannerAdSpace id="shop-bottom-banner" />
      </div>

      {/* 🎬 REWARDED AD MODAL OVERLAY */}
      {activeAd && (
        <RewardedAdModal
          placement={activeAd.placement}
          rewardDescription={activeAd.description}
          onRewardGranted={activeAd.onGranted}
          onClose={() => setActiveAd(null)}
        />
      )}

    </div>
  );
}
