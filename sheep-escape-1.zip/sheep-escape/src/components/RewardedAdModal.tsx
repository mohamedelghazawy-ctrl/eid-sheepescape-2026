/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Rewarded Ad Modal Player with Comedic Egyptian Commercials & Native WebView Bridge
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AdPlacement } from '../utils/adsManager';

interface RewardedAdModalProps {
  placement: AdPlacement;
  title?: string;
  rewardDescription: string;
  onRewardGranted: () => void;
  onClose: () => void;
}

const COMMERCIALS = [
  {
    brand: 'محل المعلم بسيوني للكباب والفتة بالخل والثوم 🥩🔥',
    tagline: 'كباب وكفتة على الفحم الأصلي! لحمة بلدي بتجري في عروقك!',
    quote: '"لو الخروف هرب منك.. تعالى كُل فتة وكوارع بالصلصة عندنا وانسى الهموم!" 😂🔪',
    badge: 'إعلان شعبي مميز 🌟',
    emoji: '🥩🍖🍛',
    color: 'from-amber-600 via-orange-600 to-red-700',
  },
  {
    brand: 'شطة البرنس الحارة الصاروخية 🌶️🚀',
    tagline: 'صاروخ الجري في الحواري والمدابح المصرية!',
    quote: '"نقطة واحدة على الفتة تخلي الخروف يجري أسرع من الصاروخ ويفلت من الساطور!" 💨',
    badge: 'طاقة نارية 100% 🔥',
    emoji: '🌶️⚡🏎️',
    color: 'from-red-600 via-rose-600 to-amber-600',
  },
  {
    brand: 'صوف هيركوليس الذهبي للأناقة البلدية 🐑✨',
    tagline: 'صوف فاخر وناعم لا يلتصق به حبل الجزار!',
    quote: '"يا واد يا خروف يا مزوق.. البس طربوش الباشا وادهن صوفك بالزبدة البلدية!" 👑',
    badge: 'أناقة العيد 🏆',
    emoji: '🐑✨👑',
    color: 'from-emerald-600 via-teal-600 to-sky-700',
  },
];

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({
  placement,
  title = 'مشاهدة إعلان قصير',
  rewardDescription,
  onRewardGranted,
  onClose,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(3);
  const [canClaim, setCanClaim] = useState(false);
  const commercial = useRef(COMMERCIALS[Math.floor(Math.random() * COMMERCIALS.length)]).current;

  // Inform native host/WebView if available
  useEffect(() => {
    try {
      if (typeof window !== 'undefined') {
        window.dispatchEvent(
          new CustomEvent('onRewardedAdStarted', {
            detail: { placement, timestamp: Date.now() },
          })
        );
        // Android / iOS native interface bridge check
        if ((window as any).Android?.onRewardedAdStarted) {
          (window as any).Android.onRewardedAdStarted(placement);
        }
      }
    } catch (e) {}
  }, [placement]);

  // 3-second countdown
  useEffect(() => {
    if (secondsLeft <= 0) {
      setCanClaim(true);
      return;
    }

    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanClaim(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [secondsLeft]);

  const handleClaim = () => {
    try {
      if (typeof window !== 'undefined') {
        window.dispatchEvent(
          new CustomEvent('onRewardedAdCompleted', {
            detail: { placement, timestamp: Date.now() },
          })
        );
        if ((window as any).Android?.onRewardedAdCompleted) {
          (window as any).Android.onRewardedAdCompleted(placement);
        }
      }
    } catch (e) {}

    onRewardGranted();
    onClose();
  };

  return (
    <AnimatePresence>
      <div 
        id="rewarded-ad-overlay"
        className="fixed inset-0 z-[120] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 text-center select-none"
        dir="rtl"
      >
        <motion.div
          initial={{ scale: 0.85, opacity: 0, y: 15 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.85, opacity: 0, y: 15 }}
          className="w-full max-w-sm bg-white rounded-[2.5rem] border-4 border-amber-400 p-5 sm:p-6 shadow-2xl flex flex-col gap-4 text-center relative overflow-hidden"
        >
          {/* Top Ad header & Timer bar */}
          <div className="flex justify-between items-center border-b border-gray-100 pb-2.5">
            <span className="text-[11px] font-black bg-amber-100 text-amber-900 border border-amber-300 px-3 py-0.5 rounded-full flex items-center gap-1">
              <span>🎬</span>
              <span>إعلان مكافأة كرتوني</span>
            </span>

            <div className="flex items-center gap-1 text-xs font-mono font-bold text-gray-500">
              {canClaim ? (
                <span className="text-emerald-600 font-black animate-pulse flex items-center gap-1">
                  <span>✓</span>
                  <span>اكتملت المشاهدة</span>
                </span>
              ) : (
                <span>متبقي: <strong className="text-amber-600 font-mono text-sm">{secondsLeft}s</strong></span>
              )}
            </div>
          </div>

          {/* Sponsored Egyptian Commercial Billboard */}
          <div className={`rounded-3xl p-5 text-white bg-gradient-to-br ${commercial.color} shadow-lg relative overflow-hidden flex flex-col items-center justify-center gap-2.5`}>
            <div className="absolute top-2 right-3 text-[10px] bg-black/30 backdrop-blur-xs px-2 py-0.5 rounded-full font-bold">
              {commercial.badge}
            </div>

            <div className="text-4xl my-1 animate-bounce">
              {commercial.emoji}
            </div>

            <h3 className="font-black text-base sm:text-lg leading-tight drop-shadow-sm text-yellow-100">
              {commercial.brand}
            </h3>

            <p className="text-xs font-bold leading-normal text-white/95">
              {commercial.tagline}
            </p>

            <div className="bg-black/25 backdrop-blur-xs p-2.5 rounded-2xl border border-white/20 text-[11px] font-bold italic leading-relaxed text-yellow-50">
              {commercial.quote}
            </div>
          </div>

          {/* Reward Promise Box */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 flex flex-col items-center justify-center gap-1 text-center">
            <span className="text-[11px] text-emerald-800 font-extrabold">المكافأة المستحقة بعد الإعلان:</span>
            <span className="text-sm font-black text-emerald-600 font-mono flex items-center gap-1.5">
              <span>🎁</span>
              <span>{rewardDescription}</span>
            </span>
          </div>

          {/* Progress / Claim Button */}
          <div className="flex flex-col gap-2">
            {canClaim ? (
              <button
                onClick={handleClaim}
                className="w-full py-3.5 bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 hover:brightness-105 active:scale-95 text-white font-black text-sm sm:text-base rounded-2xl shadow-xl border-b-4 border-emerald-700 cursor-pointer flex items-center justify-center gap-2 transition-all animate-bounce"
              >
                <span>🎉</span>
                <span>استلم المكافأة فوراً!</span>
                <span>✨</span>
              </button>
            ) : (
              <div className="w-full py-3 bg-gray-100 text-gray-500 font-bold text-xs sm:text-sm rounded-2xl flex items-center justify-center gap-2 border border-gray-200">
                <span className="w-4 h-4 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
                <span>شاهد حتى النهاية لاستلام المكافأة ({secondsLeft} ثوانٍ)...</span>
              </div>
            )}

            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 text-[11px] font-bold py-1 cursor-pointer transition-colors"
            >
              إلغاء والعودة للعبة
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
export default RewardedAdModal;
