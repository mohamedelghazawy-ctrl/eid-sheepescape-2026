/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Reserved 60px Bottom Banner Ad Space for Mobile WebViews & Native Ad SDKs
 */

import React from 'react';
import { APP_CONFIG } from '../config';

interface BannerAdSpaceProps {
  id?: string;
  className?: string;
}

export const BannerAdSpace: React.FC<BannerAdSpaceProps> = ({
  id = 'bottom-banner-ad-space',
  className = '',
}) => {
  // لا نعرض مساحة إعلان فارغة للمستخدم حتى تُربط شبكة إعلانات حقيقية (config.ts)
  if (!APP_CONFIG.SHOW_BANNER_AD_PLACEHOLDER) return null;
  return (
    <div
      id={id}
      data-ad-slot="banner"
      className={`w-full h-[60px] min-h-[60px] max-h-[60px] bg-amber-50/70 border-t border-dashed border-amber-200/80 flex items-center justify-center text-center select-none overflow-hidden shrink-0 relative transition-all ${className}`}
      dir="rtl"
    >
      <div className="flex items-center justify-center gap-2 text-gray-400 text-[10.5px] font-bold px-3">
        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
        <span className="bg-amber-100 text-amber-800 text-[9px] font-black px-1.5 py-0.5 rounded border border-amber-200">
          إعلان
        </span>
        <span className="text-gray-500 font-mono tracking-wide">
          مساحة مخصصة لإعلان البنر السفلي (320x50 / 60px) 📱✨
        </span>
      </div>
    </div>
  );
};
export default BannerAdSpace;
