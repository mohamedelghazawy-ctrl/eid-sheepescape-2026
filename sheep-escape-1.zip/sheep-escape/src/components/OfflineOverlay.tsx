import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { isConnected } from '../utils/connection';
import { APP_CONFIG } from '../config';

interface OfflineOverlayProps {
  onConnectivityRestored?: () => void;
  onExitGame?: () => void;
  isGameRunning?: boolean;
}

export const OfflineOverlay: React.FC<OfflineOverlayProps> = ({
  onConnectivityRestored,
  onExitGame,
  isGameRunning = false,
}) => {
  // Check if browser/webview is currently offline
  const [isOffline, setIsOffline] = useState<boolean>(() => {
    return !isConnected();
  });

  const [isChecking, setIsChecking] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);
  const [isShake, setIsShake] = useState(false);

  // Synchronize with browser online/offline events & expose global showOfflineOverlay
  useEffect(() => {
    // بدون REQUIRE_INTERNET لا نسجّل أي مستمع ولا نجمّد اللعبة عند تغيّر حالة الشبكة
    if (!APP_CONFIG.REQUIRE_INTERNET) return;
    (window as any).showOfflineOverlay = () => {
      setIsOffline(true);
      setFeedbackMessage(null);
      if (typeof (window as any).freezeGameMovement === 'function') {
        (window as any).freezeGameMovement();
      }
    };

    const handleOffline = () => {
      setIsOffline(true);
      setFeedbackMessage(null);
      if (typeof (window as any).freezeGameMovement === 'function') {
        (window as any).freezeGameMovement();
      }
    };

    const handleOnline = () => {
      setIsOffline(false);
      setFeedbackMessage(null);
      if (typeof (window as any).unfreezeGameMovement === 'function') {
        (window as any).unfreezeGameMovement();
      }
      if (onConnectivityRestored) {
        onConnectivityRestored();
      }
    };

    window.addEventListener('offline', handleOffline);
    window.addEventListener('online', handleOnline);

    return () => {
      delete (window as any).showOfflineOverlay;
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('online', handleOnline);
    };
  }, [onConnectivityRestored]);

  // Check connection status via isConnected() when "إعادة المحاولة 🔄" is clicked
  const handleRetry = useCallback(async () => {
    setIsChecking(true);
    setFeedbackMessage(null);

    // Short realistic delay for animated feedback
    await new Promise((resolve) => setTimeout(resolve, 300));

    // Direct connectivity check
    const isOnline = isConnected();

    setIsChecking(false);

    if (isOnline) {
      // Network is back! Hide overlay and resume game immediately without full reload
      setIsOffline(false);
      setFeedbackMessage(null);
      if (typeof (window as any).unfreezeGameMovement === 'function') {
        (window as any).unfreezeGameMovement();
      }
      window.dispatchEvent(new Event('online'));
      if (onConnectivityRestored) {
        onConnectivityRestored();
      }
    } else {
      // Still offline: trigger comic shake and error message
      setIsShake(true);
      setTimeout(() => setIsShake(false), 500);
      setFeedbackMessage('النت لسه مقطوع! تأكد من تشغيل الواي فاي أو بيانات الهاتف وحاول مرة أخرى 📶🔌');
    }
  }, [onConnectivityRestored]);

  // Handle exiting the game
  const handleExit = () => {
    if (onExitGame) {
      onExitGame();
    }
    try {
      if (typeof window !== 'undefined') {
        if ((window as any).Android?.closeApp) {
          (window as any).Android.closeApp();
        } else if ((window as any).Android?.exitApp) {
          (window as any).Android.exitApp();
        }
      }
    } catch (e) {}

    // Strict internet requirement: do NOT dismiss overlay if still offline
    if (isConnected()) {
      setIsOffline(false);
    } else {
      setFeedbackMessage('تم إنهاء الجولة. الاتصال بالإنترنت مطلوب إجبارياً لبدء الجولة ومواصلة اللعب 📶⚠️');
    }
  };

  if (!APP_CONFIG.REQUIRE_INTERNET || !isOffline) {
    return null;
  }

  return (
    <AnimatePresence>
      <motion.div
        id="offline-overlay"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md select-none overflow-hidden"
        dir="rtl"
      >
        <motion.div
          initial={{ scale: 0.85, y: 20 }}
          animate={
            isShake
              ? {
                  scale: [1, 1.03, 0.97, 1.02, 1],
                  x: [0, -10, 10, -8, 8, -4, 4, 0],
                }
              : { scale: 1, y: 0 }
          }
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="relative w-full max-w-sm bg-gradient-to-b from-[#fffbf5] to-[#fdf2e9] border-4 border-amber-500 rounded-[2.5rem] p-5 sm:p-6 shadow-2xl flex flex-col items-center text-center gap-4 text-[#2c3e50] overflow-hidden"
        >
          {/* Decorative Corner Ribbons / Butcher theme */}
          <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-amber-400/30 to-transparent rounded-bl-full pointer-events-none" />
          <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-gradient-to-tr from-orange-400/20 to-transparent rounded-full pointer-events-none" />

          {/* Animated Cartoon Illustration: Sheep with Severed Cable & Butcher Knife */}
          <div className="relative mt-2">
            {/* Outer Glow Halo */}
            <div className="w-24 h-24 rounded-full bg-amber-100 border-4 border-amber-300 flex items-center justify-center shadow-inner relative">
              <span className="text-5xl animate-bounce">🐑</span>
              
              {/* Crossed Wi-Fi badge */}
              <div className="absolute -top-1 -right-2 bg-red-600 text-white w-9 h-9 rounded-full flex items-center justify-center border-2 border-white shadow-md text-sm font-black animate-pulse">
                📶❌
              </div>

              {/* Butcher Knife comic sticker */}
              <div className="absolute -bottom-1 -left-2 bg-orange-600 text-white w-8 h-8 rounded-full flex items-center justify-center border-2 border-white shadow-md text-xs">
                🔪⚡
              </div>
            </div>
          </div>

          {/* Header Title: "عفواً.. الجزار قطع النت! 🐑📶" */}
          <div className="flex flex-col items-center">
            <h2 className="text-xl sm:text-2xl font-black text-red-600 tracking-tight mt-0.5">
              عفواً.. الجزار قطع النت! 🐑📶
            </h2>
          </div>

          {/* Humorous Clarification Message */}
          <div className="bg-white/90 border border-orange-200 rounded-2xl p-3.5 shadow-xs w-full text-right flex flex-col gap-1.5">
            <p className="text-xs sm:text-[13px] font-bold text-gray-700 leading-relaxed">
              شكله <span className="text-orange-600 font-black">المعلم بسيوني</span> حب يقطع سلك النت عشان يمسك الخروف المتشرد! 🔪✂️🌐
            </p>
            <p className="text-[11px] sm:text-xs text-gray-600 font-bold leading-relaxed">
              اللعبة تتطلب اتصالاً فعالاً بالإنترنت لمواصلة الهروب وحفظ تقدمك وجوائزك. يرجى الاتصال بشبكة الواي فاي أو تفعيل بيانات الهاتف للمتابعة.
            </p>
          </div>

          {/* Feedback message if retry failed */}
          {feedbackMessage && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-xs font-black p-2.5 rounded-xl border w-full leading-normal bg-red-50 text-red-700 border-red-200"
            >
              {feedbackMessage}
            </motion.div>
          )}

          {/* Action Buttons: Prominent Cartoon Retry Button & Exit Game Button */}
          <div className="w-full flex flex-col gap-2.5 mt-1">
            {/* 1. زر كرتوني بارز: إعادة المحاولة 🔄 */}
            <button
              onClick={handleRetry}
              disabled={isChecking}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-500 via-green-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 active:scale-95 text-white border-b-4 border-emerald-800 font-black text-sm sm:text-base rounded-2xl shadow-xl flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-60"
            >
              <span className={`text-lg ${isChecking ? 'animate-spin' : ''}`}>🔄</span>
              <span>{isChecking ? 'جاري فحص الاتصال...' : 'إعادة المحاولة 🔄'}</span>
            </button>

            {/* 2. زر الخروج من اللعبة 🚪 */}
            <button
              onClick={handleExit}
              className="w-full py-2.5 px-4 bg-rose-50 hover:bg-rose-100 active:scale-95 text-rose-700 border-2 border-rose-300 hover:border-rose-400 font-black text-xs sm:text-sm rounded-xl cursor-pointer flex items-center justify-center gap-2 transition-all shadow-xs"
            >
              <span>🚪</span>
              <span>الخروج من اللعبة</span>
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
export default OfflineOverlay;
