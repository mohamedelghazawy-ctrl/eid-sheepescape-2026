/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ControlMode } from '../types';

interface TutorialOverlayProps {
  onClose: () => void;
  controlMode: ControlMode;
}

export default function TutorialOverlay({ onClose, controlMode }: TutorialOverlayProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: 'تغيير الحارات وتفادي العوائق',
      icon: '🛺↔️',
      description: controlMode === 'swipe'
        ? 'اسحب بإصبعك يميناً أو يساراً 👈👉 للتنقل السريع بين الحارات الثلاث والابتعاد عن التكاتك وعربات البطيخ والخضار.'
        : 'اضغط على أزرار الأسهم يميناً أو يساراً ⬅️ ➡️ أسفل الشاشة أو استخدم مفاتيح (A/D) للتنقل بين الحارات الثلاث.',
      badge: 'التنقل والحركة',
      badgeColor: 'bg-blue-500',
      animation: 'lateral'
    },
    {
      title: 'القفز فوق الحواجز وقدرات الكابتن',
      icon: '⬆️⚽',
      description: controlMode === 'swipe'
        ? 'اسحب لأعلى ⬆️ للقفز فوق قدور الفول وحواجز الطريق. (إذا كنت ترتدي خروف كابتن الملاعب يمكنك السحب مجدداً للقفز المزدوج Double Jump!).'
        : 'اضغط زر القفز ⬆️ أو مفتاح المسافة/W للقفز. وخروف كابتن الملاعب يمكنه القفز مرتين متتاليتين في الهواء لتفادي العربات العالية!',
      badge: 'القفز والدبل جمب',
      badgeColor: 'bg-emerald-500',
      animation: 'jump'
    },
    {
      title: 'التزحلق تحت حبال الغسيل',
      icon: '⬇️🧺',
      description: controlMode === 'swipe'
        ? 'اسحب لأسفل ⬇️ للانزلاق بسرعة على الأرض والمرور بأمان تحت حبال غسيل الحارة والمظلات المنخفضة.'
        : 'اضغط زر التزحلق ⬇️ أو مفتاح (S) للانزلاق تحت حبال الغسيل والمظلات المنخفضة دون الاصطدام بها.',
      badge: 'الانزلاق السريع',
      badgeColor: 'bg-amber-500',
      animation: 'slide'
    },
    {
      title: 'المعدات السحرية وبالونات العيد',
      icon: '🌶️🍲🌟🎈',
      description: '• 🌶️ شطة الجزار النارية: طيران وسرعة خارقة وجذب كل البرسيم!\n• 🍲 صينية الفتة بالثوم: درع حماية مؤقت.\n• 🌟 البرسيم الذهبي المشع: يمنحك 5 زهور فوراً.\n• 🎈 بالونات العيد: تحميك من الخسارة وتجعلك تكمل الجولة بعد الاصطدام!',
      badge: 'القدرات الخارقة',
      badgeColor: 'bg-rose-500',
      animation: 'powers'
    }
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      handleFinish();
    }
  };

  const handleFinish = () => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem('sheep_game_tutorial_completed', 'true');
      }
    } catch (e) {}
    onClose();
  };

  const step = steps[currentStep];

  return (
    <div 
      id="tutorial-overlay" 
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 select-none text-right font-sans animate-fade-in"
      dir="rtl"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="relative w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border-4 border-orange-400 flex flex-col gap-4 overflow-hidden"
      >
        {/* Top Header */}
        <div className="flex justify-between items-center border-b-2 border-orange-100 pb-2.5">
          <div className="flex items-center gap-1.5">
            <span className="text-2xl animate-bounce">🐑💨</span>
            <div>
              <h2 className="text-[#e67e22] font-black text-base sm:text-lg tracking-tight">
                برنامج تعليمي: هروب الخروف
              </h2>
              <span className="text-gray-400 text-[10.5px] font-bold">
                خطوة {currentStep + 1} من {steps.length}
              </span>
            </div>
          </div>
          <button
            onClick={handleFinish}
            className="text-gray-400 hover:text-gray-600 active:scale-95 text-xs font-black bg-gray-100 px-2.5 py-1 rounded-full cursor-pointer transition-colors"
          >
            تخطي ✕
          </button>
        </div>

        {/* Step Progress indicators */}
        <div className="flex gap-1.5 w-full">
          {steps.map((_, idx) => (
            <div
              key={idx}
              className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${
                idx === currentStep
                  ? 'bg-orange-500 scale-y-125'
                  : idx < currentStep
                  ? 'bg-emerald-500'
                  : 'bg-gray-200'
              }`}
            />
          ))}
        </div>

        {/* Content Card with Light Animation illustration */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="flex flex-col gap-3"
          >
            {/* Animated Demo Box */}
            <div className="w-full h-32 bg-gradient-to-b from-orange-50 to-amber-100/60 rounded-2xl border-2 border-dashed border-orange-200 flex flex-col items-center justify-center relative overflow-hidden p-2">
              <span className="text-4xl filter drop-shadow-sm animate-pulse mb-1">
                {step.icon}
              </span>

              {/* Lightweight CSS Motion Animations */}
              {step.animation === 'lateral' && (
                <div className="flex items-center justify-center gap-4 text-xs font-black text-blue-700">
                  <motion.span 
                    animate={{ x: [-15, 15, -15] }} 
                    transition={{ repeat: Infinity, duration: 1.6, ease: 'easeInOut' }}
                    className="text-2xl"
                  >
                    🐑
                  </motion.span>
                  <span className="bg-white/80 px-2 py-0.5 rounded-full border border-blue-200 text-[11px]">
                    اسحب أو اضغط الأسهم
                  </span>
                </div>
              )}

              {step.animation === 'jump' && (
                <div className="flex items-center justify-center gap-3 text-xs font-black text-emerald-700">
                  <motion.span 
                    animate={{ y: [0, -22, 0] }} 
                    transition={{ repeat: Infinity, duration: 1.2, ease: 'easeOut' }}
                    className="text-2xl"
                  >
                    🐑⬆️
                  </motion.span>
                  <span className="bg-white/80 px-2 py-0.5 rounded-full border border-emerald-200 text-[11px]">
                    سحب لأعلى أو زر القفز
                  </span>
                </div>
              )}

              {step.animation === 'slide' && (
                <div className="flex items-center justify-center gap-3 text-xs font-black text-amber-700">
                  <motion.span 
                    animate={{ scaleY: [1, 0.55, 1], y: [0, 8, 0] }} 
                    transition={{ repeat: Infinity, duration: 1.3, ease: 'easeInOut' }}
                    className="text-2xl"
                  >
                    🐑⬇️
                  </motion.span>
                  <span className="bg-white/80 px-2 py-0.5 rounded-full border border-amber-200 text-[11px]">
                    سحب لأسفل أو زر التزحلق
                  </span>
                </div>
              )}

              {step.animation === 'powers' && (
                <div className="flex items-center justify-center gap-2">
                  <motion.span animate={{ rotate: [0, 15, -15, 0] }} transition={{ repeat: Infinity, duration: 2 }} className="text-xl">
                    🌶️
                  </motion.span>
                  <motion.span animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1.5 }} className="text-xl">
                    🍲
                  </motion.span>
                  <motion.span animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 3, ease: 'linear' }} className="text-xl">
                    🌟
                  </motion.span>
                  <motion.span animate={{ y: [0, -6, 0] }} transition={{ repeat: Infinity, duration: 1.8 }} className="text-xl">
                    🎈
                  </motion.span>
                </div>
              )}

              <span className={`absolute top-2 right-2 text-white text-[9.5px] font-black px-2 py-0.5 rounded-full shadow-xs ${step.badgeColor}`}>
                {step.badge}
              </span>
            </div>

            {/* Instruction Description */}
            <div className="flex flex-col gap-1 text-right">
              <h3 className="text-[#2c3e50] font-black text-sm sm:text-base">
                {step.title}
              </h3>
              <p className="text-gray-600 text-xs sm:text-[13px] leading-relaxed whitespace-pre-line font-medium">
                {step.description}
              </p>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Buttons Controls */}
        <div className="flex items-center gap-2 pt-1 border-t border-gray-100">
          {currentStep > 0 && (
            <button
              onClick={() => setCurrentStep(prev => prev - 1)}
              className="bg-gray-100 hover:bg-gray-200 active:scale-95 text-gray-700 font-black text-xs py-2.5 px-3 rounded-xl cursor-pointer transition-all"
            >
              السابق
            </button>
          )}

          <button
            onClick={handleNext}
            className="flex-1 bg-[#10b981] hover:bg-[#059669] active:scale-95 text-white border-b-4 border-[#047857] font-extrabold text-sm py-2.5 rounded-xl cursor-pointer text-center shadow-md transition-all flex items-center justify-center gap-1.5"
          >
            {currentStep === steps.length - 1 ? (
              <>
                <span>فهمت يا معلم.. ابدأ الهروب!</span>
                <span>🚀🐑</span>
              </>
            ) : (
              <>
                <span>التالي</span>
                <span>👈</span>
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
