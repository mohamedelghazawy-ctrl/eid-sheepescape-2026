import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { isNativeApp } from './utils/connection';

// خدمة الكاش (PWA) للنسخة المستضافة على الويب فقط.
// داخل تطبيق الأندرويد كل الملفات مضمّنة في الحزمة، وأي كاش قديم قد يعرض نسخة سابقة بعد التحديث،
// لذلك نلغي أي service worker قديم هناك ولا نسجّل جديداً.
if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  if (isNativeApp()) {
    navigator.serviceWorker
      .getRegistrations()
      .then((regs) => regs.forEach((r) => r.unregister()))
      .catch(() => {});
  } else {
    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('/sw.js')
        .then((registration) => {
          console.log('[PWA] Service Worker registered successfully:', registration.scope);
        })
        .catch((error) => {
          console.warn('[PWA] Service Worker registration failed:', error);
        });
    });
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
