#!/usr/bin/env node
/**
 * يضبط مشروع الأندرويد المولَّد بواسطة `cap add android`:
 *   • قفل الاتجاه على الوضع الرأسي (اللعبة مصمَّمة للوضع الرأسي فقط).
 * آمن للتشغيل أكثر من مرة (idempotent).
 */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const manifestPath = resolve('android/app/src/main/AndroidManifest.xml');

if (!existsSync(manifestPath)) {
  console.error('✗ لم أجد android/app/src/main/AndroidManifest.xml');
  console.error('  شغّل أولاً: npm run android:add');
  process.exit(1);
}

let xml = readFileSync(manifestPath, 'utf8');

if (/android:screenOrientation\s*=/.test(xml)) {
  console.log('✓ اتجاه الشاشة مضبوط مسبقاً، لا تغيير.');
} else {
  const patched = xml.replace(/<activity\b/, '<activity\n            android:screenOrientation="portrait"');
  if (patched === xml) {
    console.error('✗ لم أجد وسم <activity> في الـ Manifest.');
    process.exit(1);
  }
  writeFileSync(manifestPath, patched);
  console.log('✓ تم قفل الاتجاه على الوضع الرأسي.');
}
